<?php 
session_start();
$_SESSION['Category_ID']=$_GET['Category_ID'];
require 'connect.php';
$sql=" DELETE from categories WHERE Category_ID='$_SESSION[Category_ID]' ";
    $result = mysqli_query($conn, $sql); 
    if($result){
        $success ='<span class="success">1 Category deleted successfuly</span>';
         header("Location:categories.php");
        echo $success;
    }
     else{
         $fail='<span class="err">Failed to delete </span>';}
 

 ?>