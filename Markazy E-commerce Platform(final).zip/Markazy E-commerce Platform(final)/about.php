<?php
session_start();
require 'connect.php';
error_reporting(0);

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
   <link rel="stylesheet" href="about.css" /> 
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>About us</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
<?php include 'navigation.php';?>

 <main>
 	<section>
  <h1>About Markazy </h1>

  <p>
  	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam,
  	quis nostrud exercitation <br>
  	 ullamco laboris nisi ut aliquip ex ea commodo
  	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
  	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
  	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
  </p>
  
</section>

<section >
    <h1 class="story">Our Story</h1>
    <h2 class="fromAtoZ">From experiment to global movement</h2>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Excepturi, sunt officia quo earum id hic ipsum molestiae sequi possimus nemo laboriosam dolorem perferendis ullam voluptate eos facere accusantium? Quasi, nesciunt!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sequi reprehenderit, quod cupiditate voluptas nostrum, placeat atque vitae ut porro dolorem neque debitis sunt quisquam nam, perferendis illo quis adipisci nesciunt!
    </p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis cum quaerat nam molestias maxime iure ipsum dolor iste dolorum ex saepe tenetur, asperiores nihil voluptatem amet minima adipisci nisi suscipit!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum modi saepe dignissimos odit ratione cum quisquam, iure, laudantium illo similique vel eum magni? Accusantium cumque dignissimos optio, itaque pariatur ea.
    </p>
</section>
<section>    
   <h1>Our mission </h1>
   <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Necessitatibus maxime ipsum natus, reiciendis aliquam nobis ea doloribus quod voluptatum sint enim. Pariatur veritatis illum laboriosam dolores velit molestiae possimus mollitia</p>
  <ul>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur </li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  

  </ul>
</section>

<section>
	 <h1>Timeline</h1>

	 <h2>2015</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>

	 <h2>2017</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>

	 <h2>2019</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
     <h2>2021</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
     <h2>2022</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
</section>

</main>
  
<?php include 'footer.php' ?>
    