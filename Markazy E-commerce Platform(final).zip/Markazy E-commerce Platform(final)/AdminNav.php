<?php 
require 'connect.php';
?>  
  

        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <script src="https://kit.fontawesome.com/526db9288e.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="adminNav.css">
    
</head>
<body>
<div class="allnav">
<div class="mainnavbox">
    <nav class="mainnav">
    <a class="menu" href="javascript:void(0);" onclick="openNav()"><i class="fa solid fa-bars"></i></a>
    <!--<a class="moon" href="javascript:void(0);"><i class="fa solid fa-moon"></i></a>-->
    <a class="logo" href="admin.php"><img src="logo.jpg"></a>
    <div class="extra"></div>

 
</nav>
</div>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <div class="log">
  <a href="logout.php"  class="logout">Log Out</a>
             
  </div>
        
      
            <a href="users.php">Users</a>
            <a href="stores.php">Stores</a>
            <a href="adminproducts.php">Products</a>
            <a href="adminorders.php">Orders</a>
            <a href="adminreviews.php">Reviews</a>
</div>
</div>
<script>
function openNav() {
  if (window.matchMedia("(min-width: 550px)").matches) {
    document.getElementById("mySidenav").style.width ="60%"; 
} else {
  document.getElementById("mySidenav").style.width ="80%"; 
}
  
}
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


</script>


