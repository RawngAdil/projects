<?php
session_start();
require 'connect.php';
error_reporting(0);
if(isset($_SESSION['ROLE'])){
  if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){
    header("Location:admin.php");
    die;
  }
}
if(!isset($_SESSION['ROLE']) && $_SESSION['ROLE'] !== 'Supplier'){
    header("Location:index.php");
    die;
}

$notification ='';
if(isset($_GET['addsuccess'])){
    $notification = 'Your new product has been added successfully';?>
  <script>
      history.pushState(null, "", location.href.split("?")[0]);
   
  </script>
  <?php }
if(isset($_GET['updatesuccess'])){
    $notification = 'Your new product has been updated successfully';?>
  <script>
      history.pushState(null, "", location.href.split("?")[0]);
   
  </script>
  <?php }
  if(isset($_GET['deletesuccess'])){
    $notification = 'The product has been deleted successfully';?>
  <script>
      history.pushState(null, "", location.href.split("?")[0]);
   
  </script>
  <?php }
   if(isset($_GET['deletefail'])){
    $notification = 'System Error: The system was unable to delete the product';?>
  <script>
      history.pushState(null, "", location.href.split("?")[0]);
   
  </script>
  <?php }?>
<!DOCTYPE html>
<html>
 
    <head>
     <title>MY STORE</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <?php
    include 'navigation.php';?>
    <?php
    $sql = "SELECT * FROM users JOIN stores ON users.USER_ID = stores.SUPPLIER_ID WHERE USER_ID = '$_SESSION[ID]'";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){
        ?>
    
    <section class="storedetails">
    <div class="mydetails">
    <div class="image-cropper">
       <img class="profile" src="images/<?=$row['PROFILE_PIC']?>" />
</div><br>
        <h1><?=$row['STORE_NAME']?></h1><br>
      
<?php
    $star = round($row['AVG_RATING'],0);?>
 <div class="s-rating">
    <span class="star-rating">
            <input type="radio" name="rating" value="1" disabled <?php if($star == 1){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="2" disabled <?php if($star == 2){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="3" disabled <?php if($star == 3){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="4" disabled <?php if($star == 4){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="5" disabled <?php if($star == 5){echo "checked";}?>><i class="star"></i>
          </span>
          <span class="rating"><?= number_format((float)$row['AVG_RATING'], 1, '.', '')?> / 5.0</span>
    </div><br>
<h2>Store Description</h2>
<p class="StoreDesc"><?= $row['STORE_DESCRIPTION']?></p>
    </div>
    </section>
    <?php ;}?>
    <section class="yourproducts">
        <h1 class="cartheading">Your Products</h1>
        <a href="editproduct.php?addnew"><button class="addnew">Add New Products</button></a><br>
        <input type="text" id="myInput" onkeyup="filter()" placeholder="Search for names.." class="field">
        <div class="tablecontainer">
        <table id="myproducts">
            <tr>
                <th>Product Name</th>
                <th>Average Rating</th>
                <th>Edit Product</th>
                <th>Delete Product</th>
    </tr>
            <?php
            $sql = "SELECT * FROM products WHERE SUPPLIER_ID = '$_SESSION[ID]'";
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($result)){?>
            <tr>
                <td><?=$row['PRODUCT_NAME']?></td>
                <td><?=number_format((float)$row['Average_rating'], 2, '.', '')?>/5</td>
                <td><a href="editproduct.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>">Edit Product Details</a></td>
                <td><a href="editproduct.php?delete=<?=$row['PRODUCT_ID']?>" onclick="return confirm('Are you sure you want to delete <?=$row['PRODUCT_NAME']?>')">Delete Product</a></td>
            </tr>

            <?php ;}?>

            </table>
            </div>
            </section>
            <script>
function filter() {

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myproducts");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
            
    <?php include 'footer.php'?>