<?php 
include 'Templates/header.php';
 ?>

<main>
	<section class="coursecontent">
		<header>
	<?php
	require 'connect.php';
	          $sql1 = "SELECT * FROM courses "; 
       			$result1 = mysqli_query($conn ,$sql1); 
       			$sql2 = "SELECT * FROM lectures WHERE course_id = '$_GET[course_id]'";
       			$result2 = mysqli_query($conn ,$sql2); 
       				if (mysqli_num_rows($result2) >0) {
       		 $row = mysqli_fetch_assoc($result1) ?>

       			  <h1 class="coursename"><?=$row['course_name']?></h1>
                    <p class="courseDesc">
                       Description: <br> <?=$row['description']?>
                    </p>
       </header>
       <section>
       <?php while ( $lec = mysqli_fetch_assoc($result2) ) { ?>
       	     <h3 class="lecname">
       	     	<a href="course.php?course_id=<?=$_GET['course_id']?>&url=<?=$lec['url']?>"><?=$lec['lecture_name']?></a>
       	     </h3>
       	</section>
                     <section class="lecRun">
                 <?php  } 
                 if (isset($_GET['url'])) {
                   
                 
        $sql3= "SELECT lecture_name FROM lectures WHERE url = '$_GET[url]'";
            $result3 = mysqli_query($conn ,$sql3);
            $lec2 =  mysqli_fetch_assoc($result3);

                 ?>
                   <h3 class="lecname">
                   Lecture : <?=$lec2['lecture_name']?>
                   </h3>
             <iframe src="https://www.youtube.com/embed/<?=$_GET['url']?>" height="315" width="90%" title="Youtube Video"></iframe>
 </section>
                 <?php  }} ?>

       </section>
</main>

 <?php 
include 'Templates/footer.php';
 ?>