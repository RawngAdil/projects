<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID']) ){
    header("Location:index.php");
    die;
}elseif(isset($_GET['addnew'])){
    $productpic = $productname = $category = $producttype = $price = $stock = $productdescrpt = $notification = '';
    $productnameErr = $categoryErr = $producttypeErr = $priceErr = $stockErr = $productdescrptErr = '';
    if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['add'])){

        if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
            $filename = $_FILES["uploadfile"]["name"];
            $tempname = $_FILES["uploadfile"]["tmp_name"];    
             $folder ="images/".$filename;
             move_uploaded_file($tempname, $folder);
             $productpic = $filename;
        }else{
            $productpic = 'apples-carrots-food-foodie.jpg';
        }
       
        if(isset($_POST["productname"])){
            $productname=$conn -> real_escape_string($_POST["productname"]);
            
            if(empty($_POST["productname"])){
            $productnameErr = "product Name is required";
            unset($_POST["productname"]);
        }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["productname"])){
        $productnameErr = "Only letters allowed";
        unset($_POST["productname"]);}
    }else{ 
    $productnameErr = "product Name is required";
    }

    if(isset($_POST["category"])){
        $category= $_POST["category"];
       }else{
        $categoryErr = "Category is required";
    } if(isset($_POST["producttype"])){
        $producttype= $_POST["producttype"];
       }else{
        $producttypeErr = "Choose a product type";
    }if(isset($_POST['price'])){
        $price = $_POST['price'];
        if(empty($_POST["price"]) || $_POST["price"] == 0 ){
            $priceErr = "Price is required";
            unset($_POST["price"]);
        }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["price"])){
            $priceErr = "Numbers only";
            unset($_POST["price"]);
        }}else{
            $priceErr = "Price is required"; 
        }if(isset($_POST['stock'])){
            $stock = $_POST['stock'];
            if(empty($_POST["stock"]) || $_POST["stock"] == 0 ){
                $stockErr = "Stock is required";
                unset($_POST["stock"]);
            }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["stock"])){
                $stockErr = "Numbers only";
                unset($_POST["stock"]);
            }}else{
                $stockErr = "Stock is required"; 
            }
            if(isset($_POST["productdescrpt"]) || empty($_POST['productdescrpt'])){
                $productdescrpt= $_POST["productdescrpt"];
               }else{
                $productdescrptErr = "Product Description is required";
            } 
    if($productnameErr == '' and $categoryErr == '' and $producttypeErr == '' and $priceErr == '' and $stockErr == '' and  $productdescrptErr == ''){
 
            $sql="SELECT DEFPRODUCT_ID FROM defproducts WHERE DEFPRODUCT_NAME = '$producttype'";
            $result =mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($result)){
                
            $insert = "INSERT INTO products (DEFPRODUCT_ID,PRODUCT_NAME ,PRODUCT_IMG ,PRICE ,STOCK ,PRODUCT_DESCRYPT ,SUPPLIER_ID) VALUES ('$row[DEFPRODUCT_ID]','$productname','$productpic','$price','$stock','$productdescrpt','$_SESSION[ID]')";
            $result1 = mysqli_query($conn, $insert);
            if($result1){
                header("Location:mystore.php?addsuccess");
            die(); 
        }else{
                $notification = "systemerror";
            }
        
        }
    }}
    include 'notification.php';
?>
<!DOCTYPE html>
<html>
    <head>
    
     <title>Add New Product</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="register.css">
      <link rel="stylesheet" type="text/css" href="style.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
     <script>
function validateForm() {
  if (document.getElementById("productname").value == '') {
    alert("Product Name must be filled out");
    return false;
  }else if (document.getElementById("lastname").value == '') {
    alert("Last Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if (document.getElementById("telnumber").value == '') {
    alert("Mobile Number must be filled out");
    return false;
  }else if (document.getElementById("address").value == '') {
    alert("Address must be filled out");
    return false;
  }else if (document.getElementById("companyname").value == '') {
    alert("Company Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if(document.getElementById("password").value == '') {
    alert("Password must be filled out");
    return false;
  }else if(document.getElementById("reppassword").value == '') {
    alert("Please Confirm Your Password");
    return false;
  }
}
function defproduct(){
    if(document.getElementById('selectcategory2').value == "Vegetable") {
      document.getElementById('producttype1').style.display= "inline-block";
      document.getElementById('producttype1').removeAttribute("disabled");
      document.getElementById('producttype2').style.display= "none";
      document.getElementById('producttype2').setAttribute("disabled","");
}else if(document.getElementById('selectcategory2').value == "Fruit"){ 
  document.getElementById('producttype2').style.display= "inline-block";
  document.getElementById('producttype2').removeAttribute("disabled");
  document.getElementById('producttype1').style.display= "none";
  document.getElementById('producttype1').setAttribute("disabled","");
}else {
  document.getElementById('producttype1').style.display= "inline-block";
  document.getElementById('producttype1').setAttribute("disabled","");
      document.getElementById('producttype2').style.display= "none";
      document.getElementById('producttype2').setAttribute("disabled","");
}

    ;}
var loadFile = function(event) {
	var image = document.getElementById('output3');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
     <?php include 'navigation.php'?>
     
     <section class="editform" id="editform">
  <div class="form container edit">
  <h1> Add New Product</h1>
   <form method="post" action="" name="addproduct"  enctype="multipart/form-data"><?php /*onsubmit="return validateForm()"*/?>
   
   
        
   <label for="file" style="cursor: pointer;">Choose Product Picture</label><br>
   <label for="file" > <img id="output3" src="images/noprofile.png"></label><br>
       <input type="file"  accept="image/*" name="uploadfile" id="file" style="display: none;" onchange="loadFile(event)"><br>

       <label for="productname">Product Name </label><span class="error" ><?=$productnameErr?></span><br>
       <input type="text" name="productname"  placeholder="Product Name" id="productname"  ><br>

       <label for="price">Price</label><spam class="error"><?=$priceErr?></spam><br>
       <input type="number" name="price" placeholder="Enter your Price"  id="price"><br>

       <label for="stock">Stock (In kg) </label><spam class="error"><?=$stockErr?></spam><br>
       <input type="number" name="stock" placeholder="Enter your current stock"  id="stock"><br>
       
<span class="categorybar">
       <label for="category">Category </label><span class="error" ><?=$categoryErr?></span><br>
       <select name="category" id="selectcategory2" onclick="defproduct()" id="selectcategory2">
        <option>None</option>
        <option>Vegetable</option>
        <option>Fruit</option>
</select>
</span>
<span class="typebar">
       <label for="producttype">Product Type </label><span class="error" ><?=$producttypeErr?></span><br>
       <select name="producttype"  id="producttype1" disabled><br>
       <?php
       $sql ="SELECT * FROM defproducts JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.CATEGORY = 'Vegetable'";
       $result=mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($result)){?>
       <option><?=$row['DEFPRODUCT_NAME']?></option>
       <?php }

?>
</select><br>
<select name="producttype"  id="producttype2" disabled><br>
       <?php
       $sql ="SELECT * FROM defproducts JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.CATEGORY = 'Fruit'";
       $result=mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($result)){?>
       <option><?=$row['DEFPRODUCT_NAME']?></option>
       <?php }

?>
</select><br>
       </span>

       <label for="productdescrpt">Product Description</label><span class="error"><?=$productdescrptErr?></span><br>
       <textarea  name="productdescrpt"  placeholder="Product Description"  id="productdescrpt" row="5"><?=$productdescrpt?></textarea><br>

       <a href="mystore.php"><button type="button" class="cancel formbtn">Cancel</button></a>
    <button type="submit" class="formbtn" value="signup" name="add">Submit</button>
       </form>
       </div>
       </body>
       </html>
<?php }elseif(isset($_GET['delete'])){

$delete ="DELETE FROM products WHERE PRODUCT_ID = '$_GET[delete]'";
$result = mysqli_query($conn,$delete);
if($result){
    header("Location:mystore.php?deletesuccess");
    die;
}else{
    header("Location:mystore.php?deletefail");
    die;
}
}elseif(isset($_GET['PRODUCT_ID'])){
    $sql="SELECT * FROM products JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE products.PRODUCT_ID = '$_GET[PRODUCT_ID]'";
    $result=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_assoc($result)){
     $initialpic = $row['PRODUCT_IMG'];   
     $productpic = $row['PRODUCT_IMG'];
    $productname = $row['PRODUCT_NAME'];
    $category = $row['CATEGORY'];
    $producttype = $row['DEFPRODUCT_NAME'];
     $price = $row['PRICE'];
      $stock = $row['STOCK'];
      $productdescrpt = $row['PRODUCT_DESCRYPT'];
}

    $notification = '';
        $productnameErr = $categoryErr = $producttypeErr = $priceErr = $stockErr = $productdescrptErr = '';
    if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['edit'])){
    
            if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
                $filename = $_FILES["uploadfile"]["name"];
                $tempname = $_FILES["uploadfile"]["tmp_name"];    
                 $folder ="images/".$filename;
                 move_uploaded_file($tempname, $folder);
                 $productpic = $filename;
            }else{
                $productpic = $initialpic;
            }
           
            if(isset($_POST["productname"])){
                $productname=$conn -> real_escape_string($_POST["productname"]);
                
                if(empty($_POST["productname"])){
                $productnameErr = "product Name is required";
                unset($_POST["productname"]);
            }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["productname"])){
            $productnameErr = "Only letters allowed";
            unset($_POST["productname"]);}
        }else{ 
        $productnameErr = "product Name is required";
        }
    
        if(isset($_POST["category"])){
            $category= $_POST["category"];
           }else{
            $categoryErr = "Category is required";
        } if(isset($_POST["producttype"])){
            $producttype= $_POST["producttype"];
           }else{
            $producttypeErr = "Choose a product type";
        }if(isset($_POST['price'])){
            $price = $_POST['price'];
            if(empty($_POST["price"]) || $_POST["price"] == 0 ){
                $priceErr = "Price is required";
                unset($_POST["price"]);
            }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["price"])){
                $priceErr = "Numbers only";
                unset($_POST["price"]);
            }}else{
                $priceErr = "Price is required"; 
            }if(isset($_POST['stock'])){
                $stock = $_POST['stock'];
                if(empty($_POST["stock"]) || $_POST["stock"] == 0 ){
                    $stockErr = "Stock is required";
                    unset($_POST["stock"]);
                }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["stock"])){
                    $stockErr = "Numbers only";
                    unset($_POST["stock"]);
                }}else{
                    $stockErr = "Stock is required"; 
                }
                if(isset($_POST["productdescrpt"]) || empty($_POST['productdescrpt'])){
                    $productdescrpt= $_POST["productdescrpt"];
                   }else{
                    $productdescrptErr = "Product Description is required";
                } 
        if($productnameErr == '' and $categoryErr == '' and $producttypeErr == '' and $priceErr == '' and $stockErr == '' and  $productdescrptErr == ''){
          
                $sql="SELECT DEFPRODUCT_ID FROM defproducts WHERE DEFPRODUCT_NAME = '$producttype'";
                $result =mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($result)){
                   
                $insert = "UPDATE products SET DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]',PRODUCT_NAME = '$productname',PRODUCT_IMG = '$productpic',PRICE = '$price',STOCK = '$stock',PRODUCT_DESCRYPT = '$productdescrpt' WHERE PRODUCT_ID='$_GET[PRODUCT_ID]'";
                $result1 = mysqli_query($conn, $insert);
                if($result1){
                    header("Location:mystore.php?updatesuccess");
                die(); 
            }else{
                    $notification = "systemerror";
                }
            
            }
        }}
        include 'notification.php';
    


    
?>
<!DOCTYPE html>
<html>
    <head>
    
     <title>Edit Product</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="register.css">
      <link rel="stylesheet" type="text/css" href="style.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
     <script>
function validateForm() {
  if (document.getElementById("productname").value == '') {
    alert("Product Name must be filled out");
    return false;
  }else if (document.getElementById("lastname").value == '') {
    alert("Last Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if (document.getElementById("telnumber").value == '') {
    alert("Mobile Number must be filled out");
    return false;
  }else if (document.getElementById("address").value == '') {
    alert("Address must be filled out");
    return false;
  }else if (document.getElementById("companyname").value == '') {
    alert("Company Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if(document.getElementById("password").value == '') {
    alert("Password must be filled out");
    return false;
  }else if(document.getElementById("reppassword").value == '') {
    alert("Please Confirm Your Password");
    return false;
  }
}
function defproduct(){
    if(document.getElementById('selectcategory2').value == "Vegetable") {
      document.getElementById('producttype1').style.display= "inline-block";
      document.getElementById('producttype1').removeAttribute("disabled");
      document.getElementById('producttype2').style.display= "none";
      document.getElementById('producttype2').setAttribute("disabled","");
}else if(document.getElementById('selectcategory2').value == "Fruit"){ 
  document.getElementById('producttype2').style.display= "inline-block";
  document.getElementById('producttype2').removeAttribute("disabled");
  document.getElementById('producttype1').style.display= "none";
  document.getElementById('producttype1').setAttribute("disabled","");
}else {
  document.getElementById('producttype1').style.display= "inline-block";
  document.getElementById('producttype1').setAttribute("disabled","");
      document.getElementById('producttype2').style.display= "none";
      document.getElementById('producttype2').setAttribute("disabled","");
}

    ;}
var loadFile = function(event) {
	var image = document.getElementById('output3');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
   
     
     <section class="editform" id="editform">
  <div class="form container edit">
  <h1> Edit Product</h1>
   <form method="post" action="" name="addproduct"  enctype="multipart/form-data"onsubmit="return validateForm()">
   
   
        
   <label for="file" style="cursor: pointer;">Choose Product Picture</label><br>
   <label for="file"><img id="output3" src="images/<?=$productpic?>"></label><br>
       <input type="file"  accept="image/*" name="uploadfile" id="file" style="display: none;" onchange="loadFile(event)">

       <label for="productname">Product Name </label><span class="error"><?=$productnameErr?></span><br>
       <input type="text" name="productname"  placeholder="Product Name" id="productname" value='<?=$productname?>' ><br>

       <label for="price">Price</label><spam class="error"><?=$priceErr?></spam><br>
       <input type="number" name="price" placeholder="Enter your Price"  id="price" value="<?=$price?>"><br>

       <label for="stock">Stock(In kg) </label><spam class="error"><?=$stockErr?></spam><br>
       <input type="number" name="stock" placeholder="Enter your current stock"  id="stock" value="<?=$stock?>"><br>
<span class="categorybar">
       <label for="category">Category </label><span class="error" ><?=$categoryErr?></span><br>
       <select name="category" id="selectcategory2" onclick="defproduct()">
        <option>None</option>
        <option <?php if($category == 'Vegetable'){echo "selected";}?>>Vegetable</option>
        <option <?php if($category == 'Fruit'){echo "selected";}?>>Fruit</option>
</select><br>
</span>

<span class="typebar">
       <label for="producttype"> Product Type </label><span class="error" ><?=$producttypeErr?></span><br>
       <select name="producttype"  id="producttype1" disabled><br>
       <?php
       $sql ="SELECT * FROM defproducts JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.CATEGORY = 'Vegetable'";
       $result=mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($result)){?>
       <option <?php if($producttype == $row['DEFPRODUCT_NAME']){echo "selected";}?>><?=$row['DEFPRODUCT_NAME']?></option>
       <?php } ?>
      </select><br>
      <select name="producttype"  id="producttype2" disabled><br>
      <?php 
       $sql ="SELECT * FROM defproducts JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.CATEGORY = 'Fruit'";
       $result=mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($result)){?>
       <option <?php if($producttype == $row['DEFPRODUCT_NAME']){echo "selected";}?>><?=$row['DEFPRODUCT_NAME']?></option>
       <?php }

?>

</select><br>
       </span>
      

       <label for="productdescrpt">Product Description</label><span class="error"><?=$productdescrptErr?></span><br>
       <textarea  name="productdescrpt"  placeholder="Product Description"  id="productdescrpt" row="5"><?=$productdescrpt?></textarea><br>

       <a href="mystore.php"><button type="button" class="cancel formbtn">Cancel</button></a>
    <button type="submit" class="formbtn"  name="edit">Submit</button>
       </form>
       </div>
       </body>
       </html>
<?php }else{
    header("Location:index.php");
    die;
}
