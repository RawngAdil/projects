<?php 
session_start();
require 'connect.php';
 ?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
   <link rel="stylesheet" href="about.css" /> 
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL Platform</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="index.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
            
             <!-- For The Visters -->
             <?php if (!isset($_SESSION['email'])) {?>
                 <div class="signup"><a href="register.php" >Sign Up</a></div>
            <div class="log"> <a href="login.php" >Login</a></div>
            <?php  } ?>
             <!-- For The Users -->
             <?php if (isset($_SESSION['email'])) {?>
                 <div class="log"> <a href="logout.php" >Logout</a></div>
             
                 
           <?php  } ?>  
            	
             
     		<a href="courses.php">Courses</a>
             <a class="active" href="about.html" >About Us</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search" action="courses.php" method="get">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>

 <main>
 	<section>
  <h1>About WDPL </h1>

  <p>
  	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam,
  	quis nostrud exercitation <br>
  	 ullamco laboris nisi ut aliquip ex ea commodo
  	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
  	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
  	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
  </p>
  <div class="aboutlogo"><img src="Logo.png" alt="WDPL logo"></div>

</section>

<section >
    <h1 class="story">Our Story</h1>
    <h2 class="fromAtoZ">From experiment to global movement</h2>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Excepturi, sunt officia quo earum id hic ipsum molestiae sequi possimus nemo laboriosam dolorem perferendis ullam voluptate eos facere accusantium? Quasi, nesciunt!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sequi reprehenderit, quod cupiditate voluptas nostrum, placeat atque vitae ut porro dolorem neque debitis sunt quisquam nam, perferendis illo quis adipisci nesciunt!
    </p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis cum quaerat nam molestias maxime iure ipsum dolor iste dolorum ex saepe tenetur, asperiores nihil voluptatem amet minima adipisci nisi suscipit!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum modi saepe dignissimos odit ratione cum quisquam, iure, laudantium illo similique vel eum magni? Accusantium cumque dignissimos optio, itaque pariatur ea.
    </p>
</section>
<section>    
   <h1>Our mission </h1>
   <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Necessitatibus maxime ipsum natus, reiciendis aliquam nobis ea doloribus quod voluptatum sint enim. Pariatur veritatis illum laboriosam dolores velit molestiae possimus mollitia</p>
  <ul>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur </li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  	<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio accusantium porro harum pariatur alias error tenetur atque obcaecati reprehenderit. Enim inventore consectetur</li>
  

  </ul>
</section>

<section>
	 <h1>Timeline</h1>

	 <h2>2015</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>

	 <h2>2017</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>

	 <h2>2019</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
     <h2>2021</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
     <h2>2022</h2>
	 <p>
	 	Lorem ipsum dolor sit amet, consectetur adipisicing elit <br>
  	sed do eiusmod
  	tempor incididunt ut labore et dolore magna aliqua <br>
  	 Ut enim ad minim veniam
	 </p>
</section>

</main>
  

     	<div class="mainfooter">
          
           <!-- contact -->
           <section class="aboutcontact">
                 <h4 class="sectionhead">Contact Us in:</h4>
                 <div class="aboutsocial">
                 <span class="cell">  <!--  <img src="" alt="phone icon">--> <span class="icon"><i class="fa fa-phone"></i></span> <a href="">+xxx xxxx xxx</a></span>
                 <span class="cell"> <!-- <img src="" alt="mail icon"> --> <span class="icon"><i class="fa-regular fa-envelope"></i></span> <a href="mailto:email@example.com">email@example.com</a></span>
                  <p>Or Follow us Now and Get All The News!</p> 
                  <span class="cell" ><!-- <img src="" alt="facebook icon">--> <span class="icon"><i class="fa-brands fa-facebook-square"></i></span> <a href="@somefacbookacount">@somefacbookacount</a></span>
                  <span class="cell"><!--  <img src="" alt="YouTube icon">--> <span  class="icon"><i class="fa fa-youtube"></i></span> <a href="#someyoutubecannel">#someyoutubecannel</a> </span>  
                 		   </div>
                
                
         </div>
     		  
         <footer>
     	</section>
     	<!-- copyrights and some quote -->
     	<section class="rights">
     		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
     		<p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
     	</section>
     </footer>

    </article>

</body>
</html>