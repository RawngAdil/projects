<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location:adminlogin.php");
}
require 'connect.php';
?>
<!DOCTYPE html>
<html>

<head>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Cookie&family=Fredericka+the+Great&family=Great+Vibes&family=Henny+Penny&family=Merienda&family=Monoton&family=Playball&family=Rubik+Glitch&family=Rubik+Moonrocks&family=Rubik+Wet+Paint&family=Tangerine&family=Tapestry&family=Yellowtail&display=swap');
        * {
            box-sizing: border-box;
            margin: 0 ;
            padding: 0;
            
        }
      

        body {
            margin:0;
            font-family:  sans-serif;
            font-size:18px;
            color:#000000;
            background-image:url("IU5e.gif");
            background-position: center ;
	        background-repeat: no-repeat;
	        background-attachment: fixed;
	        background-size: cover;
            font-weight:bold;

        }

        .container {
            width: 90%;
            margin: 2% auto;
           
            padding: 16px 5px 16px 5px;
    background: radial-gradient(circle,rgba(225, 207, 207, 0.59),  rgba(29, 1, 1, 0.623));
    margin: 3% 4.5% 1% 4.5%;
    border-radius: 12px
            
        }

        .topnav {
            overflow: hidden;
            background: radial-gradient(circle, rgba(84, 63, 63, 0.575),  rgba(29, 1, 1, 0.623));
            width: 95%;
            margin:0 5px 7px 30px;
	 border-radius: 12px;
        }

        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
            font-family: 'Tapestry';
        }

        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        .topnav a.active {
            background-color:rgb(97, 17, 17);
            color: white;
        }

        #admin {
            margin-top:2%;
            margin-bottom:2%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;
            font-family: 'Merienda';
            font-weight:bold;
           
            

        }

        #admin td,
        #admin th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            
            padding: 8px;
        }

        #admin tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
        }
        

        #admin tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #admin th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
        
        }
        h1{
          
            color:rgb(97, 17, 17);
            text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
            font-family: 'Tapestry';
	     text-align:center;
    
    margin: 2% auto;
        }
        #add{
            background-color: rgb(97, 17, 17);
            width: 10%;
            height: 9%;
            color: white;
            text-align:center;
            border-radius:17px;
            padding: 5px 8px 5px 8px ;
            font-size:15px;
            position: absolute;
            right: 7%;
            top:20%;
            border: none;
        cursor: pointer;
        opacity: 0.8;
        }
        #add:hover{
            opacity: 1;
        }
    </style>
</head>

<body>



    <div class="topnav">
        <a href="index.php">Users</a>
        <a  class="active" href="admins.php">Admins</a>
        <a href="books.php">Books</a>
        <a href="categories.php">Categories</a>
        <a href="subcategories.php">Subcategories</a>
        <a href="#bookorders">Book Orders</a>
        <a href="logout.php">Logout</a>
    </div>
    
    <div class="container">
    <a href="addadmin.php" ><button id="add" type="button">Add Admin </button></a>
        <h1>Admins</h1>
        <?php
        $sql = "SELECT * FROM admins";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        ?>

            <table id="admin">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>Remove Admin</th>

                </tr>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['Name'] ?></td>
                        <td><?=$row['Email']?></td>
                        <td><?=$row['phone']?></td>
                        <td><?=$row['country']?></td>
                        <td><?=$row['city']?></td>
                        
                        <form action="deleteadmin.php" method="GET"  id="delete">
                        <td><a onclick="return confirm('Are you sure you want to delete this admin?')"
                         href="deleteadmin.php?id=<?php echo $row['id']; ?>">
                        <?=$row['Delete']?></a></td> 
                </form>
                        
                    </tr>
                <?php } ?>
            </table>
        <?php  } else {
            echo '<span class="err">No Rows</span>';
        } ?>
    </div>
</body>

</html>