<?php
session_start();
require 'connect.php';
$name= $email= $phone= $country= $city= '';
 $name_err= $email_err=  $exist_err = $repeat_err =
 $phone_err= $country_err= $city_err= $success = $fail = '';  

 if ($_SERVER['REQUEST_METHOD'] == 'POST') {
     if(isset($_POST["name"])){
         $name=$_POST["name"];
         if(empty($_POST["name"])){
             $name_err="Name is required ";
             unset($_POST["name"]);
         }
         elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["name"])){
             $name_err="Only letters allowed ";
             unset($_POST["name"]);
         }
     }
     if(isset($_POST["email"])){
         $email=$_POST["email"];
         if(empty($_POST["email"])){
             $email_err="Email is required";
         }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err = "Invalid email";
            unset($_POST["email"]);
        }
     }
     if(isset($_POST["phone"])){
         $phone=$_POST["phone"];
         if(empty($_POST["phone"])){
            $phone_err="Phone number is required";
         }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["phone"])){
             $phone_err="Only number is allowed";
         }
     }
     if(isset($_POST["country"])){
        $country=$_POST["country"];
        if(empty($_POST["country"])){
            $country_err="Country is required ";
            unset($_POST["country"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["country"])){
            $country_err="Only letters allowed ";
            unset($_POST["country"]);
        }
      }
      if(isset($_POST["city"])){
        $city=$_POST["city"];
        if(empty($_POST["city"])){
            $city_err="City is required ";
            unset($_POST["city"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["city"])){
            $city_err="Only letters allowed ";
            unset($_POST["city"]);
        }
    

     if ($_POST['password'] != $_POST['psw-repeat']) {
        $repeat_err = '<span class="error">Password does not match with confirm</span>';
     } else {
        $sql = "SELECT * FROM admins WHERE email = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $exist_err = '<span class="error">Email already exists</span>';
            } elseif($name_err=='' and $email_err==''and  $repeat_err =='' and
            $phone_err=='' and $country_err=='' and  $city_err=='') {
                $sql = "INSERT INTO admins ( name, email, password, phone, country, city ) VALUES ( '$_POST[name]', '$_POST[email]', '$_POST[password]' , '$_POST[phone]' , '$_POST[country]' , '$_POST[city]')";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $success = ' 1 admin added successfuly';
                   header("Location:admins.php");
                    
                } else {
                    $fail = '<span class="err">Failed to add admin</span>';
                }
            }
        }
     }
    }
 }
  


?>
<!DOCTYPE html>
<html>
<style>
     <?php include 'style.css' ?>
</style>

<body>

    <?= $success ?><?= $fail ?>
    <form action="addadmin.php" method="post">

        <div class="container">
            <h1>Add Admin</h1>
           
            <div class="hrl"> </div>

            <label for="name"><b>Name</b></label> <span class="error"> <?=$name_err?></span><br>
            <input type="text" placeholder="Enter Name" name="name" id="name" required>

            <label for="email"><b>Email</b></label><span class="error"> <?=$email_err?></span><br><span class="error"> <?= $exist_err ?></span><br>
            <input type="text" placeholder="Enter Email" name="email" id="email" required>
           
            <label for="password"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="password" required>

            <label for="psw-repeat"><b>Confirm Password</b></label><span class="error"> <?=$repeat_err ?></span><br>
            <input type="password" placeholder="Confirm Password" name="psw-repeat" required>
           
            <label for="phone"><b>Phone Number</b></label><span class="error"> <?=$phone_err?></span><br>
            <input type="int"   placeholder="Enter Phone Number" name="phone" required>

            <label for="country"><b>Country</b></label><span class="error"> <?=$country_err?></span><br>
            <input type="text"  placeholder="Enter Country" name="country"  required>

            <label for="city"><b>City</b></label><span class="error"> <?=$city_err?></span><br>
            <input type="text" placeholder="Enter City" name="city" required>

            <div class="clearfix">
                <a href="admins.php"><button type="button" class="cancel">Cancel</button></a>
                <button type="submit" class="submit">Add </button>
            </div>
        </div>
    </form>

</body>

</html>