<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die;
}
if(isset($_SESSION['ROLE'])){
    if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){
     header("Location:admin.php");
            die;   
    }
  }
$firstname = $email = $lastname = $telnumber = $address = $companyname = $password = $reppassword = $storename = $storedescrpt = '';
$firstnameErr = $emailErr = $lastnameErr = $telnumberErr = $addressErr = $companynameErr = $passwordErr = $reppasswordErr = $storenameErr = $storedescrptErr = '';
$sql="SELECT * FROM users WHERE USER_ID ='$_SESSION[ID]'";
$result=mysqli_query($conn,$sql);
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])){
    if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
        $filename = $_FILES["uploadfile"]["name"];
       $tempname = $_FILES["uploadfile"]["tmp_name"];    
        $folder = $filename;
        move_uploaded_file($tempname, $folder);
    $profilepic = $filename; }else{
        while($row = mysqli_fetch_assoc($result)){
            $profilepic = $row['PROFILE_PIC'];
        }
        }
    
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$firstnameErr = "First Name is required";
}
if(isset($_POST["lastname"])){
    $lastname=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$lastnameErr = "Last Name is required";
}
$sqlemail = "SELECT EMAIL FROM users WHERE USER_ID = '$_SESSION[ID]'";
$result = mysqli_query($conn,$sqlemail);
while($row = mysqli_fetch_assoc($result)){
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif($email !== $row['EMAIL']){
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}}else{
    $emailErr = "Email is required";
}}if(isset($_POST["telnumber"])){
    $telnumber = $_POST['telnumber'];
    if(empty($_POST["telnumber"])){
        $telnumberErr = "Phone Number is required";
        unset($_POST["telnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
        $telnumberErr = "Numbers only";
        unset($_POST["telnumber"]);
    }elseif(strlen($_POST["telnumber"])!=10){
        $telnumberErr = "Invalid Phone Number";
        unset($_POST["telnumber"]);
    }
    }else{
        $telnumberErr = "Phone Number is required";
    }if(isset($_POST['address'])){
    $address = $_POST['address'];
    if(empty($_POST['address'])){
        $addressErr= "Address is Required";
        unset($_POST['address']);
    }
    }else{
    $addressErr= "Address is Required";  
    }
    if($_SESSION['ROLE'] == 'Customer'){
    if(isset($_POST['companyname'])){
        $companyname = $_POST['companyname'];
        if(empty($_POST['companyname'])){
            $companynameErr= "Company Name is Required";
            unset($_POST['companyname']);
        }
    }else{
        $companynameErr= "Company Name is Required";  
    }
}elseif($_SESSION['ROLE'] == 'Supplier'){
    if(isset($_POST['storename'])){
        $storename = $_POST['storename'];
        if(empty($_POST['storename'])){
            $storenameErr= "Store Name is Required";
            unset($_POST['storename']);
        }
    }else{
        $storenameErr= "Store Name is Required";  
    }
    if(isset($_POST['storedescrpt'])){
        $storedescrpt = $_POST['storedescrpt'];
        if(empty($_POST['storedescrpt'])){
            $storedescrptErr= "Store Description is Required";
            unset($_POST['storedescrpt']);
        }
    }else{
        $storedescrptErr= "Store Description is Required";  
    }

}
    if(!(empty($_POST['password']) && empty($_POST['reppassword']))){
    if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppassword'])){
    $reppassword = $_POST['reppassword'];
    if(empty($_POST['reppassword'])){
        $reppasswordErr = "Repeat your Password";
        unset($_POST['reppassword']);
    }elseif($_POST['reppassword'] !== $password){
        $reppasswordErr = "The passwords dont match";
        unset($_POST['reppassword']);
    }
}else{
    $reppasswordErr = "Repeat your Password";
}}else{
    $passwordErr = $reppasswordErr = '';
    
}
if($firstnameErr == ''  and  $emailErr == '' and  $lastnameErr == '' and $passwordErr == '' and $reppasswordErr == '' and  $telnumberErr == '' and 
$addressErr == '' and $companynameErr == '' and $storenameErr == '' and $storedescrptErr == ''){
    if(!(empty($_POST['password']) && empty($_POST['reppassword']))){
    $insert = "UPDATE users SET PROFILE_PIC ='$profilepic',FIRST_NAME = '$firstname' ,LAST_NAME ='$lastname' ,EMAIL = '$email' ,
    MOBILE_NO ='$telnumber',ADDRESS = '$address' ,PASSWORD = '$password' WHERE USER_ID = '$_SESSION[ID]'";}else{
        $insert = "UPDATE users SET PROFILE_PIC ='$profilepic',FIRST_NAME = '$firstname' ,LAST_NAME ='$lastname' ,EMAIL = '$email' ,
        MOBILE_NO ='$telnumber',ADDRESS = '$address' WHERE USER_ID = '$_SESSION[ID]'";
    }
    $result1 = mysqli_query($conn, $insert);
    if($result1){header("Location:profile.php?profileeditsuccess");
    die(); }else{
        $notification = "systemerror";
    }}else{
        $notification = "error";
        

    }}?>
    <!DOCTYPE html>
<html>
 
    <head>
     <title>Edit Profile</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="register.css">
      <script>
function validateForm() {
  if (document.getElementById("firstname").value == '') {
    alert("First Name must be filled out");
    return false;
  }else if (document.getElementById("lastname").value == '') {
    alert("Last Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if (document.getElementById("telnumber").value == '') {
    alert("Mobile Number must be filled out");
    return false;
  }else if (document.getElementById("address").value == '') {
    alert("Address must be filled out");
    return false;
  }else if (document.getElementById("companyname").value == '') {
    alert("Company Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }
}

var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>

    <?php 
    if($_SESSION['ROLE'] == 'Supplier'){
    $sql = "SELECT * FROM users JOIN stores ON stores.SUPPLIER_ID = users.USER_ID WHERE USER_ID = '$_SESSION[ID]'";
    $result = mysqli_query($conn,$sql);
    }else{
        $sql = "SELECT * FROM users WHERE USER_ID = '$_SESSION[ID]'";
        $result = mysqli_query($conn,$sql);
    }
    while($row = mysqli_fetch_assoc($result)){?>

  <section class="editform" id="editform">
  <div class="form container edit">
   <h1> Edit Profile</h1>
   <form method="post" action="" name="editform" onsubmit="return validateForm()" enctype="multipart/form-data">
 
       <label for="file" style="cursor: pointer;">Choose Profile Picture</label><br>
       <div class="image-cropper">
       <label for="file" ><img id="output" src="images/<?=$row['PROFILE_PIC']?>" /><label><br>
</div>
       <input type="file"  accept="image/*" name="uploadfile" id="file" style="display: none;" onchange="loadFile(event)">

       <label for="firstname">First Name </label><span class="error" ><?= $firstnameErr?></span><br>
       <input type="text" name="firstname"  placeholder="First Name" id="firstname"  value="<?=$row['FIRST_NAME']?>"><br>

       <label for="lastname">Last Name </label><span class="error" ><?= $lastnameErr?></span><br>
       <input type="text" name="lastname"  placeholder="Last Name" id="lastname"  value="<?=$row['LAST_NAME']?>"><br>

       <label for="email">Email </label><span class="error" ><?= $emailErr?></span><br>
       <input type="text" name="email"  placeholder="Email address" id="email"  value="<?=$row['EMAIL']?>"><br>

       <label for="telnumber">Mobile Number </label><spam class="error"><?= $telnumberErr?></spam><br>
       <input type="text" name="telnumber" placeholder="Enter your mobile number" value="0<?=$row['MOBILE_NO']?>" id="telnumber"><br>

       <label for="address">Address </label><spam class="error"><?= $addressErr?></spam><br>
       <input type="text" name="address" placeholder="Enter address of current residency" value="<?=$row['ADDRESS']?>" id="address"><br>
<?php if($_SESSION['ROLE'] == 'Customer'){?>
       <label for="companyname">Company Name</label><span ><?= $companynameErr?></span><br>
       <input type="text" name="companyname"  placeholder="Company Name"   value="<?=$row['COMPANY_NAME']?>" id="companyname" <?php if($_SESSION['ROLE'] !== 'Customer'){echo "disabled";}?>><br>
<?php }elseif($_SESSION['ROLE'] == 'Supplier'){?>
       <label for="storename">Store Name</label><span ><?= $storenameErr?></span><br>
       <input type="text" name="storename"  placeholder="Store Name"   value="<?=$row['STORE_NAME']?>" id="storename" <?php if($_SESSION['ROLE'] !== 'Supplier'){echo "disabled";}?>><br>

       <label for="storedescrpt">Store Description</label><span class="error"><?=$storedescrptErr?></span><br>
       <textarea  name="storedescrpt"  placeholder="Store Description"  id="storedescrpt" row="5" <?php if($_SESSION['ROLE'] !== 'Supplier'){echo "disabled";}?>><?=$row['STORE_DESCRIPTION']?></textarea><br>

<?php }?>
       <label for="password">Change Password(leave pasword fields empty if you do not want to change)</label><span ><?= $passwordErr?></span><br>
       <input type="password" name="password"  placeholder="Password" id="password"><br>

       <label for="reppassword"> Repeat New Password </label><span ><?= $reppasswordErr?></span><br>
       <input type="password" name="reppassword" id="reppassword" placeholder="Repeat your password"><br>

       <a href="profile.php"><button type="button" class="cancel formbtn">Cancel</button></a>
    <button type="submit" class="formbtn" value="signup" name="signup">Submit</button>


 
   </form>
</div>
</section> 
<?php }?>