<?php 
session_start();
require 'connect.php';

if($_SESSION['role']==2){
    header("Location:admin.php");
       die();
 }
 
 error_reporting(0);

  $comt = $comterr =$email = $emailErr ='';
  if($_SERVER['REQUEST_METHOD'] == "POST"){

  if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]); 
    }}

if(isset($_POST["comt"])){
        $comt=$_POST["comt"];
        if(empty($_POST["comt"])){
        $comterr = "This field is required";
        unset($_POST["comt"]);}
}

if ($comterr=='' && $emailErr=='') {
   $sql = "SELECT * FROM users WHERE email = '$email'";
   $result = mysqli_query($conn,$sql);
   $user= mysqli_fetch_assoc($result);
   $id = $user['user_id'];


   $insert = "INSERT INTO reviews (comment , user_id) VALUES ('$comt', '$id')";
   $result2 =mysqli_query($conn,$insert);
} }
 ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" type="text/css" href="add.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="index.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
             <!-- For The Visters -->
             <?php if (!isset($_SESSION['email'])) {?>
                 <div class="signup"><a href="register.php" >Sign Up</a></div>
            <div class="log"> <a href="login.php" >Login</a></div>
            <?php  } ?>
             <!-- For The Users -->
             <?php if (isset($_SESSION['email'])) {?>
                 <div class="log"> <a href="logout.php" >Logout</a></div>
             
                 
           <?php  } ?>  
            
            	
             
     		<a href="courses.php">Courses</a>
             <a href="about.php">About Us</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search" action="courses.php" method="get">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>


       <main>
           
       <div class="jumbotron">

       <div class="overlay">
               	 <!-- jumbotron -->
     <section>
         <h2 class="jumbheader">Learn Without Limits</h2>
        <p class="p1">
              Lorem ipsum dolor sit aftmeht,  sed do eiusmod
            tempor incididunt ut laborggbe et doghhlore magna.
         </p>

         <p>Learning is The Key To Success,<br>
            It's Time to Start <span class="now">Now!</span>! 
         </p>
         <div class="btns"><button  class="primarybtn"><a href="courses.php">Pick a course</a></button><span class="or">OR</span><span class="secondarybtn"><a href="about.php">Discover More</a></span>
        </div>
    </section>
  
       </div>
       <div class="jumbimg">
        <img src="95116-coder.gif" alt="image">
    </div>
       </div>
       
    
     <!-- Courses Examples -->

     <section>
     	<!-- Most Popular -->
     	<section >
     		 <h2 class="sectionhead">Some Of Our Popular Courses</h2>

             <section class="popular">

               <?php
    require 'connect.php'; 
                $sql = "SELECT * FROM courses ORDER BY course_id DESC LIMIT 6 ";
                $result = mysqli_query($conn ,$sql) ; 
                    if (mysqli_num_rows($result) >0) {
             while ($row = mysqli_fetch_assoc($result)) { ?>

                  <article class="course">
                    
                  <img src="concept-construction-page-site.jpg" alt="course image" class="img1" width="33%"> 
                    <img src="20220531_194240_0000.png" alt="course image"  class="img2" width="33%"> 
                  <div class="content"> 
                       <h3 class="coursename"><?=$row['course_name']?></h3>
                    <p class="courseDesc">
                        <?=substr($row['description'],0,50)?>
                    </p>
                    <button class="viewbtn"><a href="course.php?course_id=<?=$row['course_id']?>">View Course</a></button>
                </div>
                </article>
                 <?php  }} ?>
                </section>

                    <button  class="viewmore"><a href="courses.php">Explore more</a></button>
                 </section>
     
     	<!-- Courses' Offers -->
     	<section class="offers">
            <h2 class="sectionhead">This Month Offers!</h2>

           <section class="ouroffers">
             <?php
    require 'connect.php'; 
                $sql = "SELECT * FROM courses LIMIT 3 ";
                $result = mysqli_query($conn ,$sql) ; 
                    if (mysqli_num_rows($result) >0) {
             while ($row = mysqli_fetch_assoc($result)) { ?>

                  <article class="course">
                    
                  <img src="concept-construction-page-site.jpg" alt="course image" class="img1" width="33%"> 
                    <img src="20220531_194240_0000.png" alt="course image"  class="img2" width="33%"> 
                  <div class="content"> 
                       <h3 class="coursename"><?=$row['course_name']?></h3>
                    <p class="courseDesc">
                        <?=substr($row['description'],0,50)?>
                    </p>
                    <button class="viewbtn"><a href="course.php?course_id=<?=$row['course_id']?>">View Course</a></button>
                </div>
                </article>
                 <?php  }} ?>
           </section>
              
                              
           <button  class="viewmore"><a href="courses.php">Explore more</a></button>
     	</section>
     	
     </section>
  
     <!-- some reviews -->
     <section class="reviwes">
        <section class="studentsReviews">
            <h2 class="sectionhead">What Our Students Say?</h2>
            <?php 
     $sql = "SELECT * FROM reviews ORDER BY comment_id DESC LIMIT 4";
   $result = mysqli_query($conn,$sql);
       while ($comment = mysqli_fetch_assoc($result)) {
          
          $sql2 = "SELECT * FROM users WHERE user_id = '$comment[user_id]'";
   $result2 = mysqli_query($conn,$sql2);
   $user = mysqli_fetch_assoc($result2);?>
 
            <article class="review">
                <h5 class="name"><?=$user['first_name']?>  <?=$user['last_name']?></h5>
                <q><?=$comment['comment']?></q>
            </article>
      <?php } ?> 
           
            <article class="review last">
                <h5 class="name">Ahmed Tibin </h5>
                <q>Lorem ipsum dolor sit, velit dolor sed libero porro magni? Culpa, commodi pariatur!</q>
            </article>
        </section> 
  
  <?php if (isset($_SESSION['email'])) {?>
      
 <section class="add">
  <button id="add" type="button"  onclick="AddFunction()">Add Review</button>
    <div id="addreview">
      <form action="" method="post">
             <label for="email">Enter Your Email</label><br>
             <input type="email" name="email" placeholder="Enter Your Email"><br>
             <span class="err"><?=$emailErr?></span><br>
            <label for="comt">Write A Comment</label><br>
            <textarea type="text" name="comt" id="comt" placeholder="Write Here"></textarea><br>
            <span class="err"><?=$comterr?></span>

            <button type="submit" id="send" >Send</button>
      </form>
      </div>
  </section>

  <script>
         function AddFunction(){
             var x = document.getElementById("addreview");
            
             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }
            }
    </script> 
<?php } ?>
       </main>

     <footer>
     	<div class="mainfooter">
             <!-- about us -->
         
     	
             <article class="aboutus">
                <h4 class="sectionhead">About Us</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. <br>
                
                </p>
           </article>
           <!-- contact -->
           <section class="contact">
                 <h4 class="sectionhead">Contact Us in:</h4>
                 <div class="social">
                 <span class="cell"> <span class="icon"><i class="fa fa-phone"></i></span> <a href="">+xxx xxxx xxx</a></span>
                 <span class="cell"><span class="icon"><i class="fa-regular fa-envelope"></i></span> <a href="mailto:email@example.com">email@example.com</a></span>
                  <p>Or Follow us Now and Get All The News!</p> 
                  <span class="cell" > <span class="icon"><i class="fa-brands fa-facebook-square"></i></span> <a href="@somefacbookacount">@somefacbookacount</a></span>
                  <span class="cell"> <span  class="icon"><i class="fa fa-youtube"></i></span> <a href="#someyoutubecannel">#someyoutubecannel</a> </span>
                 </div>
                
                
         </div>
     		  

     	</section>
     	<!-- copyrights and some quote -->
     	<section class="rights">
     		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
     		<p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
     	</section>
     </footer>

    </article>

</body>
</html>