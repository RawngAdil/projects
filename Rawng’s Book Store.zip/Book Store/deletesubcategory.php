<?php 
session_start();
$_SESSION['Subcategory_ID']=$_GET['Subcategory_ID'];
require 'connect.php';
$sql=" DELETE from subcategories WHERE Subcategory_ID='$_SESSION[Subcategory_ID]' ";
    $result = mysqli_query($conn, $sql); 
    if($result){
        $success ='<span class="success">1 Subcategory deleted successfuly</span>';
         header("Location:subcategories.php");
        echo $success;
    }
     else{
         $fail='<span class="err">Failed to delete </span>';}
 

 ?>