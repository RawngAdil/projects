<?php 
session_start();
if(!isset($_SESSION['email'])){
    header("Location:register.php");
    die();
}
 require 'connect.php';

 ?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>

    <article>

    	 <header>
     	<!-- The main navigation bar -->
         <button class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo"><a href="#"><img src="logo.png " alt="Logo" ></a></div>
     	<nav id="nav" class="mainNav">s
     		
             <!-- For The Visters -->
             <div class="signup"><a href="#" >Sign Up</a></div>
     	   <!-- For The Users -->
            <div class="log"> <a href="#" >Logoin</a></div>
            	
             
     		<a href="courses.php">Courses</a>
             <a href="about/php">About Us</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search">
     		<input type="search" name="search" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit" class="searchbtn" onclick="searchfunction()"><i class="fa fa-search"></i></button>
     	</form>

     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }
         }
         function searchfunction(){
             if (window.innerWidth<768){
                 document.location=document.location.toString().split('#')[0]+'#map';
                 return false;
             }
         }
     </script>