<?php
session_start();
require 'connect.php';
error_reporting(0);

if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
  header("Location:index.php");
 die();
}
$selecterr = '';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_GET['userid'])){
    if(!isset($_POST['orderid'.$_GET['userid']])){
          $selecterr ='choose orders first';
    }
    if($_POST['status'] !== 'Completed'){
    if(!empty($_POST['orderid'.$_GET['userid']]) && $selecterr == '') {
        foreach($_POST['orderid'.$_GET['userid']] as $orderid) {
                
                $update = "UPDATE orders SET STATUS = '$_POST[status]' WHERE ORDER_ID = '$orderid'";
                $result =mysqli_query($conn,$update);
                if(!$result){
                    echo "failed";
                }
        }
    }}else{
        foreach($_POST['orderid'.$_GET['userid']] as $orderid) {
        $update = "UPDATE orders SET STATUS = '$_POST[status]' WHERE ORDER_ID = '$orderid'";
        $result =mysqli_query($conn,$update);
        }
        if(!$result){
            echo "failed";
        }else{
        echo "works";
        $sql2 ="SELECT EMAIL FROM users WHERE USER_ID = '$_GET[userid]'";
        $result2 = mysqli_query($conn,$sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $to = $row2['EMAIL'];
        $subject = "Your Markazy Order";
        $headers =  'MIME-Version: 1.0' . "\r\n"; 
        $headers .= 'From: Markazy <malikanas553@gmail.com>' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";           
        $message = "
        <html>
        <head>
        <link href='https://fonts.googleapis.com/css?family=Merienda' rel='stylesheet'>
        <title>Book Order Bill</title>
        <script src='https://kit.fontawesome.com/526db9288e.js' crossorigin='anonymous'></script>
        <style>
        *{
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Merienda';
}
        div{
            background-color:#f9f9f9;
            width:100%;
            margin-bottom:30px;
        }
        img{
        margin-left:30%;
    width: 40%;
        }
        h1{
            margin-left:30%;
            width:45%;
            font-size:50px
        }
        table{
            margin-top: 30px;
            margin-bottom:30px;
            border-collapse: collapse;
            width: 96%;
           margin-left: 2%;
            position: relative;
            
            font-weight:bold;
        }
        table td,
        table th {
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            padding: 8px;
            font-size:25px;
        }
        
        table tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
        }
        
        table th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(29, 107, 29);
            color: white;
            text-shadow: 1px 1px 1px rgba(7, 7, 7, 0.874);
        }
        span{
            margin-left:2%;
            font-size:30px;
            font-weight:600;
        }
        footer{ 
    
    padding-top: 40px;
     margin-top: 10px;
       clear: both;
       position: absolute;
       bottom:0;
       width:100%;
     
   }


.rights{
    background: radial-gradient(circle, rgb(36, 112, 36) ,  rgb(22, 67, 22));
    font-family: 'Merienda';
    color: #f2f2f2;
   font-size: 20px;
    text-align: center;
    padding-top: 30px;
    padding-bottom: 10px;
    line-height: 15px;
   
}
.rights p{
    color: #f2f2f2;
}
.allrights, sup{
    color: #f2f2f2;
    font-size: 20px;
}
        </style>
        </head><body>";

        $sql4= "SELECT * FROM orders JOIN products ON orders.PRODUCT_ID = products.PRODUCT_ID 
        JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID 
        JOIN users ON orders.USER_ID = users.USER_ID WHERE orders.USER_ID = '$_GET[userid]' AND STATUS = 'Completed'";
        $result4 = mysqli_query($conn,$sql4);
        $sql5 = "SELECT SUM(products.PRICE) AS total_price FROM orders JOIN products ON products.PRODUCT_ID=orders.PRODUCT_ID WHERE USER_ID = '$_GET[userid]' AND STATUS = 'Completed'";
      $result5 = mysqli_query($conn,$sql5);
      $row3 = mysqli_fetch_assoc($result5);
      $number = $row3['total_price'];
      $sum = number_format((float)$number, 2, '.', '');
        $body = "<div><img src='https://i.ibb.co/wScSvNJ/logo.jpg'></div>";
        $body .= "<h1>Your Purchases:</h1>";
        $body .= "<table class='TFtable' border='1' style='width':100%>";
        $body .= "<tr><th>Product</th><th>Store</th><th>Amount</th><th>Price</th></tr>";
        while($row4 = mysqli_fetch_assoc($result4)) { 
        $body .= "<tr><td>".$row4['PRODUCT_NAME']."</td><td>".$row4['STORE_NAME']."</td><td>".$row4['AMOUNT']. "</td><td>".$row4['PRICE']."</td></tr>";
        }
        $body .="<tr><td></td><td></td><td></td><td>Total Price: ".$sum."</td></tr>";
        $body .= "</table><footer>
        <section class='rights'>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p><br><br>
            <p>All Rights reserved for <span  class='allrights'>Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>
</body></html>";
        $message .= $body;
        $message = wordwrap($message, 70);    
        if(mail($to,$subject,$message,$headers)){
        $sql = "DELETE FROM orders WHERE STATUS = 'Completed' AND USER_ID = '$_GET[userid]'";
        $result = mysqli_query($conn,$sql);
           header("Location:admin.php?mailsuccess");
           die;
        }else{
            echo "Couldnt send mail";
        }}
    }
        
    }?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php 
    
   

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin-Orders </title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css"> 
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>
<h1>Orders</h1>

<section class="nums">

    <section class="box">
        <?php 
            $sql3 = "SELECT * FROM orders WHERE STATUS ='Pending' ";
            $result3 = mysqli_query($conn,$sql3);
            $row3 = mysqli_num_rows($result3); 
            ?> 
              <h3> <?=$row3 ?> </h3>
              <h4>Products </h4>   
        </section>

       <section class="box">
        <?php 
            $sql4 = "SELECT * FROM orders WHERE  STATUS='Delivering'" ;
            $result4 = mysqli_query($conn,$sql4);
            $row4 = mysqli_num_rows($result4); 
            ?> 
               <h3> <?=$row4 ?> </h3>
               <h4>Orders</h4>   
        </section>

</section><hr>

       <?php 
        $sql = "SELECT * FROM `orders` JOIN users ON orders.USER_ID=users.USER_ID JOIN products ON orders.PRODUCT_ID=products.PRODUCT_ID WHERE NOT STATUS = 'Cart'";
        $result = mysqli_query($conn ,$sql);
    if ( mysqli_num_rows($result) > 0) {
       ?>
<?php
$sql = "SELECT DISTINCT orders.USER_ID,FIRST_NAME,LAST_NAME FROM orders JOIN users ON orders.USER_ID=users.USER_ID WHERE NOT STATUS = 'Cart' ORDER BY orders.USER_ID";
$result = mysqli_query($conn,$sql);
echo '<span class="error">'.$selecterr.'</span>';
while($row = mysqli_fetch_assoc($result)){?>
<h2><?=$row['USER_ID']?>.<?=$row['FIRST_NAME']?> <?=$row['LAST_NAME']?></h2>
<?php
$sql2 = "SELECT * FROM orders JOIN products ON orders.PRODUCT_ID=products.PRODUCT_ID WHERE NOT STATUS = 'Cart' AND orders.USER_ID = '$row[USER_ID]'";
$result2 = mysqli_query($conn,$sql2);


?>
   <script>
                    function toggle<?=$row['USER_ID']?>(source) {
  checkboxes = document.getElementsByName('orderid<?=$row['USER_ID']?>[]');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}
function complete<?=$row['USER_ID']?>(){ 
     var x = document.getElementById("status<?=$row['USER_ID']?>")
     if(x.value == 'Completed'){
        return confirm("All orders changed to complete will be deleted.Are you sure you want to proceed?")
     }
}
</script>
       <section class="tablecontainer">
        <form action="adminorders.php?userid=<?=$row['USER_ID']?>" method="POST">
                <table class="table" id="orderstable">

                <tr>
                        <th>Select</th>
                        <th>Product Name</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Remove</th>
                      
                    </tr>
                    <?php while ($row2 = mysqli_fetch_assoc($result2)) {?>
                       
                        <tr>
                            <td><input type="checkbox" name="orderid<?=$row['USER_ID']?>[]" value="<?=$row2['ORDER_ID']?>"></td>
                            <td><?=$row2['PRODUCT_NAME']?></td>
                            <td><?=$row2['AMOUNT']?></td>
                            <td><?=$row2['STATUS']?></td>
                            <td><a href="remove.php?ORDER_ID=<?=$row2['ORDER_ID']?>">Remove</a> </td> 
                        </tr>

                 <?php  } ?> </table>
                 <div class="editstatus">
                 <input type="checkbox" onClick="toggle<?=$row['USER_ID']?>(this)"><label> Select All</label><br><br>
                 <label>Change Status to:</label>
                 <select name="status" id="status<?=$row['USER_ID']?>">
                    <option>Pending</option>
                    <option>Delivering</option>
                    <option>Completed</option>
                    </select><br><br>
                <input type="submit" class="addto" value="Submit" onclick="complete<?=$row['USER_ID']?>()">
                    </div>
                    </form>
                
                    </section> <?php }} ?>
                 

                <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>