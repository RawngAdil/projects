<?php
session_start();
require 'connect.php';
/*$_SESSION["Book_ID"]=$_GET["Book_ID"]=4;
    $sql="SELECT User_Name From users WHERE Email='$_SESSION[email]' ";
    $result = mysqli_query($conn, $sql);
     $row = mysqli_fetch_assoc($result);
     $sql112="SELECT SUM(Price)as Total_Price FROM `$row[User_Name] Order`";
     $result112=mysqli_query($conn,$sql112);
     if($result112){
    echo "done" ;
     }
else {
    echo "fail" ;
}


 
 
?>
<!DOCTYPE html>
<html>
    <head><title>test</title> </head>
    <body>
        <style>
            .alert{
                padding: 20px;
                
                color:white;
            }
            .close{
                color:white;
                font-weight:bold;
                float:right;
                line-height:20px;
                font-size:22px;
                cursor: pointer;
                transition:0.3s;
            }

            </style>
        <div class="alert">
            <span class="close" onclick="this.parentElement.style.display='none';">&times;</span>
            <p>Your order is placed successfully </p>
            <?php
            $sql112="SELECT SUM(Price)as Total_Price FROM `$row[User_Name] Order`";
 $result112=mysqli_query($conn,$sql112);
 $row112 = mysqli_fetch_assoc($result112);
 $x=$row112['Total_Price'];
 $sum=number_format((float)$x,2, '.','');
 echo " Total Price :$ $sum <br> "; ?>
 Payment at delivery:<input type="checkbox" id="checkbox" onclick="CheckFunction()"> 
<p id="text" style="display:none">Your order has been confirmed..You will receive it in the coming days</p>
</div>
<script>
    function CheckFunction(){
        var checkBox =document.getElementById("checkbox")
        var text= document.getElementById("text")
        if (checkBox.checked==true){
            text.style.display="block";
        }else{
            text.style.display="none";
        }
    }
 </script>
 <?php
$sql="SELECT * FROM `"."Order"."`";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
?>
   <h1> My Order</h1>
   <table id="books">
                <tr>
                   
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                    <th>Delete From Order List  </tr>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                        <form action="deletefromorder.php" method="GET"  id="delete">
                        <td><a onclick="return confirm('Are you sure you want to delete this book from your order list?')"
                         href="deletefromorder.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        Delete</a></td> 
                </form>
                      
                        
                    </tr>
                <?php } } ?>
            </table>*/
            
 $sql="SELECT image From books   ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
            ?>
            <img src="<?=$row['image']?>">
</body>
</html>