<?php 
session_start();
require 'connect.php';
$_SESSION['search']=$_GET['search'];

?>
<!DOCTYPE html>
<html>

<head>
 <style>
 * {
            box-sizing: border-box;
            margin: 0 ;
            padding: 0;
            
        }
      

        body {
            margin:0;
            font-family:  sans-serif;
            font-size:18px;
            color:#000000;
          
        }

       

        #books {
            margin-top:2%;
            margin-bottom:2%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;
           
            

        }

        #books td,
        #books th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            
            padding: 8px;
        }

        #books tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
}
        }

        #books tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #books th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
        
        }
        .not{
          
            color:rgb(97, 17, 17);
            text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
            font-size:50px;
	     text-align:center;
    
    margin: 2% auto;
        }

    </style>
</head>

<body>
    <?php
$sql= "SELECT books.Book_Name,authors.Author_Name,books.Price,books.Buy FROM books JOIN authors ON books.Author_ID=authors.Author_ID
 WHERE Book_Name LIKE '%$_SESSION[search]%' ";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0){
?>
   <table id="books">
                <tr>
                   
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                    <th>Buy</th>

                </tr>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                        <td><?=$row['Buy']?></td>
                        <form action="mycart.php" method="GET"  id="buy">
                        <td><a href="mycart.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        <?=$row['Buy']?></a></td>
                      
                        
                    </tr>
                <?php } ?>
            </table>
        <?php  } else {
            echo '<span class="not"> No Result </span>';
        } ?>

    </body>
    </html>