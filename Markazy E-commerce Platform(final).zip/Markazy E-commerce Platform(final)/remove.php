<?php

session_start();

  require 'connect.php';
error_reporting(0);

  if (isset($_GET['PRODUCT_ID'])) {
  	$_SESSION['PRODUCT_ID']=$_GET['PRODUCT_ID'];


$sql = "DELETE  FROM products WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
$sql2 = "DELETE  FROM productrating WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
              $result = mysqli_query($conn, $sql);
        $result2 = mysqli_query($conn, $sql2);
        if ($result && $result2) {
        	 header("Location:admin.php");
        }
       }

     if (isset($_GET['USER_ID'])) {
     	$_SESSION['USER_ID']=$_GET['USER_ID'];
     	$sql3 = "DELETE FROM users WHERE USER_ID = '$_GET[USER_ID]'";
        $result3 = mysqli_query($conn, $sql3);
        if ($result3) {
        	header("Location:users.php");
        } 
        
     }

     if (isset($_GET['ORDER_ID'])) {
      $_SESSION['ORDER_ID']=$_GET['ORDER_ID'];
      $sql5 = "DELETE FROM orders WHERE ORDER_ID = '$_GET[ORDER_ID]'";
      $result5 = mysqli_query($conn, $sql5);
      if ($result5) {
         header("Location:adminorders.php");
      } 
      
   }

   if (isset($_GET['STORE_ID'])) {
      $_SESSION['STORE_ID']=$_GET['STORE_ID'];
      $sql6 = "DELETE FROM stores WHERE STORE_ID = '$_GET[STORE_ID]'";
      $result6 = mysqli_query($conn, $sql6);
      if ($result6) {
         header("Location:stores.php");
      } 
      
   }

   if (isset($_GET['RATING_ID'])) {
      $_SESSION['RATING_ID']=$_GET['RATING_ID'];
      $sql6 = "DELETE FROM productratings WHERE RATING_ID = '$_GET[RATING_ID]'";
      $result6 = mysqli_query($conn, $sql6);
      if ($result6) {
         header("Location:adminreviews.php");
      } 
      
   }
   if (isset($_GET['demote'])) {
     $sql = "UPDATE users SET ROLE = 'Customer' WHERE USER_ID='$_GET[demote]'";
    $result = mysqli_query($conn, $sql);
   if($result){
      header("Location:users.php?demotesuccess");
      die;
   }else{
      header("Location:users.php?demotefail");
      die;
   }

   }
   if (isset($_GET['promote'])) {
      $sql = "UPDATE users SET ROLE = 'admin' WHERE USER_ID='$_GET[promote]'";
     $result = mysqli_query($conn, $sql);
    if($result){
       header("Location:users.php?promotesuccess");
       die;
    }else{
       header("Location:users.php?promotefail");
       die;
    }
    
    }
   

