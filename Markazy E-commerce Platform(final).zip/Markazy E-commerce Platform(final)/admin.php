<?php
session_start();
require 'connect.php';
error_reporting(0);

if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
  header("Location:index.php");
 die();
}

$subcategory = $category = $display = $display2 = $notification = $type = $subcategory2 = $category2 = $season = '';
$subcategoryErr = $categoryErr = $typeErr = $subcategory2Err = $category2Err = $seasonErr = '';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['subcat'])){
if(isset($_POST['subcategory']) && !empty($_POST['subcategory'])){
  $subcategory = $_POST['subcategory'];
  $sql ="SELECT * FROM subcategories WHERE SUBCATEGORY LIKE '%$subcategory%'";
  $result = mysqli_query($conn,$sql);
  if(mysqli_num_rows($result) !== 0){
    $subcategoryErr="Subcategory already exists";
    unset($_POST['subcategory']);
    $display = 'style="display:block;"';
  }
}else{
  $subcategoryErr="Subcategory is required";
  unset($_POST['subcategory']);
  $display = 'style="display:block;"';
}
if(isset($_POST['category'])){
  $category =  $_POST['category'];
}else{
  $categoryErr = 'Category is required';
  unset($_POST['category']);
  $display = 'style="display:block;"';
}
if($categoryErr == '' and $subcategoryErr == ''){
$sql = "INSERT INTO subcategories (CATEGORY , SUBCATEGORY ) VALUES ('$_POST[category]','$_POST[subcategory]')";
$result = mysqli_query($conn, $sql);
   if ($result) {
       $notification = 'Subcategory added successfully';
       
   }else{
    $notification = 'System Error: The system was unable to add your subcategory';
   unset($_POST["category"]);
    unset($_POST["subcategory"]);
    
  }
  }}
  elseif($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['defproduct'])){
    if(isset($_POST['type']) && !empty($_POST['type'])){
      $type = $_POST['type'];
      $sql ="SELECT * FROM defproducts WHERE DEFPRODUCT_NAME LIKE '%$type%'";
      $result = mysqli_query($conn,$sql);
      if(mysqli_num_rows($result) !== 0){
        $typeErr="Product type already exists";
        unset($_POST['type']);
        $display2 = 'style="display:block;"';
      }
    }else{
      $typeErr="Product type is required";
      unset($_POST['type']);
      $display2 = 'style="display:block;"';
    }
    if(isset($_POST['filtercategory']) and $_POST['filtercategory'] !== 'None'){
      $category2 =  $_POST['filtercategory'];
    }else{
      $category2Err = 'Category is required';
      unset($_POST['filtercategory']);
      $display2 = 'style="display:block;"';
    }
    if(isset($_POST['filtersubcategory']) and $_POST['filtersubcategory'] !== 'None'){
      $subcategory2 =  $_POST['filtersubcategory'];
    }else{
      $subcategory2Err = 'Subcategory is required';
      unset($_POST['filtersubcategory']);
      $display2 = 'style="display:block;"';
    }
    if(isset($_POST['season'])){
      $season =  $_POST['season'];
    }else{
      $seasonErr = 'Season is required';
      unset($_POST['season']);
      $display2 = 'style="display:block;"';
    }
   
    if($typeErr == '' and $category2Err == '' and $subcategory2Err == '' and $seasonErr == ''){
    $insert = "INSERT INTO defproducts ( DEFPRODUCT_NAME, SUBCATEGORY_ID, SEASON ) VALUES ('$type','$subcategory2','$season')";
$result = mysqli_query($conn, $insert);
if ($result) {
  $notification = 'Product Type added successfully';
  
}else{
$notification = 'System Error: The system was unable to add your product type';
unset($_POST['type']);
unset($_POST["category"]);
unset($_POST["subcategory"]);
unset($_POST['season']);

}}
    
    }
include 'notification.php';
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<title>Admin page</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>

<h2> Statistics </h2>
<section class="nums">

<a href="stores.php"><section class="box">
        <?php 
            $sql = " SELECT * FROM stores ";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>Stores Count</h3>
              <h4>  <?=$row ?>  </h4>   
        </section></a>

        <a href="users.php"><section class="box">
        <?php 
            $sql2 = "SELECT * FROM users WHERE ROLE='Customer' ";
            $result2 = mysqli_query($conn,$sql2);
            $row2 = mysqli_num_rows($result2); 
            ?> 
            <h3>Customer Count  </h3>
             <h4><?=$row2 ?> </h4>   
        </section></a>

        <a href="adminproducts.php"><section class="box">
        <?php 
            $sql3 = " SELECT * FROM products ";
            $result3 = mysqli_query($conn,$sql3);
            $row3 = mysqli_num_rows($result3); 
            ?> 
              <h3>Total Products Count</h3>
              <h4>  <?=$row3 ?> </h4>   
        </section></a>

        <a href="adminorders.php"><section class="box">
        <?php 
            $sql4 = "SELECT * FROM orders WHERE NOT STATUS='Cart' " ;
            $result4 = mysqli_query($conn,$sql4);
            $row4 = mysqli_num_rows($result4); 
            ?> 
               <h3> Total Orders Count </h3>
               <h4><?=$row4 ?></h4>   
        </section></a>

</section>

<script>
function add(){
  var t = document.getElementById("addsubcat");
  if ( t.style.display === "block"){
    t.style.display ="none";
}else{
    t.style.display ="block" ;}
}

function add2(){
  var t = document.getElementById("addnew");
  if ( t.style.display === "block"){
    t.style.display ="none";
}else{
    t.style.display ="block" ;}
}

   

  </script>
 <hr>
 <h2>Most In-Demand Products</h2>
 <section class="graph">
  
<canvas id="canvas" height="350" style="display: block; box-sizing: border-box; max-height: 500px; max-width: 900px; padding: 10px; margin-left: 2%;"></canvas>
<?php 
$sql="SELECT DEFPRODUCT_ID,SUM(SALES) as 'TotalSales'
      FROM products 
      GROUP BY DEFPRODUCT_ID
      ORDER BY 'TotalSales' DESC
      LIMIT 7";
$result=mysqli_query($conn,$sql);
$rows =array();
$rows2=array();
$i=0;
while($row=mysqli_fetch_assoc($result)){
  $sql2="SELECT DEFPRODUCT_NAME FROM defproducts WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
  $result2=mysqli_query($conn,$sql2);
  $names=mysqli_fetch_assoc($result2);
  array_push($rows,$names['DEFPRODUCT_NAME']);
  array_push($rows2,$row['TotalSales']);
  $i=$i+1;
}
?>
<script type="text/javascript">
if (window.matchMedia("(min-width: 610px)").matches){
  var size = 15

}
else if (window.matchMedia("(min-width: 430px)").matches) {
  var size = 13}else{
    var size = 10
  }
 var chr = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    var options = {
    scales: {
        yAxes: [{
            ticks: {
                fontSize: 40
            }
        }]
    }
}
    var data = {
      type: "bar",
      data: {
        labels: <?php echo json_encode($rows);?>,
        datasets: [{
          label: "Number of kilos sold",
          backgroundColor: [
           <?php $sql="SELECT DEFPRODUCT_ID,SUM(SALES) as 'TotalSales'
      FROM products 
      GROUP BY DEFPRODUCT_ID
      ORDER BY 'TotalSales' DESC
      LIMIT 7";
$result=mysqli_query($conn,$sql);
while($i>0){echo
      "'rgb(29, 107, 29)',";
      $i=$i-1;}?>
    ],
    borderColor: [
      'rgb(255, 99, 132)',
      'rgb(255, 159, 64)',
      'rgb(255, 205, 86)',
      'rgb(75, 192, 192)',
      'rgb(54, 162, 235)',
      'rgb(153, 102, 255)',
      'rgb(201, 203, 207)'
    ],
    borderWidth: 1,
          fillColor: "blue",
          strokeColor: "green",
          data: <?php echo json_encode($rows2);?>
        }]
      },
    
    options: {
    scales: {
      x: {
        title: {
          font: {
            size: 14,
            weight: "300",
            family: 'vazir'
          },
          color: 'black'
          
        },

        ticks: {
          font: {
            
            size: size,
            weight: "600",
            family: "Merienda"
          },
          color: 'black',
        },
      },
      y: {
        title: {
          font: {
            size: 200,
            weight: "300",
            family: 'vazir'
          },
          color: 'black'
          
        },

        ticks: {
          font: {
            
            size: size,
            weight: "600",
            family: "Merienda"
          },
          color: 'black',
        },
      },
      }
    
  }
}
    var myfirstChart = new Chart(ctx, data);
</script>
<?php /*<h2>Seasonal Products</h2>
<canvas id="piechart" style="width:100%;max-width:600px"></canvas>
  <script>
var xValues = ["Spring", "Summer", "Autumn", "Winter"];
var yValues = [55, 49, 44, 24];
var barColors = [
  "#A3C566",
  "#ffd700",
  "#fe8b4c",
  "#2f77c3",
];

new Chart("piechart", {
  type: "pie",
  data: {
    labels: xValues, 
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "World Wide Wine Production 2018"
    }
  }
});
</script>*/?>
  </section>
  <hr>
<div class="add">
<h2>Edit Categories</h2>
<section class="sec1">

<button onclick="add()" class="editcatbtn"><a > Add Subcategory </a></button>
<section class="addsubcat">
<form id="addsubcat" action="" method="POST" <?= $display?>>
<label for="subcategory">Subcategory </label><span class="error"><?=$subcategoryErr?></span><br>
        <input type="text" name="subcategory" id="subcategory" placeholder="Enter Subcategory"><br>
        <label for="category">Category </label><span class="error"><?=$categoryErr?></span><br>
        <section class="radiocategories">
            <input type="radio" id="Vegetable"  name="category" value="Vegetable">
            <label for="Vegetable">Vegetable </label><br>

            <input type="radio" id="Fruit"  name="category" value="Fruit" >
            <label for="Fruit">Fruit </label><br>
</section>
<button class="fbsubmit" type="submit" name="subcat" >Submit</button>
</form>
</section>
</section>

<section class="sec2">
<button onclick="add2()" class="editcatbtn"><a>Add Product Type</a></button>
<section class="addsubcat">
<form id="addnew" action="" method="POST" <?= $display2?>>
<label for="type">Product Type</label><span class="error"><?=$typeErr?></span><br>
        <input type="text" name="type" id="type" placeholder="Enter Product Type"><br>
        <script>
    function subcategory(){
    if(document.getElementById('selectcategory').value == "Vegetable") {
      document.getElementById('subvegetable').style.display= "inline-block";
      document.getElementById('subvegetable').removeAttribute("disabled");
      document.getElementById('subfruit').style.display= "none";
      document.getElementById('subfruit').setAttribute("disabled","");
}else if(document.getElementById('selectcategory').value == "Fruit"){ 
  document.getElementById('subfruit').style.display= "inline-block";
  document.getElementById('subfruit').removeAttribute("disabled");
  document.getElementById('subvegetable').style.display= "none";
  document.getElementById('subvegetable').setAttribute("disabled","");
}else {
  document.getElementById('subvegetable').style.display= "inline-block";
  document.getElementById('subvegetable').setAttribute("disabled","");
      document.getElementById('subfruit').style.display= "none";
      document.getElementById('subfruit').setAttribute("disabled","");
}
    ;}
</script>
<label>Category:&nbsp</label>
<select name="filtercategory" id="selectcategory" onclick="subcategory()">
    <option>None</option>
    <option>Vegetable</option>
    <option id="fruit">Fruit</option>
  </select>

<label>SubCategory:&nbsp</label>
  <select name="filtersubcategory" id="subvegetable" disabled>
    <option>None</option>
    <?php $sql="SELECT * FROM subcategories WHERE CATEGORY = 'Vegetable'";
    $result=mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){?>
    <option value="<?=$row['SUBCATEGORY_ID']?>"><?= $row['SUBCATEGORY']?></option>
    <?php ;}?>
  </select>
  <select name="filtersubcategory" id="subfruit" disabled>
    <option>None</option>
    <?php $sql="SELECT * FROM subcategories WHERE CATEGORY = 'FRUIT'";
    $result=mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){?>
    <option value="<?=$row['SUBCATEGORY_ID']?>"><?= $row['SUBCATEGORY']?></option>
    <?php ;}?>
  </select><br>
    
        <label for="season">Season</label><span class="error"><?=$seasonErr?></span><br>
        <section class="seasons">
            <input type="radio" id="Winter"  name="season" value="Winter">
            <label for="Winter">Winter </label><br>

            <input type="radio" id="Spring"  name="season" value="Spring">
            <label for="Spring" id="labelspring">Spring </label><br>

            <input type="radio" id="Summer"  name="season" value="Summer" >
            <label for="Summer">Summer </label><br>

            <input type="radio" id="Autumn"  name="season" value="Autumn" >
            <label for="Autumn">Autumn</label><br>
</section>

<button class="fbsubmit" type="submit" name="defproduct">Submit</button>
</form>
</section>
</section>

</div>
      <hr>




<h2>Price Changes</h2>
<section class="changes">
<table >
  <tr>
    <th>Product</th>
    <th>Price change</th>
    <th>Average Price Now</th>
  </tr>
    <?php
     $sql="SELECT DEFPRODUCT_ID,SUM(SALES) as 'TotalSales'
     FROM products 
     GROUP BY DEFPRODUCT_ID
     ORDER BY 'TotalSales' DESC
     LIMIT 7";
$result=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_assoc($result)){
     
      $sql6= "SELECT MAX(PRODUCT_ID) as MaxPRO FROM products WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
      $result6=mysqli_query($conn,$sql6);
      $row6=mysqli_fetch_assoc($result6);
      $sql2 = "SELECT DEFPRODUCT_ID,AVG(PRICE) as AvgPricebefore FROM products WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]' AND NOT PRODUCT_ID = '$row6[MaxPRO]'";
      $result2=mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      $sql3="SELECT DEFPRODUCT_ID,AVG(PRICE) as 'AvgPriceNow'
      FROM products 
      WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
      $result3=mysqli_query($conn,$sql3);
      $row3=mysqli_fetch_assoc($result3);
      $sql4="SELECT DEFPRODUCT_NAME FROM defproducts WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]' ";
      $result4=mysqli_query($conn,$sql4);
      $row4=mysqli_fetch_assoc($result4);
      $change = $row3['AvgPriceNow']-$row2['AvgPricebefore'];
    ?>
    <tr>
    <td><?= $row4['DEFPRODUCT_NAME']?></td>
    <td><?php if( $change > 0){echo "<i class='fa fa-caret-up' aria-hidden='true'></i>".number_format((float)$change, 2, '.', '');
    }else{
      echo "<i class='fa fa-caret-down' aria-hidden='true'></i>".number_format((float)$change, 2, '.', '');}?>
    </td>
    <td>$<?= number_format((float)$row3['AvgPriceNow'], 2, '.', '');?></td>
    </tr>

    <?php ;}?>
  </table>
    
  </section>

  <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>
