<?php 
session_start();
$_SESSION['User_Name']=$_GET['User_Name'];
require 'connect.php';
$sql="SELECT User_Name from users WHERE User_Name='$_SESSION[User_Name]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name] Order"."'");
  if($results->num_rows == 1){

$sql1=" DROP TABLE  `$row[User_Name] Order`  ";
    $result1 = mysqli_query($conn, $sql1); 
    if($result1){
         header("Location:bookorders.php");
        
    }
     else{
         $fail='Failed to Cancel ';}
 

     }?>