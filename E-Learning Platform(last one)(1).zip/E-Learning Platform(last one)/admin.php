<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:index.php");
  die();
}
if ($_SESSION['role']==3) {
   header("Location:admincourses.php");
  die();}
  
   $CourseName = $CourseDesc = $CourseNameErr = $CourseDescErr = '';
  if($_SERVER['REQUEST_METHOD'] == "POST"){

    if(isset($_POST["name"])){
        $CourseName=$_POST["name"];
        if(empty($_POST["name"])){
        $CourseNameErr = "Course Name is required";
        unset($_POST["name"]);}
}elseif (isset($_POST["desc"])){
        $CourseDesc=$_POST["desc"];
        if(empty($_POST["name"])){
        $CourseDescErr = "Course Description is required";
        unset($_POST["desc"]);}
}
     if (!empty($_FILES['image'])) {
           $imageName = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];

        $upload = 'images/'.$imageName;
        if ($_FILES['image']['error'] == 0) {
            if (move_uploaded_file($tmp, $upload)) { 
                if ($CourseNameErr = $CourseDescErr = '') {
      $sql = "INSERT INTO courses (course_name , description ,image ) VALUES ('$_POST[name]' , '$_POST[desc]') ,$upload";

        if (!mysqli_query($conn, $sql)) {
            echo "Error:".$sql."<br>.".mysqli_error($conn);
        }
     }
 
  }
}
}
}
    
 ?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css" />
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL Admin</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="admin.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
          
            <div class="log"> <a href="login.php" >Logout</a></div>
            	
             
             <a href="users.php">Users</a>
             <a href="admincourses.php">Courses</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>
 <div class="container">
            <h1 class="mainheader">
                Welcome Admin!
            </h1>


            <h1 class="stat">
                Statistics
            </h1>
        </header>

 <!-- NUMs -->
 <section>
           
    	<a href="admincourses.php"><section class="box">
        <?php 
            $sql = " SELECT * FROM courses";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_num_rows($result); 
            ?> 
              <h3>
             <?=$row ?>
         </h3>
         <h4>
             Courses
         </h4>   
        </section></a>


   <!-- NUM OF LECTURES -->
   <a href="admincourses.php"> <section class="box">
        <?php 
            $sql2 = " SELECT * FROM lectures";
            $result2 = mysqli_query($conn,$sql2);
            $row2 = mysqli_num_rows($result2); 
            ?> 
              <h3>
             <?=$row2 ?>
         </h3>
         <h4>
             lectures
         </h4>   
        </section ></a>


     <!-- NUM OF STU -->
     <a href="users.php"><section class="box">
        <?php 
            $sql3 = " SELECT * FROM users WHERE role = '1'";
            $result3 = mysqli_query($conn,$sql3);
            $row3 = mysqli_num_rows($result3); 
            ?> 
              <h3>
             <?=$row3 ?>
         </h3>
         <h4>
             Students
         </h4>   
        </section></a>


        <a href="users.php"> <section class="box">
        <?php 
            $sql3 = " SELECT * FROM users WHERE role = '3'";
            $result3 = mysqli_query($conn,$sql3);
            $row3 = mysqli_num_rows($result3); 
            ?> 
              <h3>
             <?=$row3 ?>
         </h3>
         <h4>
            Teachers
         </h4>   
        </section></a>


        <a href="users.php"><section class="box">
        <?php 
            $sql3 = " SELECT * FROM users WHERE role = '2'";
            $result3 = mysqli_query($conn,$sql3);
            $row3 = mysqli_num_rows($result3); 
            ?> 
              <h3>
             <?=$row3 ?>
         </h3>
         <h4>
            Managers
         </h4>   
        </section></a>

  </section>
        </div>
 

       <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

    </article>

</body>
</html>