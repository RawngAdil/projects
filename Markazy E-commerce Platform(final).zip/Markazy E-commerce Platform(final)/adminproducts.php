<?php
session_start();
require 'connect.php';
error_reporting(0);

if(!isset($_SESSION['ID'])){
  header("Location:login.php");
  die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
header("Location:index.php");
die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin-Products </title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>
<h1>Products</h1>
    
       <?php 
        $sql = "SELECT * FROM products JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID";
        $result = mysqli_query($conn ,$sql);
    if ( mysqli_num_rows($result) > 0) {
       ?>
       
       <script>
function filter2() {
  var y = '';
var x = document.getElementById("filterproduct")
if(x.value == "Name"){
 y = 1
}else if(x.value == "ID"){
 y = 0
}else if(x.value == "Supplier Name"){
 y = 2
}else if(x.value == "Price"){
 y = 3
}else if(x.value == "Stock"){
 y = 4
}else if(x.value == "Sales"){
 y = 5
}else if(x.value == "Description"){
 y = 5
}

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("allproducts");
  filter = input.value.toUpperCase();
  table = document.getElementById("productstable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[y];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

<input type="text" id="allproducts" onkeyup="filter2()" placeholder="Search for names.." class="field"><br>
<div class="searchfilter">
<label>Search by:</label>
<select id="filterproduct" onclick="filter()">
  <option>Name</option>
  <option>ID</option>
  <option>Supplier Name</option>
  <option>Price</option>
  <option>Stock</option>
  <option>Sales</option>
  <option>Description</option>
</select>
</div>
       <section class="tablecontainer">
       
                <table class="table" id="productstable">

                <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Supplier Name</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Sales</th>
                        <th>Description</th>
                        <th>Rating</th>
                        <th>Delete</th>
                        <th>Reviews</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                       
                        <tr>
                            <td><?=$row['PRODUCT_ID']?></td>
                            <td><?=$row['PRODUCT_NAME']?></td>
                            <td><?=$row['STORE_NAME']?> </td>
                            <td><?=$row['PRICE']?></td>
                            <td><?=$row['STOCK']?></td>
                            <td><?=$row['SALES']?></td>
                            <td><?=substr($row['PRODUCT_DESCRYPT'], 0 , 50)?></td>
                            <td><?=$row['Average_rating']?></td>

                                <form action="remove.php" method="GET">
                                    <td><a href="remove.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>">Remove</a> </td>
                            </form>
                             <td><a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"> Go To...</a></td>
                        </tr>

                 <?php  } } ?>
                </table>
                    </section>

                <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>