<?php
session_start();
require 'connect.php';
error_reporting(0);
if(isset($_SESSION['ROLE'])){
    if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){
        header("Location:admin.php");
      die;
    }
  }
$notification = '';
$sql="SELECT * FROM orders JOIN products ON orders.PRODUCT_ID = products.PRODUCT_ID JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID WHERE USER_ID = '$_SESSION[ID]' AND STATUS = 'Cart'";
$result = mysqli_query($conn,$sql);

$cartcheck = mysqli_num_rows($result);
$sql2 =  "SELECT * FROM orders WHERE USER_ID = '$_SESSION[ID]' AND STATUS = 'PENDING'";
$result2 = mysqli_query($conn,$sql2);
if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die;
}elseif($cartcheck == 0){
    header("Location:index.php?emptycart");
    die;
}
if(isset($_GET['deleteproductsuccess'])){
    $notification = 'The product was deleted successfully';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['error1'])){
    $notification = 'Choose an amount for all products in the cart';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['error2'])){
    $notification = 'Transaction proof for MBOK payment is required';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['error3'])){
    $notification = 'Choose Payment method';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }

if(isset($_GET['deleteproductfail'])){
    $notification = 'System Error: The system was unable to delete the product';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['cancelsuccess'])){
    $notification = 'Your order has been cancelled succesfully';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['cancelfail'])){
    $notification = 'System Error:The system was unable to cancel your order';?>
    <script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
$row = mysqli_fetch_assoc($result);
include 'notification.php';
?>
<!DOCTYPE html>
<html>
 
    <head>
     <title>MY CART</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <?php
    include 'navigation.php';?>

<h1 class="cartheading">My Cart</h1>
<h2>View your list of chosen products</h2>
<form method="POST" action="cartprocess.php" enctype="multipart/form-data">
<div class="tablecontainer">
<table id="myCart">
    <tr>
    <th>Product Name</th>
    <th>Choose Amount<br>(Min:10kg)</th>
    <th>Total Price</th>
    <th>Delete From Cart</th>
</tr>
<?php
$sql="SELECT * FROM orders JOIN products ON orders.PRODUCT_ID = products.PRODUCT_ID JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID WHERE USER_ID = '$_SESSION[ID]' AND STATUS = 'Cart';";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
    ?>

<tr>
    <td><?= $row['PRODUCT_NAME']?></td>
    <td><input  type="number" min="10" max='<?=$row['STOCK']?>' oninvalid="setCustomValidity('The stock available is <?=$row['STOCK']?> kg for now')" oninput="setCustomValidity('')"  onchange={multiply<?=$row['PRODUCT_ID']?>()} id="tt<?=$row['PRODUCT_ID']?>" value="0" name="amount<?=$row['PRODUCT_ID']?>" ></td>
    <td id="totalprice<?=$row['PRODUCT_ID']?>">0</td>
    <td><a href="cartprocess.php?deleteproductid=<?=$row['PRODUCT_ID']?>" onclick="return confirm('Are you sure you want to remove <?= $row['PRODUCT_NAME']?> from your cart?')">Delete</a></td>
</tr>
<script>
    function multiply<?=$row['PRODUCT_ID']?>(){
var multiplicand = document.getElementById('tt<?=$row['PRODUCT_ID']?>').value || 0; 
  var product = parseInt(multiplicand) * parseInt('<?=$row['PRICE']?>');
  document.getElementById('totalprice<?=$row['PRODUCT_ID']?>').innerHTML =product; 
  document.getElementById('totalprice<?=$row['PRODUCT_ID']?>').value = product;
  var table = document.getElementById("myCart") 
  var sumVal = 0;
            
            for(var i = 1; i < table.rows.length-1; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[2].innerHTML);
            }
            
            document.getElementById("grandtotal").innerHTML = "Sum Value = $" + sumVal;

    }
 
 

    function hide(){
        if(document.getElementById('paymentmethod').value == "Mbok"){
        document.getElementById('upload').removeAttribute("disabled");
    }else{
        document.getElementById('upload').setAttribute("disabled","");
    }
    }
    
</script>
<?php ;}?>
<tr>
    <td>Grand Total Price:</td>
    <td id="grandtotal"></td>
    <td></td>
    <td> </td>
</tr>
</table>
</div>
    <h2>Choose Payment Method (Required)</h2>
<div id="transactionproof">
<select id="paymentmethod" name="paymethod" onchange="hide()">
        <option>Cash</option>
        <option>Mbok</option>
</select><br>
<h3>Upload Screenshot of transaction:</h3>
<input type="file" name="uploadfile"  class="primarybtn upload" id="upload" disabled/>
<button type="submit" class="addto" value="Purchase">Purchase<i class="fa-solid fa-cart-shopping"></i></button>
</div>
</form>
<?php 
$sql="SELECT * from orders WHERE USER_ID = '$_SESSION[ID]' AND (STATUS='Pending' OR STATUS = 'Shipping')";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result) > 0){
?>
<section class="pendingsection">
<h1 class="cartheading">Pending Orders</h1>
<div class="tablecontainer pending">
<table id="pendingorders">
    <tr>
    <th>Product Name</th>
    <th>Store Name</th>
    <th>Amount</th>
    <th>Total Price</th>
    
</tr>
<?php
$sql="SELECT * FROM orders JOIN products ON orders.PRODUCT_ID = products.PRODUCT_ID JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID WHERE USER_ID = '$_SESSION[ID]' AND STATUS = 'Pending';";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
    ?>

<tr>
    <td><?= $row['PRODUCT_NAME']?></td>
    <td><?= $row['STORE_NAME']?></td>
    <td><?= $row['AMOUNT']?></td>
    <td><?= $row['PRICE']*$row['AMOUNT']?></td>
    
</tr>
<?php ;}?>
</table>
</div>
<a href="cartprocess.php?cancelorder" onclick = "return confirm('Are you sure you want to cancel your order? All Orders will be deleted')"><button class="addto cancel">Cancel Order</button></a>
</section>


<?php }include 'footer.php';?>




