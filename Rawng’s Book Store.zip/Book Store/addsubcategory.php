<?php
session_start();
require 'connect.php';
 $success = $fail = $exist_error  =$subcategory=  $subcategory_err= '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if(isset($_POST["subcategory"])){
        $subcategory=$_POST["subcategory"];
        if(empty($_POST["subcategory"])){
            $subcategory_err="subcategory is required ";
            unset($_POST["subcategory"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["subcategory"])){
            $subcategory_err="Only letters allowed ";
            unset($_POST["subategory"]);
        }
   

    
     $sql = "SELECT Subcategory FROM subcategories  WHERE Subcategory = '$_POST[subcategory]'  ";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $exist_error = "subategory already exists";
            } elseif ($subcategory_err=='' and  $exist_error=='') {
                $sql = "INSERT INTO subcategories (Subcategory) VALUE ( '$_POST[subcategory]' ) ";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $success = '<span class="success"> 1 Subcategory added successfuly</span>';
                    header('Location:subcategories.php');
                } else {
                    $fail = '<span class="err">Failed to add Subcategory</span>';
                }
            }
        }
    }
}


?>
<!DOCTYPE html>
<html>
<style>
    <?php include 'style.css' ?>
    .container{
        position: absolute;
        width: 50%;
        left: 21%;
    }
    
</style>

<body>

    <?= $success ?><?= $fail ?>
    <?php
    $sql2="SELECT * FROM subcategories LIMIT 1 ";
    $result2= mysqli_query($conn,$sql2);
    ?>
    <form action="addsubcategory.php" method="post" >

        <div class="container">
            <h1>Add Subcategory</h1>
           
            <div class="hrl"> </div>
            <?php while ($row = mysqli_fetch_assoc($result2))
            
            { ?>

            <label for="subcategory"><b>Subcategory Name</b></label> <span class="error"><?=$exist_error?></span><br> <span class="error"><?=$subcategory_err?><br></span>
            <input type="text" placeholder="Enter Subcategory" name="subcategory" id="Subcategory"  required>
           
            
           

            <div class="btncontener">
            <a href="subcategories.php"> <button type="button" class="cancel">Cancel</button></a>
             <button type="submit"  class="submit">Add </button>
                <?php } ?>
            </div>
        </div>
    </form>

</body>

</html>