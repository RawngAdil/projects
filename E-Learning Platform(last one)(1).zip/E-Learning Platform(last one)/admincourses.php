<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:index.php");
  die();
}

  
  $CourseName = $CourseDesc = $CourseNameErr = $CourseDescErr = '';
  if($_SERVER['REQUEST_METHOD'] == "POST"){

    if(isset($_POST["name"])){
        $CourseName=$_POST["name"];
        if(empty($_POST["name"])){
        $CourseNameErr = "Course Name is required";
        unset($_POST["name"]);}
}
if (isset($_POST["desc"])){
        $CourseDesc=$_POST["desc"];
        if(empty($_POST["desc"])){
        $CourseDescErr = "Course Description is required";
        unset($_POST["desc"]);}
}
     // if (!empty($_FILES['image'])) {
     //       $imageName = $_FILES['image']['name'];
     //    $tmp = $_FILES['image']['tmp_name'];

     //    $upload = 'images/'.$imageName;
     //    if ($_FILES['image']['error'] == 0) {
     //        if (move_uploaded_file($tmp, $upload)) { 
                if ($CourseNameErr =='' and $CourseDescErr == '') {
      $sql = "INSERT INTO courses (course_name , description ) VALUES ('$CourseName' , '$CourseDesc')";
     $result = mysqli_query($conn, $sql);
        if (!$result) {
            echo "Error:".$sql."<br>.".mysqli_error($conn);
        }
        unset($_POST["send"]);
         unset($_POST["name"]);
          unset($_POST["desc"]);
     }
 
  // }
// }
// }
}
    
 
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css" />
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL Admin</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">

</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="admin.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
          
            <div class="log"> <a href="login.php" >Logout</a></div>
            	
             
             <a href="users.php">Users</a>
             <a  class="active" href="admincourses.php">Courses</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>



  <section>

  <div class="container">
       <button id="add" type="button" onclick="AddFunction()">Add Course </button>

       <section id="addcourse">
        <h2>Add Courses</h2>
        <form action="" method="post">
            <label for="name">Course Name</label><br>
            <input type="text" name="name" id="name" placeholder="Course Name"><br>

            <label for="image">Course Picture</label><br>
            <input type="file" name="image" id="image" placeholder="Course Name"><br>

              <label for="desc">Course Description</label><br>
            <textarea type="text" name="desc" id="desc" placeholder="Course Description"></textarea><br>


            <button type="submit" id="send" >Send</button>
            
        </form>
  </section>

  <script>
         function AddFunction(){
             var x = document.getElementById("addcourse");
            
             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }
            }
    </script>

<!-- Courses Editing -->
<section>
        <h1>
            Courses
        </h1>

        <section>
        <?php  

      if (isset($_GET['search'])) {
       $serch =$_GET['search'];
       $sql = "SELECT * FROM courses WHERE course_name LIKE '%$serch%'";
            $result = mysqli_query($conn ,$sql) ; 
      }
         else {
                $sql = "SELECT * FROM courses ";
                $result = mysqli_query($conn ,$sql);}
            if ( mysqli_num_rows($result) > 0) {?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                        
                        <tr>
                            <td><?=$row['course_id']?></td>
                             <td><a href="adminLec.php?course_id=<?=$row['course_id']?>"><?=$row['course_name']?></a></td>
                              <td><?=substr($row['description'], 0 , 50)?></td>
                                <form action="delete.php" method="get"><td><a href="delete.php?course_id=<?php echo$row['course_id'] ?>">delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>

 


 <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

      </div>
  </body>
</html>
