
    var body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
    search=document.getElementById("search");

    myBtn.onclick = function(){
        "use strict";
        
        if(body.classList.contains('lightmood')){
            body.classList.toggle('darkmood')
        }
        if(nav.classList.contains('container-lightmood')){
            nav.classList.toggle('container-darkmood')
        }
        if(myBtn.classList.contains('light')){
            myBtn.classList.contains('dark')
        }
        if(search.classList.contains('lightbar')){
            search.classList.contains('darkbar')
        }

    };
