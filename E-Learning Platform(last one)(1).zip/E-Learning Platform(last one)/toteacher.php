<?php 
session_start();
require 'connect.php';

$sql = "UPDATE users SET role = '3' WHERE user_id = '$_GET[user_id]'";
$result = mysqli_query($conn,$sql);
if ($result) {
	header("Location:users.php");
}


 ?>