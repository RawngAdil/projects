<?php 
session_start();
$_SESSION['Book_ID']=$_GET['Book_ID'];
require 'connect.php';
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

$sql1=" DELETE from  `$row[User_Name] Order` WHERE Book_ID='$_SESSION[Book_ID]' ";
    $result1 = mysqli_query($conn, $sql1); 
    if($result1){
        $success ='1 book deleted from order list successfuly';
         header("Location:myorder.php");
        echo $success;
    }
     else{
         $fail='Failed to delete ';}
 

 ?>