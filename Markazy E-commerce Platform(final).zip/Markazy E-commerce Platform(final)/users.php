<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
  header("Location:login.php");
  die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
header("Location:index.php");
die();
}
$notification = '';
if(isset($_GET['demotesuccess'])){
  $notification = 'User demoted successfully';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['demotefail'])){
  $notification = 'System Error: The system was unable to demote the user';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['promotesuccess'])){
  $notification = 'User promoted successfully';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['promotefail'])){
  $notification = 'System Error: The system was unable to promote the user';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
include 'notification.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Users </title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>
<h1>Users</h1>
    
       <?php 
        $sql = "SELECT * FROM `users` ";
        $result = mysqli_query($conn ,$sql);
    if ( mysqli_num_rows($result) > 0) {
       ?>
        <script>
function filter2() {
  var y = '';
var x = document.getElementById("filterusers")
if(x.value == "Name"){
 y = 1
}else if(x.value == "ID"){
 y = 0
}else if(x.value == "Email"){
 y = 2
}else if(x.value == "Role"){
 y = 3
}
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("allusers");
  filter = input.value.toUpperCase();
  table = document.getElementById("userstable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[y];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<input type="text" id="allusers" onkeyup="filter2()" placeholder="Search for names.." class="field"><br>
<div class="searchfilter">
<label>Search by:</label>
<select id="filterusers" onclick="filter()">
  <option>Name</option>
  <option>ID</option>
  <option>Email</option>
  <option>Role</option>
</select>
</div>
       <section class="tablecontainer">
       
                <table class="table" id="userstable">

                <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Delete</th>
                       <?php if($_SESSION['ROLE'] == "superadmin"){?> <th>Promote/Demote</th><?php }?>
                      
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                       
                        <tr>
                            <td><?=$row['USER_ID']?></td>
                            <td><?=$row['FIRST_NAME']?> <?=$row['LAST_NAME']?></td>
                            <td><?=$row['EMAIL']?></td>
                            <td><?=$row['ROLE']?></td>
                           
                                <form action="remove.php" method="GET">
                                    <td><a href="remove.php?USER_ID=<?=$row['USER_ID']?>">Remove</a> </td>
                            </form>
                             <?php if($_SESSION['ROLE'] == "superadmin"){?> 
                              <td><?php if($row['ROLE'] == "admin"){?><a href="remove.php?demote=<?=$row['USER_ID']?>">Demote</a><?php }else{?><a href="remove.php?promote=<?=$row['USER_ID']?>">Promote</a><?php }?></td><?php }?>
                        </tr>

                 <?php  } } ?>
                </table>
                    </section>

                <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>