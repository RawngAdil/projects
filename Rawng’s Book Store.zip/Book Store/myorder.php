<?php
session_start();
require "connect.php";
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name] Order"."'");
  if($results->num_rows == 1){
?>
<!DOCTYPE html>
<html>
    <head><title>my order</title>
    <style>
    <?php
              include "style2.css"?>
            #books {
            margin-top:2%;
            margin-bottom:2%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;   
            font-family: 'Merienda', cursive;          
       }

        #books td,
        #books th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            padding: 8px;
        }

        #books tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
            color:black;
}
        }

        #books tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #books th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
        
        }
        h1{
          
         color:rgb(97, 17, 17);
        text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
        text-align:center;
        margin: 1.6% auto;
        margin-bottom:4%;
        font-size:40px;
        font-family: 'Tapestry';
      }
      p{
          font-size:25px;
          margin-left:30px;
          color: rgb(80, 17, 17);
          text-shadow: 2px 2px 2px rgba(7, 7, 7, 0.574);
          
          font-family: 'Tapestry';
      }
      .cancelorder{
        background-color: rgb(97, 17, 17);
            color: white;
            text-align:center;
            width: 9%;
            height: 10%;
            font-weight:800;
        
            border-radius:15px;
            padding: 5px 8px 5px 8px ;
            font-size:15px;
            position: absolute;
            right: 7%;
            top:24%;
            border: none;
        cursor: pointer;
        opacity: 0.8;
        box-shadow:2px 2px 3px 2px rgba(7, 7, 7, 0.350);
        }
.cancelorder:hover{
         opacity: 1;
        }
      </style>
       </head>
    <body id="main" class="lightmood">
    <header>
    <div id="nav" class="topnav container-lightmood">
        <a  href="BookStore.php">Home</a>
        <a  href="aboutus.php">About Us</a>
        <a class="active" href="mycart.php">My Cart</a>
        <a href="userlogout.php">Logout</a>
        </div>

        <script>
 function switchTheme() {
         var theme = localStorage.getItem('theme');
         body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
         if (theme === 'darkmode') {
            new_theme = 'lightmode';
         } else {
            new_theme = 'darkmode';
         }
         body.classList.remove(theme);
         myBtn.classList.remove(theme);
         nav.classList.remove(theme);
         body.classList.add(new_theme);
         myBtn.classList.add(new_theme);
         nav.classList.add(new_theme);
         localStorage.setItem('theme', new_theme);
      }

      window.addEventListener('load', function () {
         var theme = localStorage.getItem('theme');
         if (theme === null || theme === undefined) {
            theme = 'lightmode';
            localStorage.setItem('theme', theme);
         }
         var body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
    search=document.getElementById("search");
    searchbtn=document.getElementById("searchbtn");
    body.classList.add(theme);
         myBtn.classList.add(theme);
         nav.classList.add(theme);
         search.classList.add(theme);
         searchbtn.classList.add(theme);
      })
</script>
</header>
<button id="themes"  onclick="switchTheme()" class="light"><i class="fa-solid fa-moon"></i></button>
<?php 
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
$result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name]"."'");
if($results->num_rows == 1){
 $sql12="SELECT * FROM  `$row[User_Name]` ";
 $result12=mysqli_query($conn,$sql12);
$num= mysqli_num_rows($result12) ;
?>
<div class="cart"> 
<a href="mycart.php"><button class="carticon"><i class="fa-solid fa-cart-plus"></i></button></a>
    <div class="num" ><?=$num?></div>
</div>
<?php } ?>
<a href="cancelorder.php"><button class="cancelorder" onclick="return confirm('Are you sure you want to cancel the order?')"> Cancel The Order </button></a>
    <?php
 $sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
    $sql12="SELECT * FROM  `$row[User_Name] Order` ";
    $result12=mysqli_query($conn,$sql12);
if (mysqli_num_rows($result12) > 0){
?>

 <div class="container">
     <h1> My Order</h1>
   <table id="books">
                <tr>
                   
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                    <th>Delete From Order List  </tr>
                <?php while ($row = mysqli_fetch_assoc($result12)) { ?>
                    <tr>
                        
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                        <form action="deletefromorder.php" method="GET"  id="delete">
                        <td><a onclick="return confirm('Are you sure you want to delete this book from your order list?')"
                         href="deletefromorder.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        Delete</a></td> 
                </form>
                      
                        
                    </tr>
                <?php } } ?>
            </table>
            <?php
            $sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
            $result = mysqli_query($conn, $sql);
             $row = mysqli_fetch_assoc($result);
       $sql112="SELECT SUM(Price)as Total_Price FROM `$row[User_Name] Order`";
$result112=mysqli_query($conn,$sql112);
$row112 = mysqli_fetch_assoc($result112);
$x=$row112['Total_Price'];
$sum=number_format((float)$x,2, '.','');
echo "<p> Total Price : $ $sum </p> "; ?>
<p> Payment at delivery : <input type="checkbox" id="checkbox" onclick="CheckFunction()"> </p>
<p id="text" style="display:none">Your order has been confirmed ..You will receive it in the coming days</p>

</div>
<script>
    function CheckFunction(){
        var checkBox =document.getElementById("checkbox")
        var text= document.getElementById("text")
        if (checkBox.checked==true){
            text.style.display="block";
        }else{
            text.style.display="none";
        }
    }
 </script>
<?php } else{
    header("Location:mycart.php");
} ?>
</body>
    </html>