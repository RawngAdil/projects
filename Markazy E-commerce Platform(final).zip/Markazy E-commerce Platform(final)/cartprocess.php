<?php
session_start();
require 'connect.php';
error_reporting(0);

if(isset($_GET['addproductid'])){
    $sql="SELECT * FROM orders WHERE PRODUCT_ID = '$_GET[addproductid]' AND STATUS = 'Cart' AND USER_ID = '$_SESSION[ID]'";
    $result = mysqli_query($conn,$sql);
    $number =mysqli_num_rows($result);
    if($number == 0){
    $sql2 = "INSERT INTO orders VALUES ('','$_SESSION[ID]','$_GET[addproductid]',0,'Cart','None','None')";
    $result2=mysqli_query($conn,$sql2);
    if($result2){
        header("Location:index.php?addcartsuccess");
        die;
    }else{
        (header("Location:index.php?addcartfail"));
        die;
    }
}else{
    header("Location:index.php?productexist");
    die;
}
}elseif(isset($_GET['deleteproductid'])){
    $sql = "DELETE FROM orders WHERE PRODUCT_ID ='$_GET[deleteproductid]' AND USER_ID = '$_SESSION[ID]' AND STATUS ='CART'";
    $result=mysqli_query($conn,$sql);
    if($result){
        header("Location:mycart.php?deleteproductsuccess");
        die;
    }else{
        header("Location:mycart.php?deleteproductfail");
        die;
    }
}elseif($_SERVER['REQUEST_METHOD'] == "POST"){
    $sql ="SELECT * FROM orders WHERE USER_ID = '$_SESSION[ID]' AND STATUS='Cart'";
    $result=mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){
        $amount = $_POST["amount".$row['PRODUCT_ID']];
        echo $amount;
    if(!isset($amount) || $amount == 0){
        header("Location:mycart.php?error1");
        die;
    }
    if(isset($_POST['paymethod'])){
        if($_POST['paymethod'] == 'Mbok'){
    if(!(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"]))){
        header("Location:mycart.php?error2");
        die;
        
    }}}else{
        header("Location:mycart.php?error3");
        die;
    }
}
$sql ="SELECT * FROM orders JOIN products ON orders.PRODUCT_ID = products.PRODUCT_ID JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID WHERE USER_ID = '$_SESSION[ID]' AND STATUS = 'Cart'";
    $result=mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
    echo $_POST['paymethod'];
       $amount = $_POST["amount".$row['PRODUCT_ID']];
       if($_POST['paymethod'] == 'Mbok'){
        $paymethod = 'Mbok';
       $filename = $_FILES["uploadfile"]["name"];
       $tempname = $_FILES["uploadfile"]["tmp_name"];    
        $folder ="images/".$filename;
        move_uploaded_file($tempname, $folder);
    }else{
            $paymethod='Cash';
            $filename = "None";
        }
        
        $sql2 = "UPDATE orders SET AMOUNT = '$amount',STATUS = 'Pending', PAYMENT_METHOD = '$paymethod', PAYMENT_IMG = '$filename'  WHERE PRODUCT_ID = '$row[PRODUCT_ID]' AND USER_ID  ='$_SESSION[ID]'  AND STATUS='CART'";
        $result2 = mysqli_query($conn,$sql2);
        if(!$result2){
              echo "fail";
        }else{
            $newstock = $row['STOCK'] - $amount;
            $newsales = $row['SALES'] + $amount;
            $sql3 = "UPDATE products SET STOCK = '$newstock',SALES = '$newsales' WHERE PRODUCT_ID = '$row[PRODUCT_ID]'";
            $result3 = mysqli_query($conn,$sql3);

        }
    }
        header("Location:index.php?ordersuccess");
        die;
}elseif(isset($_GET['cancelorder'])){
    $sql = "SELECT * FROM orders JOIN products ON products.PRODUCT_ID = orders.PRODUCT_ID WHERE USER_ID='$_SESSION[ID]' and STATUS= 'Pending'";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){
            $newstock = $row['STOCK'] + $row['AMOUNT'];
            $newsales = $row['SALES'] - $row['AMOUNT'];
            $sql3 = "UPDATE products SET STOCK = '$newstock',SALES = '$newsales' WHERE PRODUCT_ID = '$row[PRODUCT_ID]'";
            $result3 = mysqli_query($conn,$sql3);

        }
    if($result){
    $sql2="DELETE FROM orders WHERE USER_ID='$_SESSION[ID]' AND STATUS='Pending'";
    $result2=mysqli_query($conn,$sql2);
    if($result2){
        header("Location:mycart.php?cancelsuccess");
        die;
    }else{
        header("Location:mycart.php?cancelfail");
        die;
    }}



}else{
    header("Location:index.php");
    die;
}