<?php
session_start();
require "connect.php";
?>
<!DOCTYPE html>
<html>
    <head><title>About us</title>
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
    <style>
    <?php
              include "style3.css"?>
              </style>
</head>
<body>
    <div class="container">
       <div class="content"> 
    <div class="profile">
        <img src="book-leaf-open-book-autumn.jpg" alt="book image">
        </div>
        <h1>Rawng’s Book Store</h1>

</div>
<div class="content">
<h1>About us</h1>
<p><b>Rawng’s Book Store </b>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia velit sit voluptatum,
     dolorem alias <b >Millions OF Books </b>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, enim perferendis mollitia natus quia eum quos iste ducimus illo ullam recusandae placeat deserunt deleniti in.<b> Voluptatum eum</b> consequatur ea optio?
      inventore <b>eaque qui blanditiis</b> vitae nulla iure nisi. A consequatur aspernatur dolor doloribus, optio aut ut!</p>
      <p><b>Lorem ipsum dolor</b> sit amet, consectetur adipisicing elit. <b> Iusto laboriosam quae </b> reprehenderit minus alias sit magnam dolorum repellendus libero fugit exercitationem nesciunt perferendis consequatur delectus aspernatur cumque, suscipit sint vitae.</p>
</div>
<div class="content">
<h1>Contact us</h1>
<h2>Contact with Admin : </h2>
<?php
  $sql = "SELECT * FROM admins";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
  ?>
          
    <table id="admin">
                <tr>
                    <th>Admin Name</th>
                    <th>Email</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['Name'] ?></td>
                        <td><?=$row['Email']?></td>
          <?php } ?>
      </table>
  <?php  } else {
      echo 'Sorry! There is no admin available right now';
  } ?>

<h2>Our Social Media Accounts :</h2>

<div class="icon"><i class="fa fa-phone"></i></div><p> 0126444761 </p>
<div class="icon"><i class="fa-regular fa-envelope"></i></div><p>rawngBS@gmail.com </p>
<div class="icon"><i class="fa fa-facebook"></i></div><p>Rawng’s Book store </p>
<div class="icon"><i class="fa fa-instagram"></i></div><p>rawngbookstore0123 </p>
<div class="icon"><i class="fa fa-twitter"></i></div><p>rawngbookstore0123 </p>

</div>

<a href="BookStore.php"> <button class="backto">  Back to Home</button></a>
</div>
</body>
    </html>