<?php
session_start();
$_SESSION['Subcategory_ID']=$_GET['Subcategory_ID'];
require 'connect.php';
$success = $fail = $exist_error  =$subcategory=  $subcategory_err= '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if(isset($_POST["subcategory"])){
        $subcategory=$_POST["subcategory"];
        if(empty($_POST["subcategory"])){
            $subcategory_err="subcategory is required ";
            unset($_POST["subcategory"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["subcategory"])){
            $subcategory_err="Only letters allowed ";
            unset($_POST["subategory"]);
        }
        elseif ($subcategory_err=='' and  $exist_error=='') {
                $sql = "UPDATE subcategories SET Subcategory= '$_POST[subcategory]'
                 WHERE Subcategory_ID= '$_SESSION[Subcategory_ID]'";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $success = '<span class="success">Category edited successfuly</span>';
                    header('Location:subcategories.php');
                } else {
                    $fail = '<span class="err">Failed to edit Category</span>';
                }
            
        }
}
}

?>
<!DOCTYPE html>
<html>
<style>
    <?php include 'style.css' ?>
    .container{
        position: absolute;
        width: 50%;
        left: 21%;
    }
</style>

<body>

    <?= $success ?><?= $fail ?>
    <?php
    $sql2= "SELECT * FROM subcategories WHERE Subcategory_ID='$_SESSION[Subcategory_ID]' ";
    $result2= mysqli_query($conn,$sql2);
    ?>
    <form action="" method="post">

        <div class="container">
            <h1>Edit Subcategory</h1>
           
            <div class="hrl"> </div>
            <?php while ($row = mysqli_fetch_assoc($result2))
            
            { ?>

            <label for="subcategory"><b>Subcategory Name</b></label><span class="error"><?=$exist_error?></span> <span class="error"><?=$subcategory_err?><br></span>
            <input type="text"  name="subcategory" id="subcategoryname" value="<?=$row['Subcategory']?>" required>
            
           

            <div>
            <a href="subcategories.php"><button type="button" class="cancel">Cancel</button></a>
                <button type="submit"  class="submit">Submit </button>
                <?php } ?>
            </div>
        </div>
    </form>

</body>

</html>