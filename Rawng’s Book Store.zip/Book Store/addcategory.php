<?php
session_start();
require 'connect.php';
 $success = $fail = $exist_error  = $category= $category_err= '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST["category"])){
        $category=$_POST["category"];
        if(empty($_POST["category"])){
            $category_err="category is required ";
            unset($_POST["category"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["category"])){
            $category_err="Only letters allowed ";
            unset($_POST["category"]);
        }
   

    
     $sql = "SELECT Category FROM categories  WHERE Category = '$_POST[category]'  ";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $exist_error = '<span class="err" Category already exists</span>';
            } elseif($category_err=='' and  $exist_error=='') {
                $sql = "INSERT INTO categories (Category) VALUE ( '$_POST[category]' ) ";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $success = '<span class="success"> 1 Category added successfuly</span>';
                    header('Location:categories.php');
                } else {
                    $fail = '<span class="err">Failed to add Category</span>';
                }
            }
        }
    }
}

?>
<!DOCTYPE html>
<html>
<style>
    <?php include 'style.css' ?>
    .container{
        position: absolute;
        width: 50%;
        left: 21%;
    }
</style>

<body>

    <?= $success ?><?= $fail ?>
    <?php
    $sql2="SELECT * FROM categories LIMIT 1 ";
    $result2= mysqli_query($conn,$sql2);
    ?>
    <form action="" method="post" >

        <div class="container">
            <h1>Add Category</h1>
           
            <div class="hrl"> </div>
            <?php while ($row = mysqli_fetch_assoc($result2))
             /*function fetches a result row as an associative <array></array>*/
            { ?>

            <label for="category"><b>Category Name</b></label><span class="error"><?=$category_err?></span><br><span class="error"><?=$exist_error?></span><br>
            <input type="text" placeholder="Enter Category" name="category" id="Category"  required>
           
            
           

            <div>
            <a href="categories.php"> <button type="button" class="cancel">Cancel</button></a>
                <button type="submit"  class="submit">Add </button>
                <?php } ?>
            </div>
        </div>
    </form>

</body>

</html>