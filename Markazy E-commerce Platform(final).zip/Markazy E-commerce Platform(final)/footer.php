<footer>
    <div class="mainfooter">
     
        <article class="aboutus">
           <h2>About Us</h2>
               <p>Lorem ipsum dolor sit Lorem ipsum dolor sit amet,  sed do eiusmod
               tempor incididunt ut labore et dolore magna aliqua.incididunt ut labore et dolore magna . <br>
           
           </p>
      </article>
      <section class="contact">
            <h2>Contact Us in:</h2>
            <div class="social">
            <span class="cell"><span class="icon"><i class="fa fa-phone"></i></span> <a href="">+xxx xxxx xxx</a></span>
            <span class="cell"><span  class="icon"><i class="fa-brands fa-whatsapp"></i></span> <a href="#">+xxx xxxx xxx</a></span>  
            <span class="cell"><span class="icon"><i class="fa-regular fa-envelope"></i></span> <a href="markazy22@gmail.com">markazy22@gmail.com</a></span>
             <span class="cell" ><span class="icon"><i class="fa-brands fa-facebook-square"></i></span> <a href="">Markazy</a></span>
            
                       </div>
           
           
    </div>
          

    </section>
    <section class="rights">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
        <p>All Rights reserved for <span  class="allrights">Markazy<sup>&#169;</sup>2022</p></span>
    </section>
</footer>

</body>
</html>