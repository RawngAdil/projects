<?php 
session_start();
if(isset($_SESSION['ROLE'])){
    if($_SESSION['ROLE'] !== 'admin' || $_SESSION['ROLE'] !== 'superadmin'){
        header("Location:index.php");
        die;
    }else{
        header("Location:adminindex.php");
        die;
    }
}
require 'connect.php';
error_reporting(0);
$profilepic = "noprofile.png";
$profilepic2 = "noprofile.png";
$firstname = $email = $lastname = $companyname = $telnumber = $address = $password = $reppassword = $height = '';
$firstnameErr = $emailErr = $lastnameErr = $telnumberErr = $addressErr = $companynameErr = $passwordErr = $reppasswordErr = '';
$firstname2 = $email2 = $lastname2 = $storename = $telnumber2 = $address2 = $storedescrpt =  $password2 = $reppassword2 = $height2 = '';
$firstname2Err = $email2Err = $lastname2Err = $telnumber2Err = $address2Err = $storenameErr = $storedescrptErr = $password2Err = $reppassword2Err = '';
if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup'])){
    if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];    
         $folder ="images/".$filename;
         move_uploaded_file($tempname, $folder);
         $profilepic = $filename;}
   
    if(isset($_POST["firstname"])){
        $firstname=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $firstnameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $firstnameErr = "Only letters allowed";
    unset($_POST["firstname"]);}
}else{ 
$firstnameErr = "First Name is required";
}
if(isset($_POST["lastname"])){
    $lastname=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $lastnameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$lastnameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$lastnameErr = "Last Name is required";
}
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}if(isset($_POST["telnumber"])){
    $telnumber = $_POST['telnumber'];
    if(empty($_POST["telnumber"])){
        $telnumberErr = "Phone Number is required";
        unset($_POST["telnumber"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
        $telnumberErr = "Numbers only";
        unset($_POST["telnumber"]);
    }elseif(strlen($_POST["telnumber"])!=10){
        $telnumberErr = "Invalid Phone Number";
        unset($_POST["telnumber"]);
    }
    }else{
        $telnumberErr = "Phone Number is required";
    }if(isset($_POST['address'])){
    $address = $_POST['address'];
    if(empty($_POST['address'])){
        $addressErr= "Address is Required";
        unset($_POST['address']);
    }
    }else{
    $addressErr= "Address is Required";  
    }if(isset($_POST['companyname'])){
        $companyname = $_POST['companyname'];
        if(empty($_POST['companyname'])){
            $companynameErr= "Company Name is Required";
            unset($_POST['companyname']);
        }
    }else{
        $companynameErr= "Company Name is Required";  
    }if(isset($_POST['password'])){
    $password = $_POST['password'];
    if(empty($_POST['password'])){
        $passwordErr = "Password is Required";
        unset($_POST['password']);
    }elseif(strstr($_POST['password'],"\s")){
        $passwordErr = "Your password should not include whitespace";
        unset($_POST['password']);
    }
    elseif(strlen($_POST['password']) < 8){
        $passwordErr = "Your password should have at least 8 characters";
        unset($_POST['password']);
    }elseif(strlen($_POST['password']) > 16){
        $passwordErr = "Your password should not exceed 16 characters";
        unset($_POST['password']);
    }
}else{
    $passwordErr = "Password is Required";
}if(isset($_POST['reppassword'])){
    $reppassword = $_POST['reppassword'];
    if(empty($_POST['reppassword'])){
        $reppasswordErr = "Repeat your Password";
        unset($_POST['reppassword']);
    }elseif($_POST['reppassword'] !== $password){
        $reppasswordErr = "The passwords dont match";
        unset($_POST['reppassword']);
    }
}else{
    $reppasswordErr = "Repeat your Password";
}
if($firstnameErr == ''  and  $emailErr == '' and  $lastnameErr == '' and $passwordErr == '' and $reppasswordErr == '' and  $telnumberErr == '' and $addressErr == ''){
    $sql = "SELECT * FROM users";
    $result= mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) == 0){
        $role = "superadmin";
    }
    $insert = "INSERT INTO users (PROFILE_PIC,FIRST_NAME ,LAST_NAME ,EMAIL ,MOBILE_NO ,ADDRESS ,PASSWORD ,ROLE ) VALUES ('$profilepic','$firstname','$lastname','$email','$telnumber','$address','$password','Customer')";
    $result1 = mysqli_query($conn, $insert);
    if($result1){header("Location:login.php?registersuccess");
    die(); }else{
        $notification = "systemerror";
    }}else{
        $notification = "error";
        $height =  'style="height:100%"';

    }}
    elseif($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['signup2'])){
        if(isset($_FILES["uploadfile"]) && !empty($_FILES["uploadfile"]["name"])){
            $filename = $_FILES["uploadfile"]["name"];
            $tempname = $_FILES["uploadfile"]["tmp_name"];    
             $folder ="images/".$filename;
             move_uploaded_file($tempname, $folder);
             $profilepic2 = $filename;
        }
        if(isset($_POST["firstname"])){
            $firstname2=$_POST["firstname"];
            if(empty($_POST["firstname"])){
            $firstname2Err = "First Name is required";
            unset($_POST["firstname"]);
        }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
        $firstname2Err = "Only letters allowed";
        unset($_POST["firstname"]);}
    }else{ 
    $firstname2Err = "First Name is required";
    }
    if(isset($_POST["lastname"])){
        $lastname2=$_POST["lastname"];
        if(empty($_POST["lastname"])){
        $lastname2Err = "Last Name is required";
        unset($_POST["lastname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
    $lastname2Err = "Only letters allowed";
    unset($_POST["lastname"]);}
    }else{ 
    $lastname2Err = "Last Name is required";
    }
    if(isset($_POST["email"]) && !empty($_POST["email"])){
        $email2 = $_POST["email"];
    if (!filter_var($email2, FILTER_VALIDATE_EMAIL)) {
            $email2Err = "Invalid email";
            unset($_POST["email"]);
        }else{
            $sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]'";
            $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $email2Err = 'Email already exists';
        }
    }}else{
        $email2Err = "Email is required";
    }if(isset($_POST["telnumber"])){
        $telnumber2 = $_POST['telnumber'];
        if(empty($_POST["telnumber"])){
            $telnumber2Err = "Phone Number is required";
            unset($_POST["telnumber"]);
        }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["telnumber"])){
            $telnumber2Err = "Numbers only";
            unset($_POST["telnumber"]);
        }elseif(strlen($_POST["telnumber"])!=10){
            $telnumber2Err = "Invalid Phone Number";
            unset($_POST["telnumber"]);
        }
        }else{
            $telnumber2Err = "Phone Number is required";
        }if(isset($_POST['address'])){
        $address2 = $_POST['address'];
        if(empty($_POST['address'])){
            $address2Err= "Address is Required";
            unset($_POST['address']);
        }
        }else{
        $address2Err= "Address is Required";  
        }if(isset($_POST['storename'])){
            $storename = $_POST['storename'];
            if(empty($_POST['storename'])){
                $storenameErr= "Store Name is Required";
                unset($_POST['storename']);
            }
        }else{
            $storenameErr= "Store Name is Required";  
        }if(isset($_POST['storedescrpt'])){
            $storedescrpt = $_POST['storedescrpt'];
            if(empty($_POST['storedescrpt'])){
                $storedescrptErr= "Store Description is Required";
                unset($_POST['storedescrpt']);
            }
        }else{
            $storedescrptErr= "Store Description is Required";  
        }if(isset($_POST['password'])){
        $password2 = $_POST['password'];
        if(empty($_POST['password'])){
            $password2Err = "Password is Required";
            unset($_POST['password']);
        }elseif(strstr($_POST['password'],"\s")){
            $password2Err = "Your password should not include whitespace";
            unset($_POST['password']);
        }
        elseif(strlen($_POST['password']) < 8){
            $password2Err = "Your password should have at least 8 characters";
            unset($_POST['password']);
        }elseif(strlen($_POST['password']) > 16){
            $password2Err = "Your password should not exceed 16 characters";
            unset($_POST['password']);
        }
    }else{
        $password2Err = "Password is Required";
    }if(isset($_POST['reppassword'])){
        $reppassword2 = $_POST['reppassword'];
        if(empty($_POST['reppassword'])){
            $reppassword2Err = "Repeat your Password";
            unset($_POST['reppassword']);
        }elseif($_POST['reppassword'] !== $password2){
            $reppassword2Err = "The passwords dont match";
            unset($_POST['reppassword']);
        }
    }else{
        $reppassword2Err = "Repeat your Password";
    }
    
    if($firstname2Err == ''  and  $email2Err == '' and  $lastname2Err == '' and $password2Err == '' and $reppassword2Err == '' and  $telnumber2Err == '' and $address2Err == '' and $storenameErr == '' and $storedescrptErr ==''){
        $sql = "SELECT * FROM users";
        $result= mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) == 0){
            $role = "superadmin";
        }
        $insert = "INSERT INTO users (PROFILE_PIC,FIRST_NAME ,LAST_NAME ,EMAIL ,MOBILE_NO ,ADDRESS ,PASSWORD ,ROLE ) VALUES ('$profilepic2','$firstname2','$lastname2','$email2','$telnumber2','$address2','$password2','Supplier')";
        $result1 = mysqli_query($conn, $insert);
        if($result1){
        $sql2="SELECT USER_ID FROM users WHERE EMAIL = '$email2'";
        $result2 = mysqli_query($conn,$sql2);
        $row = mysqli_fetch_assoc($result2);
        $insert2 = "INSERT INTO stores (SUPPLIER_ID,STORE_NAME,STORE_DESCRIPTION,AVG_RATING) VALUES ('$row[USER_ID]','$storename','$storedescrpt',0)";
        $result3 = mysqli_query($conn,$insert2);
        if($result3){
        header("Location:login.php?registersuccess");
        die(); }
        else{$notification = "systemerror";}}else{
            $notification = "systemerror";
        }
    }else{
            $notification = "error";
            $height2 =  'style="height:100%"';
    
        }}?>


<!DOCTYPE html>
<html>
    <head>
    
     <title>REGISTRATION</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="register.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
     <script>
function validateForm() {
if(document.getElementById("companyregister").style.height == "100%"){
  if (document.getElementById("firstname").value == '') {
    alert("First Name must be filled out");
    return false;
  }else if (document.getElementById("lastname").value == '') {
    alert("Last Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if (document.getElementById("telnumber").value == '') {
    alert("Mobile Number must be filled out");
    return false;
  }else if (document.getElementById("address").value == '') {
    alert("Address must be filled out");
    return false;
  }else if (document.getElementById("companyname").value == '') {
    alert("Company Name must be filled out");
    return false;
  }else if(document.getElementById("email").value == '') {
    alert("Email must be filled out");
    return false;
  }else if(document.getElementById("password").value == '') {
    alert("Password must be filled out");
    return false;
  }else if(document.getElementById("reppassword").value == '') {
    alert("Please Confirm Your Password");
    return false;
  }
}}
function farmerform(){
var farmer = document.getElementById("farmerregister")
farmer.style.height = "100%";
}
function companyform(){
var company = document.getElementById("companyregister")
company.style.height = "100%";
}
function closefarmerform(){
    var farmer = document.getElementById("farmerregister")
farmer.style.height = "0";
}
function closecompanyform(){
    var company = document.getElementById("companyregister")
company.style.height = "0";
}

var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};

var loadimage = function(event) {
	var image = document.getElementById('output2');
	image.src = URL.createObjectURL(event.target.files[0]);
}
</script>
</head>


    <body>
        <section class="choicesection">
            <h1 class="choicehead">Register As</h1>
            <div class="choices">
            <div class="choice">
            <img src="images/farmer.jpg" onclick="farmerform()" style="cursor:pointer;">
            <h2>Farmer</h2>
            <p>Register as a Farmer and upload your products to be sold 
                online through this website for companies to purchase and distribute</p>
            </div>
            <div class="choice">
            <img src="images/company.jpg" onclick="companyform()" style="cursor:pointer;">
            <h2>Company</h2>
            <p>Register as a company and browse through this website and search for all kinds of fruits 
                and vegetables provided by farmers in which the company intends to distribute</p>
            </div>
</div>
</section>
     <section class="companyregister" id="companyregister" <?= $height?>>

     <div class="container">
        <h1> Company Registration</h1>
        <a href="javascript:void(0)" class="closebtn" onclick="closecompanyform()">&times;</a>
        <form method="post" action="" name="registerform" onsubmit="return validateForm()" enctype="multipart/form-data">
             
        <label style="cursor: pointer;">Choose Profile Picture</label><br>
        <label for="file" style="cursor: pointer;">
            <div class="image-cropper">
            <img id="output" src="images/noprofile.png" /><br>
</div>
</label>
            <input type="file"  accept="image/*" name="uploadfile" id="file" style="display: none;" onchange="loadFile(event)">

            <label for="firstname">First Name </label><span class="error" ><?= $firstnameErr?></span><br>
            <input type="text" name="firstname"  placeholder="First Name" id="firstname"  value="<?=$firstname?>"><br>

            <label for="lastname">Last Name </label><span class="error" ><?= $lastnameErr?></span><br>
            <input type="text" name="lastname"  placeholder="Last Name" id="lastname"  value="<?=$lastname?>"><br>

            <label for="email">Email </label><span class="error" ><?= $emailErr?></span><br>
            <input type="text" name="email"  placeholder="Email address" id="email"  value="<?=$email?>"><br>

            <label for="telnumber">Mobile Number </label><spam class="error"><?= $telnumberErr?></spam><br>
            <input type="text" name="telnumber" placeholder="Enter your mobile number" value="<?= $telnumber?>" id="telnumber"><br>
    
            <label for="address">Address </label><spam class="error"><?= $addressErr?></spam><br>
            <input type="text" name="address" placeholder="Enter address of current residency" value="<?= $address?>" id="address"><br>

            <label for="companyname">Company Name</label><span class="error" ><?= $companynameErr?></span><br>
            <input type="text" name="companyname"  placeholder="Company Name"   value="<?=$companyname?>" id="companyname"><br>

            <label for="password">Password </label><span class="error" ><?= $passwordErr?></span><br>
            <input type="password" name="password"  placeholder="Password" id="password"  ><br>

            <label for="reppassword"> Repeat Password </label><span class="error" ><?= $reppasswordErr?></span><br>
            <input type="password" name="reppassword" id="reppassword" placeholder="Repeat your password"><br>

            <p class="terms">By creating an account you agree to our <a href="#" >Terms & Privacy</a>.</p> <br>

            <a href="index.php"><button type="button" class="cancel formbtn">Cancel</button></a>
         <button type="submit" class="formbtn" value="signup" name="signup">Sign Up</button>
       <footer>  <p class="Login">Already have an account? <a href="login.php">Login</a></p></footer>

      
        </form>
    </div>
</section> 

<section class="farmerregister" id="farmerregister" <?= $height2?>>

<div class="container">
        <h1> Farmer Registration</h1>
        <a href="javascript:void(0)" class="closebtn" onclick="closefarmerform()">&times;</a>
        <form method="post" action="" name="registerform" onsubmit="return validateForm()" enctype="multipart/form-data">
             
            <label for="file2" style="cursor: pointer;">Choose Profile Picture</label><br>
            <label for="file2">
            <div class="image-cropper">
            <img id="output2"  src="images/noprofile.png"/><br>
            </div>
</label>
            <input type="file"  accept="image/*" name="uploadfile" id="file2" style="display: none;" onchange="loadimage(event)">

            <label for="firstname">First Name </label><span class="error" ><?= $firstname2Err?></span><br>
            <input type="text" name="firstname"  placeholder="First Name" id="firstname"  value="<?=$firstname2?>"><br>

            <label for="lastname">Last Name </label><span class="error" ><?= $lastname2Err?></span><br>
            <input type="text" name="lastname"  placeholder="Last Name" id="lastname"  value="<?=$lastname2?>"><br>

            <label for="email">Email </label><span class="error" ><?= $email2Err?></span><br>
            <input type="text" name="email"  placeholder="Email address" id="email"  value="<?=$email2?>"><br>

            <label for="telnumber">Mobile Number </label><spam class="error"><?= $telnumber2Err?></spam><br>
            <input type="text" name="telnumber" placeholder="Enter your mobile number" value="<?= $telnumber2?>" class="field"><br>
    
            <label for="address">Home Address </label><spam class="error"><?= $address2Err?></spam><br>
            <input type="text" name="address" placeholder="Enter address of current residency" value="<?= $address2?>" class="field"><br>

            <label for="storename">Store Name</label><span class="error" ><?= $storenameErr?></span><br>
            <input type="text" name="storename"  placeholder="Store Name"   value="<?=$storename?>"><br>

            <label for="storedescrpt">Store Description</label><span class="error" ><?= $storedescrptErr?></span><br>
            <textarea type="text" name="storedescrpt"  placeholder="Store Description"><?=$storedescrpt?></textarea><br>

            <label for="password">Password </label><span class="error" ><?= $password2Err?></span><br>
            <input type="password" name="password"  placeholder="Password" id="password"  ><br>

            <label for="reppassword"> Repeat Password </label><span class="error" ><?= $reppassword2Err?></span><br>
            <input type="password" name="reppassword" id="reppassword" placeholder="Repeat your password"><br>

            <p class="terms">By creating an account you agree to our <a href="#" >Terms & Privacy</a>.</p> <br>

            <a href="index.php"><button type="button" class="cancel formbtn">Cancel</button></a>
         <button type="submit" class="formbtn" value="signup" name="signup2">Sign Up</button>
       <footer>  <p class="Login">Already have an account? <a href="login.php">Login</a></p></footer>

      
        </form>
    </div>
</section> 
    
</body>
</html>