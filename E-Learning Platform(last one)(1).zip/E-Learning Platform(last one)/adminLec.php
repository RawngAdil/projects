<?php 
session_start();

require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:login.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:index.php");
  die();
}
 if ($_SESSION['role']==3) {
   header("Location:admincourses.php");
  die();
}
if (!isset($_GET['course_id'])) {
   header("Location:admincourses.php");
   die();
}

$_SESSION['id']=$_GET['course_id'];
      

      $lecName = $lecUrl = $lecNameErr = $lecUrlErr = '';
  if($_SERVER['REQUEST_METHOD'] == "POST"){

    if(isset($_POST["name"])){
        $lecName=$_POST["name"];
        if(empty($_POST["name"])){
        $lecNameErr = "Lecture Name is required";
        unset($_POST["name"]);}
}
if (isset($_POST["url"])){
        $lecUrl=$_POST["url"];
        if(empty($_POST["name"])){
        $lecUrlErr = "Lecture Url is required";
        unset($_POST["url"]);}
}
  if ($lecNameErr ==''&& $lecUrlErr == '') {
      $sql = "INSERT INTO lectures (lecture_name , url , course_id ) VALUES ('$lecName' , '$lecUrl','$_GET[course_id]')";

        if (!mysqli_query($conn, $sql)) {
            echo "Error:".$sql."<br>.".mysqli_error($conn);
        }
        unset($_POST["send"]);
         unset($_POST["name"]);
          unset($_POST["url"]);
  }
}
       
   
 
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css" />
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL Admin</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">

</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="admin.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
          
            <div class="log"> <a href="login.php" >Logout</a></div>
            	
             
             <a href="users.php">Users</a>
             <a  class="active" href="admincourses.php">Courses</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search" action="admincourses.php" method="get">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>


          
        </header>
        <div class="container">
        <button id="add" type="button" onclick="AddFunction()">Add Lecture </button>

        <section id="addcourse">
        <h2>Add Lectures</h2>
        <form action="" method="post" >
            <label for="name">Lecture Name</label><br>
            <input type="text" name="name" id="name" placeholder="Lecture Name"><br>

              <label for="url">Lecture Youtube Url</label><br>
            <input  type="text" name="url" id="url" placeholder="Lecture Url"><br>

            <button type="submit" id="send" > Send </button>
            
        </form>
  </section>
  
  <script>
         function AddFunction(){
             var x = document.getElementById("addcourse");
            
             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }
            }
    </script>


<section >
  
    <?php
              $sql1 = "SELECT * FROM courses WHERE course_id = '$_GET[course_id]' "; 
                $result1 = mysqli_query($conn ,$sql1);
                $course = mysqli_fetch_assoc($result1) ;
                
     ?>
        <h1>
            <?=$course['course_name']?> Lectures
        </h1>

        <?php  
        
                $sql2 = "SELECT * FROM lectures WHERE course_id = '$_GET[course_id]'";
                $result2 = mysqli_query($conn ,$sql2); 
       
            if ( mysqli_num_rows($result2) > 0) {?>
                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Url</th>
                        <th>Actions</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result2)) {?>
                        
                        <tr>
                            <td><?=$row['lecture_id']?></td>
                             <td><?=$row['lecture_name']?></td>
                              <td><?=$row['url']?></td>
                                <form action="delete.php" method="get"><td><a href="delete.php?lecture_id=<?php echo$row['lecture_id'] ?>">Delete</a></td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>

 

       <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

    </article>
      </div>
</body>
</html>

