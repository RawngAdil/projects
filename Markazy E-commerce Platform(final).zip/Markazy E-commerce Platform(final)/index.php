<?php
session_start();
$notification = '';
if(isset($_GET['addcartsuccess'])){
  $notification = 'Product added to your cart succesfully';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['addcartfail'])){
  $notification = 'System Error: Product could not be added to cart';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['productexist'])){
  $notification = 'This product is already in your cart';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['ordersuccess'])){
  $notification = 'Your order has been placed successfully';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['profileeditsuccess'])){
  $notification = 'Your profile has been updated successfully';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
if(isset($_GET['emptycart'])){
  $notification = 'You haven\'t added anything to your cart yet';?>
<script>
    history.pushState(null, "", location.href.split("?")[0]);
 
</script>
<?php }
include 'notification.php';
?>
<!DOCTYPE html>
<html>

    <head>
     <title>Markazy Home Page</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <?php
    include 'navigation.php';?>
<main>
<section class="jumbtron">
  <div class="jumbtroncontainer">
    <p class="jumbtronslogan p1">Beyond <span class="strong">Nutrition</span> </p>
    <p class="jumbtronslogan p2"> Beyond <span class="strong">Healthy</span></p>

  </div>
</section>

<section class="graph">
  <h2>Most In-Demand Products</h2>
  <canvas id="canvas" height="350" style="display: block; box-sizing: border-box; max-height: 500px; max-width: 900px; padding: 10px; margin-left: 2%;"></canvas>
<?php 
$sql="SELECT DEFPRODUCT_ID,SUM(SALES) as 'TotalSales'
      FROM products 
      GROUP BY DEFPRODUCT_ID
      ORDER BY 'TotalSales' DESC
      LIMIT 7";
$result=mysqli_query($conn,$sql);
$rows =array();
$rows2=array();
$i=0;
while($row=mysqli_fetch_assoc($result)){
  $sql2="SELECT DEFPRODUCT_NAME FROM defproducts WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
  $result2=mysqli_query($conn,$sql2);
  $names=mysqli_fetch_assoc($result2);
  array_push($rows,$names['DEFPRODUCT_NAME']);
  array_push($rows2,$row['TotalSales']);
  $i=$i+1;
}
?>
<script type="text/javascript">
if (window.matchMedia("(min-width: 610px)").matches){
  var size = 15

}
else if (window.matchMedia("(min-width: 430px)").matches) {
  var size = 13}else{
    var size = 10
  }
 var chr = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    var options = {
    scales: {
        yAxes: [{
            ticks: {
                fontSize: 40
            }
        }]
    }
}
    var data = {
      type: "bar",
      data: {
        labels: <?php echo json_encode($rows);?>,
        datasets: [{
          label: "Number of kilos sold",
          backgroundColor: [
           <?php $sql="SELECT DEFPRODUCT_ID,SUM(SALES) as 'TotalSales'
      FROM products 
      GROUP BY DEFPRODUCT_ID
      ORDER BY 'TotalSales' DESC
      LIMIT 7";
$result=mysqli_query($conn,$sql);
while($i>0){echo
      "'rgb(29, 107, 29)',";
      $i=$i-1;}?>
    ],
    borderColor: [
      'rgb(255, 99, 132)',
      'rgb(255, 159, 64)',
      'rgb(255, 205, 86)',
      'rgb(75, 192, 192)',
      'rgb(54, 162, 235)',
      'rgb(153, 102, 255)',
      'rgb(201, 203, 207)'
    ],
    borderWidth: 1,
          fillColor: "blue",
          strokeColor: "green",
          data: <?php echo json_encode($rows2);?>
        }]
      },
    
    options: {
    scales: {
      x: {
        title: {
          font: {
            size: 14,
            weight: "300",
            family: 'vazir'
          },
          color: 'black'
          
        },

        ticks: {
          font: {
            
            size: size,
            weight: "600",
            family: "Merienda"
          },
          color: 'black',
        },
      },
      y: {
        title: {
          font: {
            size: 200,
            weight: "300",
            family: 'vazir'
          },
          color: 'black'
          
        },

        ticks: {
          font: {
            
            size: size,
            weight: "600",
            family: "Merienda"
          },
          color: 'black',
        },
      },
      }
    
  }
}
    var myfirstChart = new Chart(ctx, data);
</script>
  </section>
<h2>Price Changes</h2>
<section class="changes">
<table >
  <tr>
    <th>Product</th>
    <th>Price change</th>
    <th>Average Price Now</th>
  </tr>
    <?php
    while($row=mysqli_fetch_assoc($result)){
      $sql6= "SELECT MAX(PRODUCT_ID) as MaxPRO FROM products WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
      $result6=mysqli_query($conn,$sql6);
      $row6=mysqli_fetch_assoc($result6);
      $sql2 = "SELECT DEFPRODUCT_ID,AVG(PRICE) as AvgPricebefore FROM products WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]' AND NOT PRODUCT_ID = '$row6[MaxPRO]'";
      $result2=mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      $sql3="SELECT DEFPRODUCT_ID,AVG(PRICE) as 'AvgPriceNow'
      FROM products 
      WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]'";
      $result3=mysqli_query($conn,$sql3);
      $row3=mysqli_fetch_assoc($result3);
      $sql4="SELECT DEFPRODUCT_NAME FROM defproducts WHERE DEFPRODUCT_ID = '$row[DEFPRODUCT_ID]' ";
      $result4=mysqli_query($conn,$sql4);
      $row4=mysqli_fetch_assoc($result4);
      $change = $row3['AvgPriceNow']-$row2['AvgPricebefore'];
    ?>
    <tr>
    <td><?= $row4['DEFPRODUCT_NAME']?></td>
    <td><?php if( $change > 0){echo "<i class='fa fa-caret-up' aria-hidden='true'></i>".number_format((float)$change, 2, '.', '');
    }else{
      echo "<i class='fa fa-caret-down' aria-hidden='true'></i>".number_format((float)$change, 2, '.', '');}?>
    </td>
    <td>$<?= number_format((float)$row3['AvgPriceNow'], 2, '.', '');?></td>
    </tr>

    <?php ;}?>
  </table>
    
  </section>

  <section>
<h2>Most Recent Additions</h2>

<section class="offers products">
  <?php
  $i=0;
  $sql = "SELECT * FROM products INNER JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID ORDER BY PRODUCT_ID DESC LIMIT 20";
  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_assoc($result)){
$i=$i+1;
?>
  <div class="productbox">
  <a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"><img src="images/<?=$row['PRODUCT_IMG']?>" width="100%" height="100%"></a>
    <div class="content"> 
    <h3><?= $row['PRODUCT_NAME']?></h3>
    <h4><?= $row['STORE_NAME']?></h4>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php $star2 = round($row['Average_rating'],0);?>

    <div class="s-rating">
    <spam class="star-rating">
            <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
          </spam>
          <spam class="rating"><?=$row['Average_rating']?> / 5.0</spam> <br>
  </div>
   
    <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a>
  </div>
      </div>
      <?php ;}?>
      </section>
      <button class="viewmore"><a href="products.php?newadditions=DESC" >View More <i class="fa-solid fa-arrow-right"></i></a></button>
      <br>
  </section>

<section>
      <h2>Vegetables of the Season</h2>
 
<section class="vegetable products">
<?php
  $season = "";
  $today = new DateTime();
  $spring = new DateTime('March 30');
  $summer = new DateTime('June 30');
  $fall = new DateTime('September 30');
  $winter = new DateTime('December 30');
  switch(true) {
    case $today >= $spring && $today < $summer:
        $season = "Spring";
        break;

    case $today >= $summer && $today < $fall:
      $season = "Summer";
        break;

    case $today >= $fall && $today < $winter:
      $season = "Autumn";
        break;

    default:
    $season = "Winter";
}
$sql = "SELECT * FROM products JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID  JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE defproducts.SEASON = '$season' AND subcategories.CATEGORY = 'Vegetable' LIMIT 20";
  $result = mysqli_query($conn,$sql);

  while($row = mysqli_fetch_assoc($result)){
    $i =$i+1;?>

  <div class="productbox">
    <a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"><img src="images/<?=$row['PRODUCT_IMG']?>" width="100%" height="100%"></a>
    <div class="content"> 
    <h3><?= $row['PRODUCT_NAME']?></h3>
    <h4><?= $row['STORE_NAME']?></h4>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php $star2 = round($row['Average_rating'],0);?>

    <div class="s-rating">
    <spam class="star-rating">
            <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
          </spam>
          <spam class="rating"><?=$row['Average_rating']?> / 5.0</spam> <br>
  </div>
  
    <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a>
  </div>
      </div>
      <?php ;}?>
      </section>

      <button class="viewmore"><a href="products.php?seasonvegetables=<?=$season?>" >View More <i class="fa-solid fa-arrow-right"></i></a></button>
      <br>
  </section>

<section>
  <h2>Fruits of the season</h2>
 
<section class="fruits products">
  <?php
$sql = "SELECT * FROM products JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID  JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE defproducts.SEASON = '$season' AND subcategories.CATEGORY = 'Fruit' LIMIT 20";
  $result = mysqli_query($conn,$sql);

  while($row = mysqli_fetch_assoc($result)){
  $i=$i+1;?>
  <div class="productbox">
  <a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"><img src="images/<?=$row['PRODUCT_IMG']?>" width="100%" height="100%"></a>
    <div class="content"> 
    <h3 ><?= $row['PRODUCT_NAME']?></h3>
    <h4><?= $row['STORE_NAME']?></h4>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php $star2 = round($row['Average_rating'],0);?>

    <div class="s-rating">
   
   <spam class="star-rating">
           <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
           <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
           <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
           <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
           <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
         </spam>
         <spam class="rating"><?= $row['Average_rating']?> / 5.0</spam>
     </div>
    <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a>
  </div>
      </div>
      <?php ;}?>
      </section>
      <button class="viewmore"><a href="products.php?seasonfruits=<?=$season?>" >View More <i class="fa-solid fa-arrow-right"></i></a></button>
  </section>
  </main>
  <?php
  include 'footer.php';
  ?>