<?php

session_start();
  require 'connect.php';

  if (isset($_GET['course_id'])) {
  	$_SESSION['course_id']=$_GET['course_id'];


$sql = "DELETE courses FROM courses WHERE course_id = '$_GET[course_id]'";
$sql2 = "DELETE lectures FROM lectures WHERE course_id = '$_GET[course_id]'";
              $result = mysqli_query($conn, $sql);
        $result2 = mysqli_query($conn, $sql2);
        if ($result && $result2) {
        	 header("Location:admincourses.php");
        }
       }

     if (isset($_GET['user_id'])) {
     	$_SESSION['user_id']=$_GET['user_id'];
     	$sql = "DELETE users FROM users WHERE user_id = '$_GET[user_id]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
        	header("Location:users.php");
        }
        
     }

     if (isset($_GET['lecture_id'])) {
     	$_SESSION['lecture_id']=$_GET['lecture_id'];
     	$sql = "DELETE lectures FROM lectures WHERE lecture_id = '$_GET[lecture_id]'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
        	header("Location:adminlec.php?course_id=$_SESSION[id]");
        }
        
     }

