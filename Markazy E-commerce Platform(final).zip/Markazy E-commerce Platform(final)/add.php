<?php
error_reporting(0);
session_start();
require 'connect.php';
error_reporting(0);

     if (isset($_GET['USER_ID'])) {
     	$_SESSION['USER_ID']=$_GET['USER_ID'];
     	$sql3 = "DELETE FROM users WHERE USER_ID = '$_GET[USER_ID]'";
        $result3 = mysqli_query($conn, $sql3);
        if ($result3) {
        	header("Location:users.php");
        } 
        
     }
     
     ?>
