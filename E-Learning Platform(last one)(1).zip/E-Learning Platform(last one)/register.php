<?php
session_start();

require 'connect.php';
$name1 =$name2= $email =  $psw = $pswrepeat = '';
$nameErr = $emailErr = $pswErr = $repeat_err = '';
if($_SERVER['REQUEST_METHOD'] == "POST"){

    if(isset($_POST["firstname"])){
        $name1=$_POST["firstname"];
        if(empty($_POST["firstname"])){
        $nameErr = "First Name is required";
        unset($_POST["firstname"]);
    }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["firstname"])){
    $nameErr = "Only letters allowed";
    unset($_POST["Firstname"]);}
}else{ 
$nameErr = " Name is required";
}
if(isset($_POST["lastname"])){
    $name2=$_POST["lastname"];
    if(empty($_POST["lastname"])){
    $nameErr = "Last Name is required";
    unset($_POST["lastname"]);
}elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["lastname"])){
$nameErr = "Only letters allowed";
unset($_POST["lastname"]);}
}else{ 
$nameErr = " Name is required";
}
if(isset($_POST["email"])){
    $email = $_POST["email"];
    
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
    }else{
        $sql = "SELECT * FROM users WHERE email = '$_POST[email]'";
        $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                $emailErr = 'Email already exists';
    }
}}else{
    $emailErr = "Email is required";
}
    if(isset($_POST['psw'])){
    $psw = $_POST['psw'];
    if(empty($_POST['psw'])){
        $pswErr = "Password is Required";
        unset($_POST['psw']);
    }elseif(strstr($_POST['psw'],"\s")){
        $pswErr = "Your password should not include whitespace";
        unset($_POST['psw']);
    }
    elseif(strlen($_POST['psw']) > 16){
        $pswErr = "Your password should not exceed 16 characters";
        unset($_POST['psw']);
    }
    elseif(strlen($_POST['psw']) < 8){
        $pswErr = "Your password should not be less than 8 characters";
        unset($_POST['psw']);
    }
}else{
    $pswErr = "Password is Required";
}if(isset($_POST['pswrepeat'])){
    $pswrepeat = $_POST['pswrepeat'];
    if(empty($_POST['pswrepeat'])){
        $repeat_err = "Repeat your Password";
        unset($_POST['pswrepeat']);
    }elseif($_POST['pswrepeat'] !== $psw){
        $repeat_err = "Password doesn’t match with confirm";
        unset($_POST['pswrepeat']);
    }
}else{
    $repeat_err = "Repeat your Password";
}
if($nameErr == ''  and  $emailErr == '' and  $pswErr == '' and $repeat_err == ''){


    $sql = "SELECT * FROM users";
    $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result)==0) {
      $insert= "INSERT INTO users (first_name  , last_name , email ,  password , role) VALUES ('$name1' ,'$name2', '$email' ,'$psw' , '2')";
   $result1 = mysqli_query($conn, $insert);
   header("Location:login.php");
  }
  else {
   $insert= "INSERT INTO users (first_name , last_name , email ,  password ) VALUES ('$name1' ,'$name2', '$email' ,'$psw')";
   $result1 = mysqli_query($conn, $insert);
   
    header("Location:login.php"); } }
    }?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="register.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
    <div class="container">
    <h1  class="signup">Sign Up</h1>

<form action="" method="post" >

        
      


       <label for="firstname"><b>First Name</b></label> <spam class="err"><?= $nameErr?></spam><br>
            <input type="text" placeholder="Enter First Name" name="firstname" id="firstname" required><br>

         <label for="lastname"><b>Last Name</b></label> <spam class="err"><?= $nameErr?></spam><br>
            <input type="text" placeholder="Enter Last Name" name="lastname" id="lastname" required><br>

        <label for="email"><b>Email</b></label>  <spam class="err"><?= $emailErr?></spam><br>
        <input type="text" placeholder="Enter Email" name="email" id="email" > <br>
       

        <label for="password"><b>Password</b></label> <spam class="err"><?= $pswErr?></spam><br>
        <input type="password" placeholder="Enter Password" name="psw" ><br>
       

        <label for="pswrepeat"><b>Confirm Password</b></label> <spam class="err"><?= $repeat_err ?></spam><br> 
        <input type="password" placeholder="Repeat Password" name="pswrepeat" ><br>
       

        <p class="terms">By creating an account you agree to our <a href="#" >Terms & Privacy</a>.</p> <br>
       
        <a href="index.php"> <button type="button" class="cancel formbtn">Cancel</button></a>
         <button type="submit" class="formbtn">Sign Up</button>
       <footer>  <p class="Login">Already have an account? <a href="login.php">Login</a></p><footer>
        </div>
</form>
</div>
</body>
</html>
 
       