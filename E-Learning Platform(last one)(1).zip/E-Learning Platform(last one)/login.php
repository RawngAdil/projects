<?php
session_start();
if ( isset( $_SESSION['email'] )  && $_SESSION['role']==1)  {
    header('Location: index.php');
die();
}
if ( isset( $_SESSION['email'] ) && $_SESSION['role']==2)  {
    header('Location:admin.php');
die();
}
require 'connect.php';
$email = $psw =   $login_failed='';
$emailErr =  $pswErr = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]); 
    }

} if(isset($_POST['psw'])){
    $psw = $_POST['psw'];
    if(empty($_POST['psw'])){
        $pswErr = "Password is Required";
        unset($_POST['psw']);
    } }
    if($emailErr == '' and  $pswErr == '' ){
    $sql = "SELECT * FROM users WHERE email = '$_POST[email]' and password = '$_POST[psw]'";
    $result = mysqli_query($conn, $sql);
    $role = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0 ){
        $_SESSION['email'] = $_POST['email'];
        
     $_SESSION['role'] = $role['role'];
        header("Location: index.php");
    } else {
        $login_failed = '<br><span class="err">Incorrect Email or Password</span>';
    }
} }

?>


<!DOCTYPE html>
<html>
<head>
	<title>login</title>
    <link rel="stylesheet" type="text/css" href="register.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
 <div class="container">
    
       
        <h1 class="signup">Login</h1>
        <?=$login_failed ?>
  
    <form action="" method="post" >

       <div>
            
       <label for="email"><b>Email</b></label>   <spam class="err"><?= $emailErr?></spam><br>
            <input type="text" placeholder="Enter Email" name="email" id="email"> <br>
          

            <label for="password"><b>Password</b></label><spam class="err"><?= $pswErr ?></spam><br></div>
            <input type="password" placeholder="Enter Password" name="psw">
            

            <div id="btn">
            <a href="index.php"> <button type="button" class="cancel formbtn">Cancel</button></a>
             <button type="submit" class="login formbtn">Login</button>
            <footer> <p>Don’t have an account? <a href="register.php">Sign Up</a></p></footer>
               
            </div>
        
    </form>
    </div>
    </body>
</html>