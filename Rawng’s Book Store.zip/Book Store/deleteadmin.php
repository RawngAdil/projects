<?php 
session_start();
$_SESSION['id']=$_GET['id'];
require 'connect.php';
$sql=" DELETE from admins WHERE id='$_SESSION[id]' ";
    $result = mysqli_query($conn, $sql); 
    if($result){
        $success ='<span class="success">1 admin deleted successfuly</span>';
         header("Location:admins.php");
        echo $success;
    }
     else{
         $fail='<span class="err">Failed to delete </span>';}
 

 ?>