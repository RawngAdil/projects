<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
  header("Location:login.php");
  die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
header("Location:index.php");
die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Stores </title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>
<h1>Stores</h1>
    
       <?php 
        $sql = "SELECT * FROM `stores` ";
        $result = mysqli_query($conn ,$sql);
    if ( mysqli_num_rows($result) > 0) {

        $sql2 = "SELECT * FROM `` ";
        $result = mysqli_query($conn ,$sql);
       ?>
         <script>
function filter2() {
  var y = '';
var x = document.getElementById("filterstore")
if(x.value == "Store Name"){
 y = 1
}else if(x.value == "ID"){
 y = 0
}else if(x.value == "Store Description"){
 y = 2
}
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("allstores");
  filter = input.value.toUpperCase();
  table = document.getElementById("storestable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[y];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<input type="text" id="allstores" onkeyup="filter2()" placeholder="Search for names.." class="field"><br>
<div class="searchfilter">
<label>Search by:</label>
<select id="filterstore" onclick="filter()">
  <option>Store Name</option>
  <option>ID</option>
   <option>Store Description</option>
</select>
<div class="searchfilter">
       <section class="tablecontainer">
       
                <table class="table" id="storestable">

                <tr>
                        <th>ID</th>
                        <th>Store Name</th>
                        <!--<th>Supplier Name</th> -->
                        <th>Store Description</th>
                        <th>Average Rating</th>
                        <th>Delete</th>
                      
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                       
                        <tr>
                            <td><?=$row['STORE_ID']?></td>
                            <td><?=$row['STORE_NAME']?></td>
                            <!-- <td><?//=$row['']?></td> -->
                            <td><?=substr($row['STORE_DESCRIPTION'], 0 , 50)?></td>
                            <td><?=$row['AVG_RATING']?></td>
                           
                                <form action="remove.php" method="GET">
                                    <td><a href="remove.php?STORE_ID=<?=$row['STORE_ID']?>">Remove</a> </td>
                            </form>
                            
                        </tr>

                 <?php  } } ?>
                </table>
                    </section>

                <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>