<?php 
session_start();
require 'connect.php';
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name] Order"."'");
  if($results->num_rows == 1){

$sql1=" DROP TABLE  `$row[User_Name] Order`  ";
    $result1 = mysqli_query($conn, $sql1); 
    if($result1){
         header("Location:mycart.php.php");
        
    }
     else{
         $fail='Failed to Cancel ';}
 

     }?>