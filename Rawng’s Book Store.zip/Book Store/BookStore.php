<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location:userlogin.php");
}
require 'connect.php';
?>
<!DOCTYPE html>
<html>
    <head>
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
    
        <title>Book Store</title>
        <style>
            <?php include "style2.css"?>
            <?php include "style4.css"?>
          
            #books {
            margin-top:2%;
            margin-bottom:2%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;   
            font-family: 'Merienda';          
       }

        #books td,
        #books th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            padding: 8px;
        }

        #books tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
            color:black;
}
        }

        #books tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #books th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
           
        }
        .not{
     padding: 20px 20px 20px 20px;
    background: radial-gradient(circle, rgba(236, 227, 227, 0.619),  rgba(107, 63, 63, 0.623));
    justify-content: center; 
    margin: 10% 3% 1% 3%;
    border-radius: 25px;
    position:absolute;
    left: 38%;
    top:35%;
     color:rgb(97, 17, 17);
    text-shadow: 3px 2px 3px rgba(7, 7, 7, 0.812);
    font-size:60px;
	text-align:center;    
    margin: 2% auto;
      }
      

        </style>
    </head>
    <body id="main" class="lightmood">
    
        <script>
            history.pushState(null, "",location.href.split("?")[0]);
         </script>
 <?php 
        if(isset($_GET['orderdone'])){
      
      echo '<script type="text/javascript">
     alert("Your Order placed sucsseccfully ") 
     </script>';
} ?>
        <header>
    <div id="nav" class="topnav container-lightmood">
        <a class="active" href="BookStore.php">Home</a>
        <a  href="aboutus.php">About Us</a>
        <a href="mycart.php">My Cart</a>
        <a href="userlogout.php">Logout</a>
        </div>
        <form action="" method="get" >
            <div class="search">
        <input id="search" class="lightbar" type="text" placeholder="Search.." name="search">
        <button id=searchbtn class="lightbtn"><i class="fa-solid fa-magnifying-glass"></i></button>
</div>
</form>

 <script>
   function switchTheme() {
         var theme = localStorage.getItem('theme');
         body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
    search=document.getElementById("search");
    searchbtn=document.getElementById("searchbtn");
         if (theme === 'darkmode') {
            new_theme = 'lightmode';
         } else {
            new_theme = 'darkmode';
         }
         body.classList.remove(theme);
         myBtn.classList.remove(theme);
         nav.classList.remove(theme);
         search.classList.remove(theme);
         searchbtn.classList.remove(theme);
         body.classList.add(new_theme);
         myBtn.classList.add(new_theme);
         nav.classList.add(new_theme);
         search.classList.add(new_theme);
         searchbtn.classList.add(new_theme);
         localStorage.setItem('theme', new_theme);
      }

      window.addEventListener('load', function () {
         var theme = localStorage.getItem('theme');
         if (theme === null || theme === undefined) {
            theme = 'lightmode';
            localStorage.setItem('theme', theme);
         }
         var body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
    search=document.getElementById("search");
    searchbtn=document.getElementById("searchbtn");
    body.classList.add(theme);
         myBtn.classList.add(theme);
         nav.classList.add(theme);
         search.classList.add(theme);
         searchbtn.classList.add(theme);
      })
</script>

</header>
<?php if(isset($_GET['msg'])){
     echo '<script type="text/javascript">
     alert("The book added to cart successfully ") 
     </script>';
} ?>
<div class="filter"><i class="fa-solid fa-filters"></i></div>
<buttom id="themes"  onclick="switchTheme()" class="light"><i class="fa-solid fa-moon"></i></buttom>
<?php 
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
$result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name]"."'");
if($results->num_rows == 1){
 $sql12="SELECT * FROM  `$row[User_Name]` ";
 $result12=mysqli_query($conn,$sql12);
$num= mysqli_num_rows($result12) ;
?>
<div class="cart"> 
<a href="mycart.php"><button class="carticon"><i class="fa-solid fa-cart-plus"></i></button></a>
    <div class="num" ><?=$num?></div>
</div>
<?php } ?>
<?php
 if(isset($_GET['search'])){
 $_SESSION['search']=$_GET['search'];
$sql= "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price,books.Buy FROM books JOIN authors ON books.Author_ID=authors.Author_ID
 WHERE Book_Name LIKE '%$_SESSION[search]%' ";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0){
?>


 <div class="container">
     <table id="books">
                <tr>
                   
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                    <th>Buy</th>

                </tr>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                        <form action="mycart.php" method="GET" id="buy">
                        <td><a href="mycart.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        <?=$row['Buy']?></a></td>
                </form>
                        
                    </tr>
                <?php } ?>
            </table>
        <?php  } else {
            echo '<span class="not"> No Result </span>';
        } } ?>
</div>
  <div class="base">   
<div class="maincontaner">
     <?php
     $sql = "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price,books.image,books.Buy,
     books.Editing,books.Delete FROM books JOIN authors ON books.Author_ID=authors.Author_ID ORDER BY Book_ID ASC
     ";
     $result = mysqli_query($conn, $sql);
     $row = mysqli_fetch_assoc($result);
    
            ?>
           
  
     <?php while ($row = mysqli_fetch_assoc($result)) { 
            ?>
     <div class="book-cell">
     <div class="book-img">
     <img src="<?=$row['image']?>" alt="Book Image" class="book-photo">
     </div>
     <div class="book-content">
     <div class="book-title"><?=$row['Book_Name']?></div>
     <div class="book-author">By <?=$row['Author_Name']?></div>
     <div class="book-price">$ <?=$row['Price']?></div>
     <div class="my-cart"><a href="mycart.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        <?=$row['Buy']?></a> </div>

    
     
   </div>

   </div>
            
    
    <?php } ?>
    </div>
     </div>
    </body>
</html>