<?php
session_start();
require 'connect.php';
error_reporting(0);
if(!isset($_SESSION['ID'])){
    header("Location:login.php");
    die;
}
if(isset($_SESSION['ROLE'])){
  if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){
    header("Location:admin.php");
    die;
  }
}
?>
<!DOCTYPE html>
<html>
 
    <head>
     <title> Profile</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
      <?php  include 'navigation.php';?>
      <?php
      if($_SESSION['ROLE'] == 'Supplier'){
        $sql = "SELECT * FROM users JOIN stores ON stores.SUPPLIER_ID = users.USER_ID WHERE USER_ID = '$_SESSION[ID]'";
        $result = mysqli_query($conn,$sql);
        }else{
            $sql = "SELECT * FROM users WHERE USER_ID = '$_SESSION[ID]'";
            $result = mysqli_query($conn,$sql);
        }
    while($row = mysqli_fetch_assoc($result)){?>
      <div class="myprofile">
      <a href="profileedit.php"><button class="addnew"> <i class="fa-solid fa-pen"></i> Edit profile</button></a><br>
      <div class="content2">
       <img class="profile" src="images/<?=$row['PROFILE_PIC']?>" /><br>
       <h1> <?=$row['FIRST_NAME']?> <?=$row['LAST_NAME']?></h1><br><br>


<span><span class="label">Email </span> : <?=$row['EMAIL']?> </span><br>
<span><span class="label">Mobile Number </span> : <?=$row['MOBILE_NO']?> </span><br>
<?php if($_SESSION['ROLE'] == 'Customer'){?>
<span><span class="label">Company Name </span> : <?=$row['COMPANY_NAME']?> </span><br>
<?php }elseif($_SESSION['ROLE'] == 'Supplier'){?>
<span><span class="label">Store Name </span> : <?=$row['STORE_NAME']?> </span><br>
<span><span class="label">Store Description </span> : <?=$row['STORE_DESCRIPTION']?> </span><br>
<?php }?>
<span><span class="label">Address </span> : <?=$row['ADDRESS']?> </span><br>

</div>

    </div>
      <?php } include 'footer.php'?>
    