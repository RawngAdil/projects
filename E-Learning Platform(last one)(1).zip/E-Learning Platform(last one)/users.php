<?php 
session_start();
require 'connect.php';
if(!isset($_SESSION['email'])){
    header("Location:register.php");
    die();
}
  if ($_SESSION['role']==1) {
   header("Location:index.php");
  die();
}
if ($_SESSION['role']==3) {
   header("Location:admincourses.php");
  die();}
  ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css" />
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	<title>WDPL Admin</title>
    <meta content="width=device-width,initial-scale=1" name="viewport">

</head>
<body>

    <article>

    <header>
     	<!-- The main navigation bar -->
         <button  id="menu" class="menu" onclick="myFunction()"><i class="fa-solid fa-bars"></i></button>
         <button id="searchbtn2" class="searchbtn btn2" onclick="searchfunction()"><i class="fa fa-search"></i></button>
         <button id="xmark" class="searchbtn btn2"  onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></button>
         <!-- the logo take you to the home page  -->
         <div class="logo" id="logo"><a href="admin.php"><img src="logo.png " alt="Logo" ></a></div>

     	<nav id="nav" class="mainNav">
     		
          
            <div class="log"> <a href="login.php" >Logout</a></div>
            	
             
             <a class="active" href="users.php">Users</a>
             <a href="admincourses.php">Courses</a>
     	
             
     	</nav>
     	<!-- The Search bar -->
     	<form class="search" action="" method="get">
             <div id="searchbar">
     		<input type="search" name="search" id="searchinput" class="searchbar">
     		<!-- The search icon -->
     		<button type="submit"  id="btn1" class="searchbtn btn1"><i class="fa fa-search"></i></button>

</div>
     	</form>
        
     </header>
     <script>
         function myFunction(){
             var x = document.getElementById("nav");
             var y = document.getElementById("searchbtn2");
            // var s = document.getElementById("searchbar");


             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }

             if ( y.style.display === "none"){
                 y.style.display ="block";
             }else{
                 y.style.display ="none";
             }

           
   // if ( s.style.display === "block"){
   // s.style.display ="none";
  //  }else{
 //   s.style.display ="block";}

         }
         function searchfunction(){
            var s = document.getElementById("searchbar");
            var x = document.getElementById("logo");
            var y = document.getElementById("searchinput");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");
            var menu = document.getElementById("menu");

            


if ( s.style.display === "block"){
    s.style.display ="none";
}else{
    s.style.display ="block";}


    if ( x.style.display === "none"){
                 x.style.display ="block";
             }else{
                 x.style.display ="none";
             }

             if ( y.style.display === "block"){
    y.style.display ="none";
}else{
    y.style.display ="block";}

    if ( m.style.display === "block"){
    m.style.display ="none";
}else{
    m.style.display ="block";}

    if ( sb2.style.display === "none"){
                 sb2.style.display ="block";
             }else{
                 sb2.style.display ="none";
             }

             if ( menu.style.display === "none"){
                 menu.style.display ="block";
             }else{
                 menu.style.display ="none";
             }
         }
     </script>


<div class="container">
  <!-- <section>

       <button id="add" type="button"  onclick="AddFunction()">Add Teacher </button>
       <section id="addcourse">
        <h2>Add Courses</h2>
        <form action="" method="post">
            <label for="name">Course Name</label><br>
            <input type="text" name="name" id="name" placeholder="Course Name"><br>

            <label for="image">Course Picture</label><br>
            <input type="file" name="image" id="image" placeholder="Course Name"><br>

              <label for="desc">Course Description</label><br>
            <textarea type="text" name="desc" id="desc" placeholder="Course Description"></textarea><br>

            <button type="submit" id="send" >Send</button>
            
        </form>
  </section>
 -->
 <!--  <script>
         function AddFunction(){
             var x = document.getElementById("addcourse");
            
             if ( x.style.display === "block"){
                 x.style.display ="none";
             }else{
                 x.style.display ="block";
             }
            }
    </script> -->
    
        <h1>
            Users
        </h1>

        <?php 
         if (isset($_GET['search'])) {
       $serch =$_GET['search'];
       $sql = "SELECT * FROM users WHERE first_name LIKE '%$serch%' OR last_name LIKE '%$serch%'";
            $result = mysqli_query($conn ,$sql) ; 
      }
         else {
                $sql = "SELECT * FROM users ";
                $result = mysqli_query($conn ,$sql);} 
       

            if ( mysqli_num_rows($result) > 0) {?>

                <table class="table">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Change Role</th>
                        <th>Delete</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) {?>
                        
                        <tr>
                            <td><?=$row['user_id']?></td>
                             <td><?=$row['first_name']?> <?=$row['last_name']?></td>
                              <td><?php if ($row['role']==1) { echo "Student";} 
                              elseif ($row['role']==3) {echo "Teacher"; } elseif ($row['role']==2) {
                                  echo "Manager";}?>  
                            </td>
                            <td><?php if ($row['role']==1) {?> <a href="toadmin.php?user_id=<?=$row['user_id']?>">To Admin</a> <br>Or<br><a href="toteacher.php?user_id=<?=$row['user_id']?>">To Teacher</a> <?php } elseif ($row['role']==3) {?><a href="toadmin.php?user_id=<?=$row['user_id']?>">To Admin</a> <?php } else {?> No Options <?php } ?>
                        </td>
                                <form action="delete.php" method="get"><td><a href="delete.php?user_id=<?php echo$row['user_id'] ?>">Delete</a> </td></form>
                        </tr>

                 <?php  }  ?>
                </table>
   <?php
      } else { ?>
 
 <span>
     No Results
 </span>

    <?php  } ?>
  </section>


  <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

      </div>
  </body>
</html>