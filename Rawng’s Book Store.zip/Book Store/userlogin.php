<?php
session_start(); 
if ( isset( $_SESSION['email'] ))  {
    header('Location: BookStore.php');
}
require 'connect.php';
$email= $email_err=$password= $password_err=  $login_failed = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST["email"])){
        $email=$_POST["email"];
        if(empty($_POST["email"])){
            $email_err="Email is required";
        }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
           $email_err = "Invalid email";
           unset($_POST["email"]);
       }
    }
    if(isset($_POST["password"])){
        $password=$_POST["password"];
        if(empty($_POST["password"])){
            $password_err="Password is required ";
            unset($_POST["password"]);
        }
    }
    if($email_err=='' and $password_err==''){
    $sql = "SELECT * FROM users WHERE email = '$_POST[email]' and password = '$_POST[password]'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['email'] = $_POST['email'];
        header("Location: Bookstore.php");
    } else {
        $login_failed = '<span class="error">Incorrect Email or Password</span>';
    }
}
}

?>
<!DOCTYPE html>
<html>

<head>
   <title>user login</title>
    <style>
     <?php include 'style.css' ?>
     html{
       background-image:url("background 1 .gif") ;
       background-position: center ;
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size: cover;
   }
   body{
  
	display: flex;
	flex-direction: column;
	align-items: center;
	margin: auto;
}
.container{
    background: radial-gradient(circle,  rgba(236, 227, 227, 0.619),  rgba(107, 63, 63, 0.623));
    border-radius: 12px;
	    justify-content: center; 
        margin: 4% 3% 1% 3%;
}
h2{
    margin-top:3%;
            color:rgb(116, 25, 25);
            text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
            text-align:center;
            font-size:40px;
}
p{
    font-size:20px;
  font-weight: bold; 
  letter-spacing: 0.5px;
  word-spacing:2px;
 font-size:22px;
          text-shadow: 2px 2px 2px rgba(7, 7, 7, 0.574);
          
          /*font-family: 'Tapestry';*/
}

.footer {
    margin: 1.7% auto 2% 30%;
    padding: 10px 8px 10px 8px ;
    font-size:20px;
    position: relative;
    align-items: center;
    text-align:center;
    width: 40%;
    font-weight: bold;
    text-shadow: 2px 2px 2px rgba(7, 7, 7, 0.574);
   
}
.submit{
    left: 33%;
    margin-top:5%;
    margin-bottom:3%;
}
</style>
</head>

<body>
<div class="container">
    <h2> User’s Login Form</h2>
    <div class="hrl"></div>
    <p><b> This form for Users if you are an Admin pleace click <a href="adminlogin.php"> Here </a> to login. </b></p>
    <?= $login_failed ?>
    <form action="userlogin.php" method="post">


       
       
            <label for="email"><b>Email</b></label><span class="error"><?=$email_err?></span>
            <input type="text" placeholder="Enter Email" name="email" required>

            <label for="password"><b>Password</b></label><span class="error"><?=$password_err?></span>
            <input type="password" placeholder="Enter Password" name="password" required>

            <button class="submit" type="submit">Login</button>
       <div class="footer" ><b>Not a member ? <a href="register.php"> Sign Up </a></b> </div>

       
          
         
        </div>
    </form>

</body>

</html>