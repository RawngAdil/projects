<?php
session_start();
$_SESSION['Book_ID']=$_GET['Book_ID'];

require 'connect.php';
$success = $fail   =$bookname= $authorname= $price= $catergory = $subcategory= '';
$bookname_err= $authorname_err= $price_err= $category_err= $subcategory_err= $exist_error='';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   if(isset($_POST["bookname"])){
       $bookname=$_POST["bookname"];
       if(empty($_POST["bookname"])){
           $bookname_err="Book Name is required ";
           unset($_POST["bookname"]);
       }
       elseif(preg_match("/[@#-$%^'+=~|&\/_*()1234567890]/",$_POST["bookname"])){
           $bookname_err="Only letters allowed ";
           unset($_POST["bookname"]);
       }
   }
   if(isset($_POST["author"])){
       $authorname=$_POST["author"];
       if(empty($_POST["author"])){
           $authorname_err="Author Name is required";
       } elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["author"])){
           $authorname_err="Only letters allowed ";
           unset($_POST["author"]);
       }
   }
   if(isset($_POST["price"])){
       $price=$_POST["price"];
       if(empty($_POST["price"])){
          $price_err="Price is required";
       }elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()qwertyuioplkjhgfdsazxcvbnm\s]/",$_POST["price"])){
           $price_err="Only number is allowed";
       }
   }
   if(isset($_POST["category"])){
      $category=$_POST["category"];
      if(empty($_POST["category"])){
          $category_err="category is required ";
          unset($_POST["category"]);
      }
      elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["category"])){
          $category_err="Only letters allowed ";
          unset($_POST["category"]);
      }
    }
    if(isset($_POST["subcategory"])){
      $subcategory=$_POST["subcategory"];
      if(empty($_POST["subcategory"])){
          $subcategory_err="subcategory is required ";
          unset($_POST["subcategory"]);
      }
      elseif(preg_match("/[!@#-$%^'+=~|&?\/_*()1234567890]/",$_POST["subcategory"])){
          $subcategory_err="Only letters allowed ";
          unset($_POST["subcategory"]);
      }
      elseif($bookname_err=='' and  $authorname_err=='' and  $price_err=='' and  $category_err=='' and $subcategory_err== ''){
   $sql = "SELECT books.Book_Name,authors.Author_Name FROM books JOIN authors ON books.Author_ID=authors.Author_ID WHERE Book_Name = '$_POST[bookname]' and Author_Name='$_POST[author]' ";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $exist_error = '<span class="err">Book already exists</span>';
            } else {  
                $sql="SELECT Author_name FROM authors WHERE Author_Name= '$_POST[author]' ";  
                $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) == 0) {                         
                $sql2="INSERT INTO authors (Author_Name) VALUES ('$_POST[author]') ";
                $result2 = mysqli_query($conn, $sql2);}

                $sql10="SELECT Category FROM categories WHERE Category= '$_POST[category]' ";  
                $result10 = mysqli_query($conn, $sql10);
        if ($result10) {
            if (mysqli_num_rows($result10)== 0) {
                $sql3="INSERT INTO categories (Category) VALUES ('$_POST[category]')  ";
                $result3 = mysqli_query($conn, $sql3);}

                $sql11="SELECT Subcategory FROM subcategories WHERE Subcategory= '$_POST[subcategory]' ";  
                $result11 = mysqli_query($conn, $sql11);
        if ($result11) {
            if (mysqli_num_rows($result11) == 0) {
                       
                 $sql4="INSERT INTO subcategories (Subcategory) VALUES ('$_POST[subcategory]') ";
                $result4 = mysqli_query($conn, $sql4);}

                $sql5="SELECT Author_ID FROM authors  WHERE Author_Name= '$_POST[author]' ";
                 $result5 = mysqli_query($conn, $sql5);
                 $row = mysqli_fetch_assoc($result5);
                $sql6="SELECT Category_ID FROM categories WHERE Category= '$_POST[category]' ";
                 $result6 = mysqli_query($conn, $sql6);
                 $row2 = mysqli_fetch_assoc($result6);
                $sql7=" SELECT Subcategory_ID FROM subcategories WHERE Subcategory= '$_POST[subcategory]' ";
                $result7 = mysqli_query($conn, $sql7);
                $row3 = mysqli_fetch_assoc($result7);
                $sql8="UPDATE books SET Book_Name ='$_POST[bookname]' ,Price = '$_POST[price]', Author_ID ='$row[Author_ID]'
                 , Category_ID = '$row2[Category_ID]', Subcategory_ID = '$row3[Subcategory_ID]' WHERE Book_ID= '$_SESSION[Book_ID]' ";
                $result8 = mysqli_query($conn,$sql8);
                if ($result8) {
                    $success = '<span class="success">Book edited successfuly</span>';
                    header('Location:books.php');
                } else {
                    $fail = '<span class="err">Failed to edit  book info</span>';
                }
            }
        }
    }
  }
                }
            }
        }
    }
        
    

?>
<!DOCTYPE html>
<html>
<style>
    <?php include 'style.css' ?>
    .container{
        position: absolute;
        width: 50%;
        left: 21%;
    }
</style>

<body>

    <?= $success ?><?= $fail ?>
    <?php
    $sql2= "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price,
    categories.Category,subcategories.Subcategory,books.Editing,books.Delete FROM books JOIN authors ON books.Author_ID=authors.Author_ID
    JOIN categories ON books.Category_ID=categories.Category_ID
    JOIN subcategories ON books.Subcategory_ID=subcategories.Subcategory_ID WHERE Book_ID='$_SESSION[Book_ID]' ";
    $result2= mysqli_query($conn,$sql2);
    ?>
    <form action="" method="post" >

        <div class="container">
            <h1>Edit Book Info</h1>
           
            <div class="hrl"> </div>
            <?php while ($row = mysqli_fetch_assoc($result2))
             /*function fetches a result row as an associative <array></array>*/
            { ?>

            <label for="bookname"><b>Book Name</b></label><span class="error" ><?=$bookname_err?></span><br>
            <input type="text"  name="bookname" id="bookname" value="<?=$row['Book_Name']?>" required>

            <label for="author"><b>Book Author</b></label><span class="error" ><?=$authorname_err?></span><br>
            <input type="text" name="author" id="author" value="<?=$row['Author_Name']?>" required>
            
            <label for="price"><b>Price</b></label><span class="error" ><?=$price_err?></span><br>
            <input type="float" name="price" value="<?=$row['Price']?>" required>

            <label for="category"><b>Category</b></label><span class="error" ><?=$category_err?></span><br>
            <input type="text"  name="category" value="<?=$row['Category']?>" required>

            <label for="subcategory"><b>Subcategory</b></label><span class="error" ><?=$subcategory_err?></span><br>
            <input type="text"  name="subcategory" value="<?=$row['Subcategory']?>" required>
            
           

            <div >
            <a href="books.php"><button type="button" class="cancel">Cancel</button></a>
                <button type="submit"  class="submit">Submit </button>
                <?php } ?>
            </div>
        </div>
    </form>

</body>

</html>