<?php 
session_start();
require 'connect.php';
error_reporting(0);
$feedback= $notification = "";
if(!isset($_GET['PRODUCT_ID'])){
  header("Location:index.php");
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
  if(isset($_POST['anonymous']) && $_POST['anonymous'] == 'True'){
    $anonymous = 'True';
    
  }else{
    $anonymous = 'False';
  }
  if(isset($_POST['feedback']) && $_POST['feedback'] !== ''){
    if(isset($_POST['rating'])){
      $rating = $_POST['rating'];
    }else{
      $rating = 0;
    }
    $sql = "SELECT * FROM productratings JOIN products ON productratings.PRODUCT_ID = products.PRODUCT_ID WHERE productratings.USER_ID ='$_SESSION[ID]' AND productratings.PRODUCT_ID = '$_GET[PRODUCT_ID]' LIMIT 1";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_assoc($result)){
      $supplierid = $row['SUPPLIER_ID'];
      $sql2 = "UPDATE productratings SET RATING = '$rating',FEEDBACK = '$_POST[feedback]',ANONYMOUS = '$anonymous'  WHERE USER_ID ='$_SESSION[ID]' AND PRODUCT_ID = '$_GET[PRODUCT_ID]'";
      $result2 = mysqli_query($conn,$sql2);
      if($result2){
        $sql3 = "SELECT AVG(RATING) as AverageRating FROM productratings WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
        $result3 =mysqli_query($conn,$sql3);
        $row3 = mysqli_fetch_assoc($result3);
        $sql4 = "UPDATE products SET Average_rating = '$row3[AverageRating]' WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
        $result4 =mysqli_query($conn,$sql4);
        if($result4){
          $sql5 = "SELECT AVG(Average_rating) as AverageStoreRating FROM products WHERE SUPPLIER_ID = '$supplierid'";
          $result5 =mysqli_query($conn,$sql5);
          $row5 = mysqli_fetch_assoc($result5);
          $sql6 = "UPDATE stores SET AVG_RATING = '$row5[AverageStoreRating]' WHERE SUPPLIER_ID = '$supplierid'";
          $result6 =mysqli_query($conn,$sql6);
          if($result6){
          $notification = "Review added succesfully";
          }else{
            $notification = "System Error: Review failed to upload1";
          }
        }else{
            $notification = "System Error: Review failed to upload2";
          }
      }else{
        $notification = "System Error: Review failed to update";
      }
    }}else{
    $sql2 = "INSERT INTO productratings (USER_ID,PRODUCT_ID,RATING,FEEDBACK,ANONYMOUS) VALUES('$_SESSION[ID]','$_GET[PRODUCT_ID]','$rating','$_POST[feedback]','$anonymous')";
    $result2 = mysqli_query($conn,$sql2);
    if($result2){
      $sql3 = "SELECT AVG(RATING) as AverageRating FROM productratings WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
        $result3 =mysqli_query($conn,$sql3);
        $row3 = mysqli_fetch_assoc($result3);
        $sql4 = "UPDATE products SET Average_rating = '$row3[AverageRating]' WHERE PRODUCT_ID = '$_GET[PRODUCT_ID]'";
        $result4 =mysqli_query($conn,$sql4);
        if($result4){
        $sql5 = "SELECT AVG(Average_rating) as AverageRating FROM products WHERE SUPPLIER_ID = '$supplierid'";
        $result5 =mysqli_query($conn,$sql5);
        $row5 = mysqli_fetch_assoc($result5);
        $sql6 = "UPDATE stores SET Average_rating = '$row5[AverageRating]' WHERE SUPPLIER_ID = '$supplierid'";
        $result6 =mysqli_query($conn,$sql6);
        if($result6){
        $notification = "Review added succesfully";
        }else{
          $notification = "System Error: Review failed to upload3";
        }
      }else{
          $notification = "System Error: Review failed to upload4";
        }
    }else{
      $notification = "System Error: Review failed to upload5";
    }
  }
}else{
    $notification = "Feedback is required";
    $feedback = "style='height{28%}'";
  }

}
include 'notification.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">   
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <?php
       if(isset($_SESSION['ROLE'])) {

    if($_SESSION['ROLE'] !== "admin" && $_SESSION['ROLE'] !== "superadmin") {
      include 'navigation.php';} 
      else  { include 'AdminNav.php';}  }
      else{
      include 'navigation.php';  }
    ?>
<body>

<section >
    <?php
$sql = "SELECT * FROM products INNER JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID WHERE PRODUCT_ID= '$_GET[PRODUCT_ID]'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$DEFPRODUCT_ID= $row['DEFPRODUCT_ID'];
?>
<div class="details">
 <img src="images/<?= $row['PRODUCT_IMG']?>"  width="100%" height="100%">

    <div class="content3"> 
    <h2><?= $row['PRODUCT_NAME']?></h2>
    <h3><?= $row['STORE_NAME']?></h3>
    <p class="productDesc"><?= $row['PRODUCT_DESCRYPT']?></p>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php
    $star = round($row['Average_rating'],0);?>
<div class="s-rating">
    <spam class="star-rating">
            <input type="radio" name="rating" value="1" disabled <?php if($star == 1){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="2" disabled <?php if($star == 2){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="3" disabled <?php if($star == 3){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="4" disabled <?php if($star == 4){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating" value="5" disabled <?php if($star == 5){echo "checked";}?>><i class="star"></i>
          </spam>
          <spam class="ratings"><?= $row['Average_rating']?> / 5.0 </spam> 
      </div>
    <?php if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){}else{?> <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a><?php }?>
  </div>

  <script>
function textbox(){
  var t = document.getElementById("textbox");
  if ( t.style.height === "50%"){
    t.style.height ="0";
}else{
    t.style.height ="50%" ;}
}
  </script>

 <hr>
     
<!-- feedback -->
<div class="feedback" >
 

<a <?php if(isset($_SESSION['ID'])){?> href="javascript:void(0)" onclick="textbox()" <?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php ;}?>>Add your feedback</a> <span id="arrow" ></span>
<form id="textbox" action="" method="POST" <?= $feedback?>>
<div class="anonymousbar">
    <label class="switch">
    <input type="checkbox" name="anonymous" value="True">
    <span class="boll"></span>
</label>
<span class="Anonymous">Anonymous</span>
</div>

<div class="rate">
<label class="">Rate out of 5 stars</label>
<spam class="star-rating">
            <input type="radio" name="rating" value="1"><i class="star"></i>
            <input type="radio" name="rating" value="2"><i class="star"></i>
            <input type="radio" name="rating" value="3"><i class="star"></i>
            <input type="radio" name="rating" value="4"><i class="star"></i>
            <input type="radio" name="rating" value="5"><i class="star"></i>
          </spam><br>
    <div>
<textarea name="feedback" rows="5"  placeholder="Enter your feedback here.."></textarea><br>
<button class="fbsubmit" type="submit">Submit</button>
</form>
</div>
      </div>
      </section>

<?php  ?>

 <!-- Similar Products -->
<section>
    <h2>Similar Products</h2>
    <section class="similar products">
  <?php
$sql = "SELECT * FROM products  JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID  JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID  WHERE products.DEFPRODUCT_ID = '$DEFPRODUCT_ID' ";
  $result = mysqli_query($conn,$sql);
  $i=0;
  while($row = mysqli_fetch_assoc($result)){
    $i=$i+1;?>
  <div class="productbox">
  <a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"><img src="images/<?= $row['PRODUCT_IMG']?>" width="100%" height="100%"></a>
    <div class="content"> 
    <h3 ><?= $row['PRODUCT_NAME']?></h3>
    <h4><?= $row['STORE_NAME']?></h4>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php $star2 = round($row['Average_rating'],0);?>

<div class="s-rating">
   
<spam class="star-rating">
        <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
      </spam>
      <spam class="rating"><?= $row['Average_rating']?> / 5.0</spam>
  </div>
  
  <?php if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){}else{?> <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a><?php }?>
  </div>
      </div>
      <?php ;}?>
      </section>
</section>

 <!-- reviews -->
<section class="reviwes">
<h2>Reviews</h2>
<?php $sql3 = "SELECT * FROM productratings  JOIN users ON  productratings.USER_ID = users.USER_ID  WHERE productratings.PRODUCT_ID= '$_GET[PRODUCT_ID]'";
$result3 = mysqli_query($conn,$sql3);

if (mysqli_num_rows($result3) >0) {
  while ($row3 = mysqli_fetch_assoc($result3)) { 
 $i=$i+1;
         ?>
            <article class="review">
                <h5 class="name"><?php if($row3['ANONYMOUS'] == 'False'){echo $row3['FIRST_NAME']." ".$row3['LAST_NAME'];}else{echo "Anonymous";}?></h5>
                <?php $star2 = round($row3['RATING'],0) ;?>

            
                <span class="star-rating">
            <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
            <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
          </span>
          <br>
           
                <q> <?=$row3['FEEDBACK']?></q>
                </article>

                <?php  } }
                else {
                echo '<h3 class="notyet">There isn’t any reviews yet<h3>';
                } ?>
  </section>
      <?php
  include 'footer.php';
  ?>