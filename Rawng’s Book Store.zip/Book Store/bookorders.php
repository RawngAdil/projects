<?php 
session_start();
require "connect.php";
?>
<!DOCTYPE html>
<html>

<head>
<script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
<title>Book Orders</title>
 <style>
     @import url('https://fonts.googleapis.com/css2?family=Cookie&family=Fredericka+the+Great&family=Great+Vibes&family=Henny+Penny&family=Merienda&family=Monoton&family=Playball&family=Rubik+Glitch&family=Rubik+Moonrocks&family=Rubik+Wet+Paint&family=Tangerine&family=Tapestry&family=Yellowtail&display=swap');
 * {
            box-sizing: border-box;
            margin: 0 ;
            padding: 0;
            
        }
      

        body {
            margin:0;
            font-family:  sans-serif;
           font-weight:bold;
            color:#000000;
            background-image:url("IU5e.gif");
            background-position: center ;
	        background-repeat: no-repeat;
	        background-attachment: fixed;
	        background-size: cover;

        }

        .container {
            width: 90%;
            margin: 2% auto;
           
            padding: 16px 5px 16px 5px;
    background: radial-gradient(circle,rgba(225, 207, 207, 0.59),  rgba(29, 1, 1, 0.623));
    margin: 3% 4.5% 1% 4.5%;
    border-radius: 12px
            
        }

        .topnav {
            overflow: hidden;
            background: radial-gradient(circle, rgba(84, 63, 63, 0.575),  rgba(29, 1, 1, 0.623));
            width: 95%;
            margin:0 5px 7px 30px;
	 border-radius: 12px;
     font-family: 'Tapestry';
     
        }

        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        .topnav a.active {
            background-color:rgb(97, 17, 17);
            color: white;
        }

        #books {
            margin-top:2%;
            margin-bottom:5%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;
            font-family: 'Merienda';
            font-weight:bold;
           
            

        }

        #books td,
        #books th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            
            padding: 8px;
        }

        #books tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
}
        }

        #books tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #books th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
        
        }
        h1{
          
            color:rgb(97, 17, 17);
            text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
            font-family: 'Tapestry';
	     text-align:center;
    
    margin: 2% auto;
        }
        .not{
     padding: 20px 20px 20px 20px;
    background: radial-gradient(circle, rgba(236, 227, 227, 0.619),  rgba(107, 63, 63, 0.623));
    justify-content: center; 
    margin: 10% 3% 1% 1%;
    border-radius: 25px;
    position:absolute;
    left: 24%;
    top:45%;
     color:rgb(97, 17, 17);
    text-shadow: 3px 2px 3px rgba(7, 7, 7, 0.812);
    font-size:60px;
	text-align:center;    
    margin: 2% auto;
      }
      #add{
            background-color: rgb(97, 17, 17);
            width: 10%;
            height: 9%;
            color: white;
            text-align:center;
            border-radius:17px;
            padding: 5px 8px 5px 8px ;
            font-size:15px;
            position: absolute;
            top:30%;
            left:50% ;        
            border: none;
        cursor: pointer;
        opacity: 0.9;
        }
        #add:hover{
            opacity: 1;
        }
        h2{
            padding-top:2%;
          padding-bottom:3%;
          color:rgb(97, 17, 17);
          text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
          font-family: 'Tapestry';  
         margin: 2% 3% 0% 1%;
        }
        .check{
            font-size:25px;
            padding-top:2%;
            float:right;
            
          color:rgb(97, 17, 17);
          text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
          font-family: 'Tapestry';  
         margin: 0 3% 3% 1%;
        }
        .complete{
            background: radial-gradient(circle, rgba(236, 227, 227, 0.619),  rgba(107, 63, 63, 0.623));
            width: 95%;
            margin: 2% 3% 0 3%;
           
        }
    </style>
</head>

<body>



    <div class="topnav">
        <a  href="index.php">Users</a>
        <a  href="admins.php">Admins</a>
        <a  href="books.php">Books</a>
        <a href="categories.php">Categories</a>
        <a href="subcategories.php">Subcategories</a>
        <a  class="active" href="bookorders.php">Book Orders</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
      
      <h1>Books Orders</h1>
      <?php
      $results=mysqli_query($conn,"SHOW TABLES LIKE'"."% Order%"."'");
if($results->num_rows == 0){
    echo '<span class="not">There are no order yet!</span>';}
    else{
$sql="SELECT User_Name FROM users";
$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_assoc($result)){
$results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name] Order"."'");
if($results->num_rows ==1){
  ?>
  <div class="complete">
  <div class="check"> Completed : <input type="checkbox" name="done" id=<?php echo $row['User_Name']?> value="1"
   onclick="return confirm('Has this order been completed ?')" 
   onchange="window.location.href='ordercompleted.php?User_Name=<?=$row['User_Name']?>';"/> </div>
   <h2><?=ucfirst($row['User_Name'])?></h2>
   
   
</div>
        <?php
$sql2="SELECT * From  `$row[User_Name] Order`";
$result2=mysqli_query($conn,$sql2);
if($result2){
?>

            <table id="books">
                <tr>
                    <th>Book ID</th>
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                   

                </tr>
                <?php while ($row = mysqli_fetch_assoc($result2)) { ?>
                    <tr>
                        <td><?= $row['Book_ID'] ?></td>
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                       
                 
                        
                    </tr>
                <?php } ?>
            </table>
        <?php 
     } } } }?>
    </div>
</body>

</html>