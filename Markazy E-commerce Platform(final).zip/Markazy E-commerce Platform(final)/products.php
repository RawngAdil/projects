<?php
session_start();
require 'connect.php';
error_reporting(0);
if(isset($_SESSION['ROLE'])){
  if($_SESSION['ROLE'] == "admin" || $_SESSION['ROLE'] == "superadmin"){
    header("Location:admin.php");
    die;
  }
}
?>

<!DOCTYPE html>
  <html>
    <head>
    <title>Products Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">   
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <?php
    include 'navigation.php';
    $sql = "SELECT * FROM products 
    JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID 
    JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
    JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID";
    $result= mysqli_query($conn,$sql);
    $filtercat = "";
    $filtersubcat = "";
    if(isset($_GET['search'])){
      if(isset($_GET['store'])){
        $name = 'stores.STORE_NAME';
      }else{
        $name = 'products.PRODUCT_NAME';
      }
        if(isset($_GET['filtercategory']) && $_GET['filtercategory'] !== 'Category'){
            $filtercat=$conn -> real_escape_string($_GET['filtercategory']);
            $category="AND subcategories.CATEGORY = '$filtercat'";
        }else{
            $filtercat="";
            $category = "";
        }
        if(isset($_GET['filtersubcategory']) && $_GET['filtersubcategory'] !== 'SubCategory'){
          $filtersubcat=$conn -> real_escape_string($_GET['filtersubcategory']);
          $sql2 = "SELECT SUBCATEGORY_ID FROM subcategories WHERE SUBCATEGORY LIKE '%$filtersubcat%'";
          $result2 =mysqli_query($conn,$sql2);
          $row2 = mysqli_fetch_assoc($result2);
          $subcategory="AND subcategories.SUBCATEGORY_ID = '$row2[SUBCATEGORY_ID]'";
      }else{
          $subcategory = "";
      }if(isset($_GET['filterseason']) && $_GET['filterseason'] !== 'Season'){
        $filterseason=$conn -> real_escape_string($_GET['filterseason']);
        $season="AND defproducts.SEASON = '$filterseason'";
    }else{
        $season = "";
    }if(isset($_GET['orderby']) && $_GET['orderby'] !== 'Order By'){
      $filterorderby=$conn -> real_escape_string($_GET['orderby']);
        if($filterorderby == 'High to low rating'){
          $orderby='ORDER BY AVERAGE_RATING DESC';
        }elseif($filterorderby == 'A-Z'){
          $orderby='ORDER BY PRODUCT_NAME ASC';
        }elseif($filterorderby == 'Z-A'){
          $orderby='ORDER BY PRODUCT_NAME DESC';
        }elseif($filterorderby == 'Low to High Price'){
          $orderby='ORDER BY PRICE ASC';
        }
    }else{
      $orderby = '';
    }
        $search=$conn -> real_escape_string($_GET['search']);
        $sql = "SELECT * FROM products 
        JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID
        JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
        JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE $name LIKE '%$search%' $category $subcategory $season $orderby";
        $result= mysqli_query($conn,$sql);
        echo '<h2>Search Results</h2>';
    }elseif(isset($_GET['subcategory'])){
      $filtersubcat=$conn -> real_escape_string($_GET['subcategory']);
      $sql2 = "SELECT SUBCATEGORY_ID,CATEGORY FROM subcategories WHERE SUBCATEGORY LIKE '%$filtersubcat%'";
      $result2 =mysqli_query($conn,$sql2);
      $row2 = mysqli_fetch_assoc($result2);
      $filtercat = $row2['CATEGORY'];
      $sql = "SELECT * FROM products 
        JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID
        JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
        JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE subcategories.SUBCATEGORY_ID = '$row2[SUBCATEGORY_ID]'";
      $result = mysqli_query($conn,$sql);
    }elseif(isset($_GET['newadditions'])){
        $sql = "SELECT * FROM products 
        JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID
        JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
        JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID ORDER BY products.PRODUCT_ID DESC";
        $result = mysqli_query($conn,$sql);
      }elseif(isset($_GET['seasonvegetables'])){
        $sql = "SELECT * FROM products 
        JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID
        JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
        JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE defproducts.SEASON = '$_GET[seasonvegetables]' AND subcategories.CATEGORY='Vegetable'";
        $result = mysqli_query($conn,$sql);
        echo "<h2>".$_GET['seasonvegetables']." Vegetables</h2>";
      }elseif(isset($_GET['seasonfruits'])){
          $sql = "SELECT * FROM products 
          JOIN stores ON products.SUPPLIER_ID = stores.SUPPLIER_ID
          JOIN defproducts ON products.DEFPRODUCT_ID = defproducts.DEFPRODUCT_ID 
          JOIN subcategories ON defproducts.SUBCATEGORY_ID = subcategories.SUBCATEGORY_ID WHERE defproducts.SEASON = '$_GET[seasonfruits]' AND subcategories.CATEGORY='Fruit'";
          $result = mysqli_query($conn,$sql);
          echo "<h2>".$_GET['seasonfruits']." Fruits</h2>";}?>
    <div class="productlist">
    <?php
    if($filtercat != ""){echo '<h2>'.$filtercat.'s</h2>';};
    echo '<h3 class="sub">'.$filtersubcat.'</h3>';
    if(mysqli_num_rows($result) > 0){
      $i=0;
    while($row = mysqli_fetch_assoc($result)){
      $i=$i+1;?>
       <div class="productbox">
       <a href="details.php?PRODUCT_ID=<?=$row['PRODUCT_ID']?>"><img src="images/<?=$row['PRODUCT_IMG']?>" width="100%" height="100%"></a>
    <div class="content"> 
    <h3><?= $row['PRODUCT_NAME']?></h3>
    <h4><?= $row['STORE_NAME']?></h4>
    <p class="price">$<?= number_format((float)$row['PRICE'], 2, '.', '')?></p>
    <?php $star2 = round($row['Average_rating'],0);?>
    <div class="s-rating">
<spam class="star-rating">
        <input type="radio" name="rating<?=$i?>" value="1" disabled <?php if($star2 == 1){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="2" disabled <?php if($star2 == 2){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="3" disabled <?php if($star2 == 3){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="4" disabled <?php if($star2 == 4){echo "checked";}?>><i class="star"></i>
        <input type="radio" name="rating<?=$i?>" value="5" disabled <?php if($star2 == 5){echo "checked";}?>><i class="star"></i>
      </spam>
      <spam class="rating"><?= $row['Average_rating']?> / 5.0</spam> <br>
    </div>
    <a <?php if(isset($_SESSION['ID'])){?>href="cartprocess.php?addproductid=<?= $row['PRODUCT_ID']?>"<?php }else{?> href="login.php" onclick=" return confirm('To continue you must sign in first.Proceed?')"<?php }?>><button class="addto">ADD TO CART<i class="fa-solid fa-cart-shopping"></i></button></a>
  </div>
  </div>
            <?php ;}?>
    </div><?php }else{
        echo '<br><br><br><h2>No Results Found</h2>';
    }?>