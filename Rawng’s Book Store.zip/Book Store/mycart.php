<?php
session_start();
require 'connect.php';
if(isset($_GET["Book_ID"])){
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
$_SESSION["Book_ID"]=$_GET["Book_ID"];
    $sql="SELECT User_Name From users WHERE Email='$_SESSION[email]' ";
    $result = mysqli_query($conn, $sql);
     $row = mysqli_fetch_assoc($result);
     $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name]"."'");
      if($results->num_rows == 1){
         echo "Table exists";
         $sql1=  "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price
         FROM books JOIN authors ON books.Author_ID=authors.Author_ID
         WHERE Book_ID='$_SESSION[Book_ID]' ";
        $result1=mysqli_query($conn,$sql1);
        $row1=mysqli_fetch_assoc($result1);
        $sql2="INSERT INTO `$row[User_Name]` (`Book_ID`, `Book_Name`, `Author_Name`, `Price`) VALUES ('$row1[Book_ID]', '$row1[Book_Name]', '$row1[Author_Name]', '$row1[Price]');";
        $result2=mysqli_query($conn,$sql2);
         if($result2){
             header("Location:BookStore.php?msg");
           
    }
         else{
             echo "fail";
         }

     }
     else{
         $sql3="CREATE TABLE `bookstore`.`$row[User_Name]` ( `Book_ID` INT(10) NOT NULL , `Book_Name` VARCHAR(100) NOT NULL , 
         `Author_Name` VARCHAR(30) NOT NULL , `Price` FLOAT(20) NOT NULL , INDEX (`Book_ID`)) ENGINE = InnoDB;";
         $result3=mysqli_query($conn,$sql3);
         $sql1=  "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price
         FROM books JOIN authors ON books.Author_ID=authors.Author_ID
         WHERE Book_ID='$_SESSION[Book_ID]' ";
        $result1=mysqli_query($conn,$sql1);
        $row1=mysqli_fetch_assoc($result1);
         $sql4="INSERT INTO `$row[User_Name]` (`Book_ID`, `Book_Name`, `Author_Name`, `Price`) VALUES ('$row1[Book_ID]', '$row1[Book_Name]', '$row1[Author_Name]', '$row1[Price]');";
         $result4=mysqli_query($conn,$sql4);
         if($result4){
            
             header("Location:BookStore.php?msg");
         }
         else{
             echo "fail";
         }
     }

}

}

?>
<!DOCTYPE html>
<html>
    <head>
        <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
        <title>my cart</title>
        <style>
            <?php
              include "style2.css"?>
            #books {
            margin-top:2%;
            margin-bottom:2%;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 95%;
            position: relative;
            left:2.5%;  
            font-family: 'Merienda',;        
       }

        #books td,
        #books th {
            
            border: 2px solid rgba(174, 168, 168, 0.549) ;
            padding: 8px;
        }

        #books tr:nth-child(even) {
            background-color:rgba(221, 221, 221, 0.618);
            color:black;
}
        }

        #books tr:hover {
            background-color:rgba(155, 86, 86, 0.3);
        }

        #books th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color:rgb(97, 17, 17);
            color: white;
            font-size:17px;
            text-shadow: 3px 4px 4px rgba(7, 7, 7, 0.874);
        
        }
        h1{
          
         color:rgb(97, 17, 17);
        text-shadow: 2px 1px 2px rgba(7, 7, 7, 0.512);
        text-align:center;
        margin: 1.6% auto;
        margin-bottom:4%;
        font-size:40px;
        font-family: 'Tapestry';

       
/*font-family: 'Cookie', cursive;
font-family: 'Fredericka the Great', cursive;
font-family: 'Great Vibes', cursive; /*welcome*/
/*font-family: 'Henny Penny', cursive; 
font-family: 'Merienda', cursive;/*body
font-family: 'Monoton', cursive;
font-family: 'Playball', cursive;
font-family: 'Rubik Glitch', cursive;
font-family: 'Rubik Moonrocks', cursive;
font-family: 'Rubik Wet Paint', cursive;/*huror
font-family: 'Tangerine', cursive;
font-family: 'Tapestry', cursive;
font-family: 'Yellowtail', cursive;*/

      }
      .not{
     padding: 20px 20px 20px 20px;
    background: radial-gradient(circle, rgba(236, 227, 227, 0.619),  rgba(107, 63, 63, 0.623));
    justify-content: center; 
    margin: 10% 3% 1% 1%;
    border-radius: 25px;
    position:absolute;
    left: 20%;
    top:30%;
     color:rgb(97, 17, 17);
    text-shadow: 3px 2px 3px rgba(7, 7, 7, 0.812);
    font-size:60px;
	text-align:center;    
    margin: 2% auto;
      }
      .addbtn {
    background-color:rgb(97, 17, 17);
     color: white;
     font-size:40%;
     font-weight:800;
     text-align:center;
     border-radius:10px;
     margin: 1.7%;
    padding: 10px 8px 10px 8px ;
    font-size:20px;
    position: absolute;
    left: 38%;
    top:55%;
    cursor: pointer;
    opacity: 0.9;
    box-shadow:3px 3px 4px 3px rgba(7, 7, 7, 0.642);
    
}
.addbtn:hover {
    opacity: 1;
}
.order{
            background-color: rgb(97, 17, 17);
            color: white;
            text-align:center;
            width: 8%;
            height: 8%;
            font-weight:800;
            font-family:'Tapestry','Rubik Wet Paint', 'Tangerine';
            letter-spacing:0.9px;
            border-radius:15px;
            padding: 5px 8px 5px 8px ;
            font-size:15px;
            position: absolute;
            right: 7%;
            top:22%;
            border: none;
        cursor: pointer;
        opacity: 0.8;
        box-shadow:2px 2px 3px 2px rgba(7, 7, 7, 0.350);
        }
.order:hover{
         opacity: 1;
        }
        .vieworder1{
            background-color: rgb(97, 17, 17);
            color: white;
            text-align:center;
            width: 8%;
            height: 9%;
            font-weight:800;
            letter-spacing:0.9px;
            font-family:'Tapestry','Rubik Wet Paint', 'Tangerine';
            border-radius:15px;
            padding: 5px 8px 16px 8px ;
            padding-bottom:16px;
            font-size:15px;
            position: absolute;
            right: 7%;
            top:32%;
            border: none;
        cursor: pointer;
        opacity: 0.8;
        box-shadow:2px 2px 3px 2px rgba(7, 7, 7, 0.350);
        }
.vieworder1:hover{
         opacity: 1;
        }
        
.vieworder{
    background-color: #ddd;
            color:  rgb(97, 17, 17);
            text-align:center;
            width: 20%;
            height: 15%;
            font-weight:800;
        
            border-radius:15px;
            padding: 5px 8px 5px 8px ;
            font-size:15px;
            position: absolute;
            right: 39%;
            border: none;
        cursor: pointer;
        opacity: 0.8;
        box-shadow:2px 2px 3px 2px rgba(7, 7, 7, 0.350);
        }
        .vieworder:hover{
         opacity: 1;
        }   
@media screen and (max-width:600px){
    .not{
    left: 0;
    top:30%;
    right:26%;
    }
}

        </style>
    </head>
    <body  id="main" class="lightmood">
   
        <header>
        <div id="nav" class="topnav container-lightmood">
        <a  href="BookStore.php">Home</a>
        <a  href="aboutus.php">About Us</a>
        <a class="active" href="mycart.php">My Cart</a>
        <a href="userlogout.php">Logout</a>
        </div>

        <script>
   function switchTheme() {
         var theme = localStorage.getItem('theme');
         body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
         if (theme === 'darkmode') {
            new_theme = 'lightmode';
         } else {
            new_theme = 'darkmode';
         }
         body.classList.remove(theme);
         myBtn.classList.remove(theme);
         nav.classList.remove(theme);
         body.classList.add(new_theme);
         myBtn.classList.add(new_theme);
         nav.classList.add(new_theme);
         localStorage.setItem('theme', new_theme);
      }

      window.addEventListener('load', function () {
         var theme = localStorage.getItem('theme');
         if (theme === null || theme === undefined) {
            theme = 'lightmode';
            localStorage.setItem('theme', theme);
         }
         var body=document.getElementById("main"),
    myBtn=document.getElementById("themes"),
    nav=document.getElementById("nav");
    search=document.getElementById("search");
    searchbtn=document.getElementById("searchbtn");
    body.classList.add(theme);
         myBtn.classList.add(theme);
         nav.classList.add(theme);
         search.classList.add(theme);
         searchbtn.classList.add(theme);
      })
</script>

</header>
<buttom id="themes"  onclick="switchTheme()" class="light"><i class="fa-solid fa-moon"></i></buttom>
<?php 
$sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
$result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name]"."'");
if($results->num_rows == 1){
 $sql12="SELECT * FROM  `$row[User_Name]` ";
 $result12=mysqli_query($conn,$sql12);
$num= mysqli_num_rows($result12) ;
?>
<div class="cart"> 
<a href="mycart.php"><button class="carticon"><i class="fa-solid fa-cart-plus"></i></button></a>
    <div class="num" ><?=$num?></div>
</div>
<?php } ?>
 <?php
 $sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
 $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name]"."'");
   if($results->num_rows == 1){
    $sql12="SELECT * FROM  `$row[User_Name]` ";
    $result12=mysqli_query($conn,$sql12);
if (mysqli_num_rows($result12) > 0){
?>
<abbr title="Click to Order this books in your cart">
   <a href="order.php"> <button class="order" >Order</button></a>
</abbr> 
<a href="myorder.php"><button class="vieworder1"> View My Order </button></a>
 <div class="container">
     <h1> My Cart</h1>
   <table id="books">
                <tr>
                   
                    <th>Book Name</th>
                    <th>Book Author</th>
                    <th>Price</th>
                    <th>Delete From The Cart</th>

                </tr>
                <?php while ($row = mysqli_fetch_assoc($result12)) { ?>
                    <tr>
                        
                        <td><?= $row['Book_Name'] ?></td>
                        <td><?=$row['Author_Name']?></td>
                        <td>$<?=$row['Price']?></td>
                        <form action="deletefromcart.php" method="GET"  id="delete">
                        <td><a onclick="return confirm('Are you sure you want to delete this book from your cart?')"
                         href="deletefromcart.php?Book_ID=<?php echo $row['Book_ID']; ?>">
                        Delete</a></td> 
                </form>
                      
                        
                    </tr>
                <?php }  ?>
            </table>
            <?php if(isset($_GET['orderdone'])){
       
       $sql="SELECT User_Name from users WHERE Email='$_SESSION[email]' ";
   $result = mysqli_query($conn, $sql);
   $row = mysqli_fetch_assoc($result);?>

       <div class="alert">
       <span class="close" onclick="this.parentElement.style.display='none';">&times;</span>
       <p>Your order is placed successfully </p>
       <?php
       $sql112="SELECT SUM(Price)as Total_Price FROM `$row[User_Name] Order`";
$result112=mysqli_query($conn,$sql112);
$row112 = mysqli_fetch_assoc($result112);
$x=$row112['Total_Price'];
$sum=number_format((float)$x,2, '.','');
echo " Total Price : $ $sum <br> "; ?>
<p> Payment at delivery : <input type="checkbox" id="checkbox" onclick="CheckFunction()"> </p>
<p id="text" style="display:none">Your order has been confirmed ..You will receive it in the coming days</p>
<a href="myorder.php"><button class="vieworder"> View My Order </button></a>
</div>
<script>
    function CheckFunction(){
        var checkBox =document.getElementById("checkbox")
        var text= document.getElementById("text")
        if (checkBox.checked==true){
            text.style.display="block";
        }else{
            text.style.display="none";
        }
    }
 </script>
<?php  } ?>
        <?php   }
        else{echo '<span class="not"> Your cart is Empty </span>
         <a href="BookStore.php"><button class="addbtn" >Add Book To My Cart</button></a>' ;} 
    } 
    
    else {echo '<span class="not">You didn’t add any book yet!</span> 
    <a href="BookStore.php"><button class="addbtn" >Add Book To My Cart</button></a>';}
    ?>
</div>
    </body>
</html>
             
