<?php 
require 'connect.php';
?>  
  

        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <script src="https://kit.fontawesome.com/526db9288e.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" type="text/css" href="nav.css">
        <link href='https://fonts.googleapis.com/css?family=Merienda' rel='stylesheet'>
</head>
<body>
<div class="categories" id="navcategories"> 
 
  
  <a href="javascript:void(0);" class="closebtn" onclick="closeCat()">&times;</a>
  <h1>Categories</h1>
  <div class="categoriesbox">
  <h2>Vegetables</h2>
 
  <?php
  $sql = "SELECT * FROM Subcategories WHERE CATEGORY='Vegetable'";
  $result = mysqli_query($conn,$sql);
  while($row=mysqli_fetch_assoc($result)){?>
  <div class="subcat">
    <a href="products.php?subcategory=<?=$row['SUBCATEGORY']?>"><?=$row['SUBCATEGORY']?></a>
  </div>
  <?php ;}?>
  <hr>
  <h2>Fruits</h2>
  <?php
  $sql = "SELECT * FROM Subcategories WHERE CATEGORY='Fruit'";
  $result = mysqli_query($conn,$sql);
  while($row=mysqli_fetch_assoc($result)){?>
  <div>
  
  <a href="products.php?subcategory=<?=$row['SUBCATEGORY']?>"><?=$row['SUBCATEGORY']?></a>
  </div>
  <?php ;}?>
  </div>
</div>
<div class="allnav">
<div class="mainnavbox">
    <nav class="mainnav">
      <div class="icons">
    <a class="menu" href="javascript:void(0);" onclick="openNav()"><i class="fa solid fa-bars"></i></a>
  </div>
    <a class="logo" href="index.php"><img src="logo.jpg"></a>
   
    <div class="icons">
   
    <a class="profile" href="profile.php"><i class="fa-solid fa-user"></i></a>

    <?php
    if(isset($_SESSION['ID'])){
     $sql12="SELECT * FROM  `orders` WHERE USER_ID='$_SESSION[ID]' AND STATUS='Cart'  ";
     $result12=mysqli_query($conn,$sql12);
    $num= mysqli_num_rows($result12) ;
    }else{
      $num ='';
    }
    ?>
    <span class="cart"> 
    <a class="carticon" href="mycart.php"><i class="fa-solid fa-cart-shopping"></i></a>
    <span class="num" ><?=$num?></span>
  </span>
  
    <a id="searchbtn2" class="searchbtn btn2" href="javascript:void(0);"  onclick="searchfunction()"><i class="fa fa-search"></i></a>
    <a id="xmark" class="searchbtn btn2" href="javascript:void(0);" onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></a>
  </div>
 
</nav>
<form class="searchengine" action="products.php" method="GET">

<div id="searchbar">
<a href="javascript:void(0);"><i class="fa fa-filter" aria-hidden="true"></i></a>
<input class="search" onkeyup="openfilter()" type="search" name="search"><input class="fa-search" style="font-family: FontAwesome" value="&#xf002;" type="submit" id="sbtn">
<script>
  function openfilter(){
    var x =document.getElementsByClassName("filters") ;
if(x.style.height === 0){
  x.style.height == "130px"
}else{
  x.style.height == "0"
  
}
  }
</script>
<script>
    function subcategory(){
    if(document.getElementById('selectcategory').value == "Vegetable") {
      document.getElementById('subvegetable').style.display= "inline-block";
      document.getElementById('subvegetable').removeAttribute("disabled");
      document.getElementById('subfruit').style.display= "none";
      document.getElementById('subfruit').setAttribute("disabled","");
}else if(document.getElementById('selectcategory').value == "Fruit"){ 
  document.getElementById('subfruit').style.display= "inline-block";
  document.getElementById('subfruit').removeAttribute("disabled");
  document.getElementById('subvegetable').style.display= "none";
  document.getElementById('subvegetable').setAttribute("disabled","");
}else {
  document.getElementById('subvegetable').style.display= "inline-block";
  document.getElementById('subvegetable').setAttribute("disabled","");
      document.getElementById('subfruit').style.display= "none";
      document.getElementById('subfruit').setAttribute("disabled","");
}
    ;}
</script>




<div class="filters" id="filtersbox">

<span class="filter">
<select name="filtercategory" id="selectcategory" onclick="subcategory()">
    <option>Category</option>
    <option>Vegetable</option>
    <option>Fruit</option>
  </select>
</span>

<span class="filter">
  <select name="filtersubcategory" id="subvegetable" disabled>
    <option>SubCategory</option>
    <?php $sql="SELECT SUBCATEGORY FROM subcategories WHERE CATEGORY = 'Vegetable'";
    $result=mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){?>
    <option><?= $row['SUBCATEGORY']?></option>
    <?php ;}?>
  </select>
  <select name="filtersubcategory" id="subfruit" disabled>
    <option>SubCategory</option>
    <?php $sql="SELECT SUBCATEGORY FROM subcategories WHERE CATEGORY = 'FRUIT'";
    $result=mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){?>
    <option><?= $row['SUBCATEGORY']?></option>
    <?php ;}?>
  </select>
    </span>

    <span class="filter">
  <select name="filterseason">
    <option>Season</option>
    <option>Winter</option>
    <option>Spring</option>
    <option>Summer</option>
    <option>Autumn</option>
  </select>
    </span>

    <span class="filter">
  <select name="orderby">
    <option>Order By</option >
    <option >High to low rating</option>
    <option>A-Z</option>
    <option>Z-A</option>
    <option>Low to High Price</option>
  </select> 
  </div>
</form>
    </span>
    
    </div>


<div class="icons2">
   
    <a class="profile" href="profile.php"><i class="fa-solid fa-user"></i></a>

    <?php
    if(isset($_SESSION['ID'])){
     $sql12="SELECT * FROM  `orders` WHERE USER_ID='$_SESSION[ID]' AND STATUS='Cart'  ";
     $result12=mysqli_query($conn,$sql12);
    $num= mysqli_num_rows($result12) ;
    }else{
      $num ='';
    }
    ?>
    <span class="cart"> 
    <a class="carticon" href="mycart.php"><i class="fa-solid fa-cart-shopping"></i></a>
    <span class="num" ><?=$num?></span>
  </span>
  
    <a id="searchbtn2" class="searchbtn btn2" href="javascript:void(0);"  onclick="searchfunction()"><i class="fa fa-search"></i></a>
    <a id="xmark" class="searchbtn btn2" href="javascript:void(0);" onclick="searchfunction()"><i class="fa-regular fa-circle-xmark"></i></a>
  </div>
<script>
function openNav() {
 if (window.matchMedia("(min-width: 550px)").matches) {
    document.getElementById("mySidenav").style.width ="60%"; 
} else {
  document.getElementById("mySidenav").style.width ="80%"; 
}
}
function openCat() {
  if (window.matchMedia("(min-width: 769px)").matches) {
    document.getElementById("navcategories").style.width ="30%"; 
} else if (window.matchMedia("(min-width: 550px)").matches) {
    document.getElementById("navcategories").style.width ="60%"; 
} else {
  document.getElementById("navcategories").style.width ="80%"; 
}
}

function closeCat() {
  document.getElementById("navcategories").style.width = "0%";
}
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


function searchfunction(){
            var s = document.getElementById("searchbar");
            var m = document.getElementById("xmark");
            var sb2 = document.getElementById("searchbtn2");

            if ( s.style.display === "block"){
    s.style.display ="none";}
    else{
    s.style.display ="block";}
 
    
    if ( m.style.display === "block"){
                 m.style.display ="none";
             }else{
                 m.style.display ="block";
             }
    
    if ( sb2.style.display === "none"){
    sb2.style.display ="block";
}else{
    sb2.style.display ="none";}

   

}
</script>
</div>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <div class="log">
 <?php if(isset($_SESSION['ID'])){?> <a href="logout.php"  class="logout">Log Out</a><?php } ?>
           <?php if(!isset($_SESSION['ID'])) { ?><a href="login.php" class="login">Log In</a><?php } ?>
           <?php if(!isset($_SESSION['ID'])) { ?> <a href="register.php" class="signup" >Sign Up</a><?php } ?>
           
  </div>
        
  <?php if(isset($_SESSION['ID'])){?> <a href="logout.php"  class="account">Log Out</a><?php } ?>
           <?php if(!isset($_SESSION['ID'])) { ?><a href="login.php" class="account">Log In</a><?php } ?>
           <?php if(!isset($_SESSION['ID'])) { ?> <a href="register.php" class="account" >Sign Up</a><?php } ?>
            <a href="about.php">About</a>
            <a href="javascript:void(0);" onclick="openCat()">Categories</a>
            <?php if(isset($_SESSION['ID']) && $_SESSION['ROLE'] == 'Supplier'){?><a href="mystore.php">My Store</a><?php }?>
</div>
</div>