<?php 
include 'Templates/header.php';
 ?>

<main>
    <section class="coursescontent">
	<?php
	require 'connect.php'; 
      
      if (isset($_GET['search'])) {
       $serch =$_GET['search'];
       $sql = "SELECT * FROM courses WHERE course_name LIKE '%$serch%'";
            $result = mysqli_query($conn ,$sql) ; 
      }
         else {
       			$sql = "SELECT * FROM courses ";
       			$result = mysqli_query($conn ,$sql);}

       				if (mysqli_num_rows($result) >0) {
       		 while ($row = mysqli_fetch_assoc($result)) { ?>

       			  <article class="course">
                    
                     <img src="concept-construction-page-site.jpg" alt="course image" class="img1" width="33%"> 
                    <img src="20220531_194240_0002.png" alt="course image" class="img2" width="33%"> 
                  <div class="content"> 
                       <h3 class="coursename"><?=$row['course_name']?></h3>
                    <p class="courseDesc">
                        <?=substr($row['description'],0,50)?>
                    </p>
                    <button class="viewbtn"><a href="course.php?course_id=<?=$row['course_id']?>">View Course</a></button>
                </div>
                </article>
              </section>
                 <?php  }}
                 else{?>
                 <span class="noresult">
                   No Results
                 </span>
                <?php  } ?> 

             
</main>

 <?php 
include 'Templates/footer.php';
 ?>