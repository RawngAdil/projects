<?php
session_start();
require 'connect.php';
error_reporting(0);

if(!isset($_SESSION['ID'])){
  header("Location:login.php");
  die();
}
if($_SESSION['ROLE'] == "Customer" || $_SESSION['ROLE'] == "Supplier") {
header("Location:index.php");
die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin-reviews</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="admin.css">
    <script src="https://kit.fontawesome.com/7c48de50ee.js" crossorigin="anonymous"></script>
	
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<?php include 'AdminNav.php';?>
<h1>Reviews</h1>
    
 
       <?php 
       $sql3 = "SELECT * FROM productratings JOIN users ON  productratings.USER_ID = users.USER_ID  JOIN products ON productratings.PRODUCT_ID = products.PRODUCT_ID ";
       $result3 = mysqli_query($conn,$sql3);
       
       if (mysqli_num_rows($result3) >0) {
         ?>

       <script>
function filter2() {

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("allreviews");
  filter = input.value.toUpperCase();
  table = document.getElementById("reviewstable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<input type="text" id="allreviews" onkeyup="filter2()" placeholder="Search for names.." class="field">
       <section class="tablecontainer">
       
        <table class="table" id="reviewstable">
                <tr>
                        <th>ID</th>
                        <th>User Name</th>
                        <th>Product Name</th> 
                        <th> Feedback</th>
                        <th> Rating</th>
                        <th>See all of product reviews</th>
                         <th>Delete Review</th>
                      
                    </tr>
                    <?php  while ($row3 = mysqli_fetch_assoc($result3)) { ?>
                       
                        <tr>
                            <td><?=$row3['RATING_ID']?></td>
                            <td><?=$row3['FIRST_NAME']?> <?=$row3['LAST_NAME']?></td>
                            <td><?=$row3['PRODUCT_NAME']?></td> 
                            <td> <?=$row3['FEEDBACK']?></td>
                            <td><?=$row3['RATING']?></td>
                            <td><a href="details.php?PRODUCT_ID=<?=$row3['PRODUCT_ID']?>"> Go To...</a></td>
                                <form action="remove.php" method="GET">
                                    <td><a href="remove.php?RATING_ID=<?=$row3['RATING_ID']?>">Remove</a> </td>
                            </form>
                            
                        </tr>

                 <?php  } } ?>
                </table>
                    </section>

                <footer>
        <section class="rights">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
            <p>All Rights reserved for <span  class="allrights">Markazy<sup>&copy;</sup>2022</p></span>
        </section>
     </footer>

</body>
</html>