<?php 
session_start();
if(isset($_SESSION['ROLE'])){
    if($_SESSION['ROLE'] == 'Customer' || $_SESSION['ROLE'] == 'Supplier'){
        header("Location:index.php");
        die;
    }else{
        header("Location:admin.php");
        die;
    }
}
require 'connect.php';
error_reporting(0);
$email = $password = $notification = '';
$emailErr = $passwordErr = $Err ='';
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(isset($_POST["email"])){
    $email = $_POST["email"];
    if(empty($_POST["email"])){
        $emailErr = "Email is required";
        unset($_POST["email"]);
        unset($_POST['password']);
    }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email";
        unset($_POST["email"]);
        unset($_POST['password']);
    }
}else{
    $emailErr = "Email is required";
}if(isset($_POST['password'])){
    if(empty($_POST['password'])){
        $passwordErr = 'Password is required';
        unset($_POST['email']);
        unset($_POST['password']);
    }elseif($emailErr == ''){$sql = "SELECT * FROM users WHERE EMAIL = '$_POST[email]' AND PASSWORD = '$_POST[password]'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) == 0){
        $Err = "Incorrect Email or Password";
        unset($_POST['email']);
        unset($_POST['password']);
    }else{
    $_SESSION['ID']=$row['USER_ID'];
    $_SESSION['ROLE']=$row['ROLE'];
    if($_SESSION['ROLE'] == 'admin' || $_SESSION['ROLE'] == 'superadmin'){
        header("Location: admin.php");
        die;
    
    }else{
        header("Location: index.php");
        die;
       
    }}
}}else{
    $passwordErr = "Password is required";
    unset($_POST['email']);
    unset($_POST['password']);}
}
    if(isset($_GET['registersuccess'])){
        $notification = 'Your account has been registered succcessfully';?>
      <script>
          history.pushState(null, "", location.href.split("?")[0]);
       
      </script>
      <?php }
      include 'notification.php';
      ?>

<!DOCTYPE html>
    <html>
    <head>
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="register.css">
    <meta content="width=device-width,initial-scale=1" name="viewport">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
function validateForm() {
  if (document.getElementById("loginemail").value == '') {
    alert("Email must be filled out");
    return false;
  }else if (document.getElementById("loginpassword").value == '') {
    alert("Password must be filled out");
    return false;
  }
}
</script>
</head>

<body>

<section class="loginbox container">
        <h1>Log In</h1>
        <form method="POST" action="" name="loginform" onsubmit="return validateForm()"><spam><?= $Err?></spam><br>

            <label for="email">Email </label><spam><?= $emailErr?></spam><br>
            <input type="text" name="email" placeholder="Email address" id="loginemail" value="<?= $email?>">

            <label for="password">Password </label><spam><?= $passwordErr?><br>
            <input type="password" name="password" placeholder="Enter your password" id="loginpassword" value="<?= $password?>">

            <div id="btn">
            <a href="index.php"> <button type="button" class="cancel formbtn">Cancel</button></a>
             <button type="submit" class="login formbtn">Login</button>
            <footer class="loginfooter"> <p>Don’t have an account? <a href="register.php">Sign Up</a></p></footer>
               
            </div>
        </form>
    
</section>
</body>
</html>