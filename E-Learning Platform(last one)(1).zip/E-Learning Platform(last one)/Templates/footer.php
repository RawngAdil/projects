<footer>
     	<div class="mainfooter">
             <!-- about us -->
         
     	
             <article class="aboutus">
                <h4 class="sectionhead">About Us</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. <br>
                
                </p>
           </article>
           <!-- contact -->
           <section class="contact">
                 <h4 class="sectionhead">Contact Us in:</h4>
                 <div class="social">
                 <span class="cell">  <!--  <img src="" alt="phone icon">--> <span class="icon"><i class="fa fa-phone"></i></span> <a href="">+xxx xxxx xxx</a></span>
                 <span class="cell"> <!-- <img src="" alt="mail icon"> --> <span class="icon"><i class="fa-regular fa-envelope"></i></span> <a href="mailto:email@example.com">email@example.com</a></span>
                  <p>Or Follow us Now and Get All The News!</p> 
                  <span class="cell" ><!-- <img src="" alt="facebook icon">--> <span class="icon"><i class="fa-brands fa-facebook-square"></i></span> <a href="@somefacbookacount">@somefacbookacount</a></span>
                  <span class="cell"><!--  <img src="" alt="YouTube icon">--> <span  class="icon"><i class="fa fa-youtube"></i></span> <a href="#someyoutubecannel">#someyoutubecannel</a> </span>  
                 		   </div>
                
                
         </div>
     		  

     	</section>
     	<!-- copyrights and some quote -->
     	<section class="rights">
     		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
     		<p>All Rights reserved for <span  class="allrights">WD.PL<sup>&copy;</sup>2022</p></span>
     	</section>
     </footer>

    </article>

</body>
</html>