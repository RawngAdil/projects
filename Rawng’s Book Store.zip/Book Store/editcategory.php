<?php
session_start();
$_SESSION['Category_ID']=$_GET['Category_ID'];
require 'connect.php';
$success = $fail = $exist_error  = $category= $category_err= '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST["category"])){
        $category=$_POST["category"];
        if(empty($_POST["category"])){
            $category_err="category is required ";
            unset($_POST["category"]);
        }
        elseif(preg_match("/[!@#-$%^'+=~|?\/_*()1234567890]/",$_POST["category"])){
            $category_err="Only letters allowed ";
            unset($_POST["category"]);
        }
   
        elseif($category_err=='' and  $exist_error=='') {
                $sql = "UPDATE categories SET Category= '$_POST[category]'
                 WHERE Category_ID= '$_SESSION[Category_ID]'";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    $success = '<span class="success">Category edited successfuly</span>';
                    header('Location:categories.php');
                } else {
                    $fail = '<span class="err">Failed to edit Category</span>';
                }
            
        }
}
}


?>
<!DOCTYPE html>
<html>
<style>
    <?php include 'style.css' ?>
    .container{
        position: absolute;
        width: 50%;
        left: 21%;
    }
</style>

<body>

    <?= $success ?><?= $fail ?>
    <?php
    $sql2= "SELECT * FROM categories WHERE Category_ID='$_SESSION[Category_ID]' ";
    $result2= mysqli_query($conn,$sql2);
    ?>
    <form action="" method="post" >

        <div class="container">
            <h1>Edit Category</h1>
            <div class="hrl"> </div>
            <?php while ($row = mysqli_fetch_assoc($result2))
          
            { ?>

            <label for="category"><b>Category Name</b></label><span class="error"><?=$category_err?></span><br>
            <input type="text"  name="category" id="categoryname" value="<?=$row['Category']?>" required>
            
           

            <div>
            <a href="categories.php"><button type="button" class="cancel">Cancel</button></a>
                <button type="submit"  class="submit">Submit </button>
                <?php } ?>
            </div>
        </div>
    </form>

</body>

</html>