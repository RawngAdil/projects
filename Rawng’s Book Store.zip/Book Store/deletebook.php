<?php 
session_start();
$_SESSION['Book_ID']=$_GET['Book_ID'];
require 'connect.php';
$sql=" DELETE from books WHERE Book_ID='$_SESSION[Book_ID]' ";
    $result = mysqli_query($conn, $sql); 
    if($result){
        $success ='<span class="success">1 Book deleted successfuly</span>';
         header("Location:books.php");
        echo $success;
    }
     else{
         $fail='<span class="err">Failed to delete </span>';}
 

 ?>