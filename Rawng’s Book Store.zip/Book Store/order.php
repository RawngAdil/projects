<?php
session_start();
require 'connect.php';
$sql="SELECT User_Name From users WHERE Email='$_SESSION[email]' ";
$result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 $results=mysqli_query($conn,"SHOW TABLES LIKE'"."$row[User_Name] Order"."'");
if($results->num_rows == 1){
    echo "Table exists";
    $sql1=  "SELECT books.Book_ID,books.Book_Name,authors.Author_Name,books.Price
    FROM books JOIN authors ON books.Author_ID=authors.Author_ID
    WHERE Book_ID='$_SESSION[Book_ID]' ";
   $result1=mysqli_query($conn,$sql1);
   $row1=mysqli_fetch_assoc($result1);
    $sql2="INSERT INTO `$row[User_Name] Order` (`Book_ID`, `Book_Name`, `Author_Name`, `Price`) VALUES ('$row1[Book_ID]', '$row1[Book_Name]', '$row1[Author_Name]', '$row1[Price]');";
    $result2=mysqli_query($conn,$sql2);
if($result1){
    echo "done";
    header("Location:mycart.php?orderdone");
}
else{
    echo "fail";
}
}


$sql1=" CREATE TABLE  `bookstore`.`$row[User_Name] Order` AS 
SELECT `Book_ID`, `Book_Name`, `Author_Name`, `Price`
FROM `$row[User_Name]`";
$result1=mysqli_query($conn,$sql1);
if($result1){
    echo "done";
    header("Location:BookStore.php?orderdone");
}
else{
    echo "fail";
}

?>