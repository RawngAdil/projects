<?php 
if($notification !=''){?>
    <div class="notification">
    <span class="closebtn" onclick="this.parentElement.style.display='none';">
                &times;
            </span>
    <p><?= $notification?></p>
    
</div>
    <?php ;}
    ?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Cookie&family=Fredericka+the+Great&family=Great+Vibes&family=Henny+Penny&family=Merienda&family=Monoton&family=Playball&family=Rubik+Glitch&family=Rubik+Moonrocks&family=Rubik+Wet+Paint&family=Tangerine&family=Spectral+SC:ital,wght@1,300&Tapestry&family=Yellowtail&display=swap');
    .notification{
        position: fixed;
        z-index: 99;
        padding: 15px;
        background:linear-gradient( rgb(11 185 11), rgb(6 42 2) );
        border-radius: 5px;
        width: 97.5%;
        margin-bottom: 10px;
        margin-left:7px;
        
    
    }
    .notification .closebtn{
        cursor: pointer;
        font-family: 'Merienda';
        color:white;
 
  position: absolute;
  text-decoration:none;
  float: right;
  top: 0px;
  right: 15px;
  font-size: 30px;
  margin-left: 50px;
  border: none;
  opacity: 0.9;
  transition: .3s ease;
 
}


.notification .closebtn:hover{
  opacity: 1;
  transform: scale(1.03);
}
.notification p{
    color:white;
    margin-top: 25px;
    font-size: 17px;
    font-family: 'Spectral SC';  
    line-height: 22px;
    font-weight: 595;
}
@media only screen and (min-width:1024px){
    .notification{
        width:75%;
        margin-left:-1px;

    }
    @media only screen and (min-width:1300px){
    .notification{
        width:70%;
        margin-left:-1px;

    }
}
</style>