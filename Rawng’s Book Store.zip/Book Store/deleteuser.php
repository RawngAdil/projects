<?php 
session_start();
$_SESSION['id']=$_GET['id'];
require 'connect.php';
$sql=" DELETE from users WHERE id='$_SESSION[id]' ";
    $result = mysqli_query($conn, $sql); 
    if($result){
        $success ='<span class="success">1 User deleted successfuly</span>';
         header("Location:index.php");
        echo $success;
    }
     else{
         $fail='<span class="err">Failed to delete </span>';}
 

 ?>